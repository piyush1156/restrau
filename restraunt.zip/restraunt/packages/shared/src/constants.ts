import type { OrderStatus, PaymentMethod, PaymentStatus, ReservationStatus, Role, RestaurantConfig } from './types';

/** Brand palette — white-dominant, orange accents. Never use dark mode. */
export const Colors = {
  background: '#FFFFFF',
  backgroundAlt: '#F8F9FB',
  card: '#FFFFFF',
  textPrimary: '#171717',
  textSecondary: '#737373',
  textMuted: '#A3A3A3',
  border: '#EAEAEA',
  primary: '#FF7900',
  primaryPressed: '#E96800',
  primarySoft: '#FFF2E6',
  success: '#198754',
  successSoft: '#E8F5EE',
  danger: '#DC3545',
  dangerSoft: '#FDECEE',
  warning: '#B45309',
  warningSoft: '#FEF3C7',
  disabled: '#F1F1F1',
  white: '#FFFFFF',
  veg: '#198754',
  nonVeg: '#DC3545',
} as const;

export const Spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32 } as const;
export const Radius = { sm: 10, md: 14, lg: 16, xl: 20, xxl: 24, pill: 999 } as const;

/** Soft neumorphic shadow tokens. */
export const Shadow = {
  soft: {
    shadowColor: '#171717',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  card: {
    shadowColor: '#171717',
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
    elevation: 3,
  },
  floating: {
    shadowColor: '#FF7900',
    shadowOpacity: 0.28,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
  },
} as const;

export const TouchTarget = 44;

export const DEFAULT_RESTAURANT_CONFIG: RestaurantConfig = {
  name: 'The Grove',
  tagline: 'Good Food • Good Mood',
  currency: '₹',
  taxBps: 500, // 5% GST
  deliveryFeeMinor: 4000, // ₹40
  platformFeeMinor: 2000, // ₹20
  freeDeliveryAboveMinor: 49900, // ₹499
  minOrderMinor: 19900, // ₹199
  codEnabled: true,
  timezone: 'Asia/Kolkata',
};

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Order Placed',
  confirmed: 'Confirmed',
  preparing: 'Preparing',
  ready: 'Ready',
  out_for_delivery: 'On the way',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

/** Customer-facing tracking timeline (delivery orders). */
export const DELIVERY_TRACKING_STEPS: OrderStatus[] = [
  'confirmed',
  'preparing',
  'out_for_delivery',
  'delivered',
];

export const TAKEAWAY_TRACKING_STEPS: OrderStatus[] = [
  'confirmed',
  'preparing',
  'ready',
  'delivered',
];

export const PAYMENT_STATUS_LABELS: Record<PaymentStatus, string> = {
  pending: 'Pending',
  created: 'Payment initiated',
  paid: 'Paid',
  failed: 'Failed',
  refunded: 'Refunded',
  cancelled: 'Cancelled',
};

export const RESERVATION_STATUS_LABELS: Record<ReservationStatus, string> = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  rejected: 'Rejected',
  cancelled: 'Cancelled',
  completed: 'Completed',
};

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
  razorpay: 'UPI / Card / NetBanking',
  cod: 'Cash on Delivery',
};

export const ROLE_LABELS: Record<Role, string> = {
  customer: 'Customer',
  owner: 'Owner / Super Admin',
  manager: 'Restaurant Manager',
  kitchen: 'Kitchen Staff',
  delivery: 'Delivery Staff',
};

export const SUPPORTED_LOCALES = ['en', 'hi'] as const;
export type Locale = (typeof SUPPORTED_LOCALES)[number];

/** Opening hours, 0 = Sunday. */
export const DEFAULT_OPENING_HOURS = [
  { day: 0, opensAt: '09:00', closesAt: '23:00', isClosed: false },
  { day: 1, opensAt: '09:00', closesAt: '23:00', isClosed: false },
  { day: 2, opensAt: '09:00', closesAt: '23:00', isClosed: false },
  { day: 3, opensAt: '09:00', closesAt: '23:00', isClosed: false },
  { day: 4, opensAt: '09:00', closesAt: '23:00', isClosed: false },
  { day: 5, opensAt: '09:00', closesAt: '23:30', isClosed: false },
  { day: 6, opensAt: '08:30', closesAt: '23:30', isClosed: false },
];
