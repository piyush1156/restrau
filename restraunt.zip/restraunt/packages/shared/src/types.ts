/** Domain types shared by the mobile app, backend and admin dashboard. */

export type Role = 'customer' | 'owner' | 'manager' | 'kitchen' | 'delivery';
export const STAFF_ROLES: Role[] = ['owner', 'manager', 'kitchen', 'delivery'];
export const ADMIN_ROLES: Role[] = ['owner', 'manager'];

export type OrderType = 'delivery' | 'takeaway' | 'dine_in';

export type PaymentMethod = 'razorpay' | 'cod';
export type PaymentStatus =
  | 'pending'
  | 'created'
  | 'paid'
  | 'failed'
  | 'refunded'
  | 'cancelled';

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export type ReservationStatus =
  | 'pending'
  | 'confirmed'
  | 'rejected'
  | 'cancelled'
  | 'completed';

export type SeatPreference = 'indoor' | 'outdoor' | 'any';

export type CategorySlug =
  | 'starters'
  | 'main-course'
  | 'desserts'
  | 'beverages';

export interface Profile {
  id: string;
  fullName: string;
  email: string;
  phone: string | null;
  role: Role;
  locale: 'en' | 'hi';
  avatarUrl: string | null;
  pushTokens?: string[];
  notifyOrderUpdates?: boolean;
  notifyOffers?: boolean;
  notifyReservations?: boolean;
  shareAnalytics?: boolean;
  createdAt: string;
}

export interface Address {
  id: string;
  label: string; // Home, Work, Other
  line1: string;
  line2?: string | null;
  landmark?: string | null;
  city: string;
  pincode: string;
  lat?: number | null;
  lng?: number | null;
  isDefault: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: CategorySlug | string;
  sortOrder: number;
}

export interface AddOn {
  id: string;
  name: string;
  priceMinor: number;
  isAvailable?: boolean;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  categorySlug?: string;
  name: string;
  description: string;
  /** Current selling price in minor units. */
  priceMinor: number;
  /** Optional discounted price; when set and lower, it is the selling price. */
  discountedPriceMinor?: number | null;
  imageUrl: string;
  rating: number;
  reviewCount: number;
  isVeg: boolean;
  isAvailable: boolean;
  isSpecial?: boolean;
  ingredients: string[];
  allergens: string[];
  addOns: AddOn[];
  prepTimeMins?: number;
}

/** Line item as stored in the cart (client side). */
export interface CartLine {
  /** Stable identity: menuItemId + sorted add-on ids + instructions. */
  key: string;
  menuItemId: string;
  name: string;
  imageUrl: string;
  /** Unit price snapshot (menu price + selected add-ons), minor units. */
  unitPriceMinor: number;
  addOns: AddOn[];
  quantity: number;
  specialInstructions?: string;
}

export interface CartTotals {
  subtotalMinor: number;
  discountMinor: number;
  taxesMinor: number;
  deliveryFeeMinor: number;
  platformFeeMinor: number;
  grandTotalMinor: number;
}

export interface Coupon {
  code: string;
  description: string;
  discountPercent?: number;
  discountFlatMinor?: number;
  maxDiscountMinor?: number | null;
  minOrderMinor: number;
  expiresAt: string;
  isActive: boolean;
  usageLimit: number | null;
  usedCount: number;
}

export interface OrderItem {
  id: string;
  menuItemId: string | null;
  name: string;
  imageUrl: string;
  quantity: number;
  /** Price snapshot at checkout (unit price, minor units). */
  unitPriceMinor: number;
  addOns: { id: string; name: string; priceMinor: number }[];
  specialInstructions?: string | null;
}

export interface OrderTotals extends CartTotals {
  itemsTotalMinor: number;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  phone: string;
  vehicle?: string | null;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerPhone: string;
  type: OrderType;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  items: OrderItem[];
  totals: OrderTotals;
  address?: Address | null;
  deliveryInstructions?: string | null;
  couponCode?: string | null;
  deliveryPartner?: DeliveryPartner | null;
  estimatedAt?: string | null;
  cancelReason?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface OrderStatusStep {
  status: OrderStatus;
  label: string;
  at: string | null;
  done: boolean;
}

export interface Reservation {
  id: string;
  code: string;
  userId: string;
  customerName: string;
  customerPhone: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm 24h
  guests: number;
  seating: SeatPreference;
  tableNumber?: number | null;
  specialRequests?: string | null;
  status: ReservationStatus;
  createdAt: string;
}

export interface RestaurantTable {
  id: string;
  tableNumber: number;
  capacity: number;
  seating: 'indoor' | 'outdoor';
  is_active: boolean;
}

export interface OpeningHour {
  /** 0 = Sunday … 6 = Saturday */
  day: number;
  opensAt: string; // HH:mm
  closesAt: string; // HH:mm
  isClosed: boolean;
}

export interface Review {
  id: string;
  menuItemId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  createdAt: string;
}

export interface RestaurantConfig {
  name: string;
  tagline: string;
  currency: string;
  /** GST applied on item subtotal, in basis points (5% = 500). */
  taxBps: number;
  deliveryFeeMinor: number;
  platformFeeMinor: number;
  freeDeliveryAboveMinor: number;
  minOrderMinor: number;
  codEnabled: boolean;
  timezone: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

export interface Paginated<T> {
  data: T[];
  page: number;
  pageSize: number;
  total: number;
}

export interface DashboardStats {
  totalOrders: number;
  todayOrders: number;
  todayRevenueMinor: number;
  pendingOrders: number;
  preparingOrders: number;
  completedOrders: number;
  cancelledOrders: number;
  avgOrderValueMinor: number;
}

export interface RevenuePoint {
  label: string;
  orders: number;
  revenueMinor: number;
}
