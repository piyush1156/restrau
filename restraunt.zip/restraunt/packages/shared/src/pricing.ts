import { clampMinor } from './money';
import type { CartLine, Coupon, RestaurantConfig } from './types';

export interface PriceInput {
  lines: CartLine[];
  coupon?: Coupon | null;
  config: RestaurantConfig;
  /** 'delivery' adds delivery fee + enforces minimum order. */
  orderType: 'delivery' | 'takeaway' | 'dine_in';
}

export interface PriceBreakdown {
  itemsTotalMinor: number;
  subtotalMinor: number;
  discountMinor: number;
  taxesMinor: number;
  deliveryFeeMinor: number;
  platformFeeMinor: number;
  grandTotalMinor: number;
  couponCode: string | null;
  /** Non-empty when the order cannot be placed (e.g. below minimum). */
  issues: string[];
}

export const lineTotal = (line: CartLine): number =>
  clampMinor(line.unitPriceMinor * line.quantity);

export const cartSubtotal = (lines: CartLine[]): number =>
  lines.reduce((sum, l) => sum + lineTotal(l), 0);

export const couponIsValid = (coupon: Coupon, subtotalMinor: number, now = new Date()): boolean => {
  if (!coupon.isActive) return false;
  if (new Date(coupon.expiresAt).getTime() < now.getTime()) return false;
  if (subtotalMinor < coupon.minOrderMinor) return false;
  if (coupon.usageLimit != null && coupon.usedCount >= coupon.usageLimit) return false;
  return true;
};

export const couponDiscount = (
  coupon: Coupon | null | undefined,
  subtotalMinor: number,
  now = new Date(),
): { discountMinor: number; applied: boolean } => {
  if (!coupon || !couponIsValid(coupon, subtotalMinor, now)) {
    return { discountMinor: 0, applied: false };
  }
  let discount = 0;
  if (coupon.discountPercent) {
    discount = Math.round((subtotalMinor * coupon.discountPercent) / 100);
  }
  if (coupon.discountFlatMinor) {
    discount = Math.max(discount, coupon.discountFlatMinor);
  }
  if (coupon.maxDiscountMinor != null) {
    discount = Math.min(discount, coupon.maxDiscountMinor);
  }
  discount = Math.min(discount, subtotalMinor); // never exceed subtotal
  return { discountMinor: clampMinor(discount), applied: discount > 0 };
};

/**
 * Single source of truth for payable amounts.
 * All math happens in integer paise; taxes apply to the discounted item value.
 */
export const computeTotals = ({ lines, coupon, config, orderType }: PriceInput): PriceBreakdown => {
  const issues: string[] = [];
  const itemsTotalMinor = cartSubtotal(lines);
  const { discountMinor, applied } = couponDiscount(coupon, itemsTotalMinor);
  const netItems = itemsTotalMinor - discountMinor;

  const taxesMinor = clampMinor(Math.round((netItems * config.taxBps) / 10000));

  const isDelivery = orderType === 'delivery';
  let deliveryFeeMinor = 0;
  if (isDelivery) {
    deliveryFeeMinor =
      netItems >= config.freeDeliveryAboveMinor ? 0 : config.deliveryFeeMinor;
  }

  const platformFeeMinor = lines.length > 0 ? config.platformFeeMinor : 0;
  const grandTotalMinor = clampMinor(
    netItems + taxesMinor + deliveryFeeMinor + platformFeeMinor,
  );

  if (isDelivery && itemsTotalMinor > 0 && itemsTotalMinor < config.minOrderMinor) {
    issues.push(
      `Minimum order for delivery is ₹${Math.round(config.minOrderMinor / 100)}. Add ₹${Math.ceil(
        (config.minOrderMinor - itemsTotalMinor) / 100,
      )} more.`,
    );
  }

  return {
    itemsTotalMinor,
    subtotalMinor: itemsTotalMinor,
    discountMinor: applied ? discountMinor : 0,
    taxesMinor,
    deliveryFeeMinor,
    platformFeeMinor,
    grandTotalMinor,
    couponCode: applied ? coupon!.code : null,
    issues,
  };
};
