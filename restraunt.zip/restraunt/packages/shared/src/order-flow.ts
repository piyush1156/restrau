import type { OrderStatus, OrderType, PaymentStatus, ReservationStatus, Role } from './types';

/** Allowed order status transitions. Server enforces these; UI mirrors them. */
export const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['preparing', 'cancelled'],
  preparing: ['ready', 'out_for_delivery', 'cancelled'],
  ready: ['out_for_delivery', 'delivered'],
  out_for_delivery: ['delivered'],
  delivered: [],
  cancelled: [],
};

export const canTransition = (from: OrderStatus, to: OrderStatus): boolean =>
  ORDER_TRANSITIONS[from]?.includes(to) ?? false;

/** Statuses a customer is allowed to cancel from. */
export const CUSTOMER_CANCELLABLE: OrderStatus[] = ['pending', 'confirmed'];

export const canCustomerCancel = (status: OrderStatus): boolean =>
  CUSTOMER_CANCELLABLE.includes(status);

/** Which staff roles may move an order INTO a given status. */
export const STATUS_WRITE_ROLES: Record<OrderStatus, Role[]> = {
  pending: ['owner', 'manager'],
  confirmed: ['owner', 'manager', 'kitchen'],
  preparing: ['owner', 'manager', 'kitchen'],
  ready: ['owner', 'manager', 'kitchen'],
  out_for_delivery: ['owner', 'manager', 'delivery'],
  delivered: ['owner', 'manager', 'delivery'],
  cancelled: ['owner', 'manager'],
};

export const canRoleSetStatus = (role: Role, to: OrderStatus): boolean =>
  (STATUS_WRITE_ROLES[to] ?? []).includes(role);

/** Statuses that count as "active" for the customer tracking screen. */
export const ACTIVE_ORDER_STATUSES: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'ready',
  'out_for_delivery',
];

export const PAYMENT_TRANSITIONS: Record<PaymentStatus, PaymentStatus[]> = {
  pending: ['created', 'paid', 'failed', 'cancelled'],
  created: ['paid', 'failed', 'cancelled'],
  paid: ['refunded'],
  failed: ['created', 'cancelled'],
  cancelled: [],
  refunded: [],
};

/** Steps of the customer tracking timeline, per order type. */
export const trackingStepsFor = (type: OrderType): OrderStatus[] =>
  type === 'delivery'
    ? ['confirmed', 'preparing', 'out_for_delivery', 'delivered']
    : ['confirmed', 'preparing', 'ready', 'delivered'];

/** Reservation transitions. */
export const RESERVATION_TRANSITIONS: Record<ReservationStatus, ReservationStatus[]> = {
  pending: ['confirmed', 'rejected', 'cancelled'],
  confirmed: ['cancelled', 'completed'],
  rejected: [],
  cancelled: [],
  completed: [],
};

export const canTransitionReservation = (
  from: ReservationStatus,
  to: ReservationStatus,
): boolean => RESERVATION_TRANSITIONS[from]?.includes(to) ?? false;

/** Roles that may perform admin-only operations. */
export const ADMIN_ONLY_ROLES: Role[] = ['owner', 'manager'];

export const isStaff = (role: Role): boolean => role !== 'customer';
