import { describe, expect, it } from 'vitest';
import { DEFAULT_RESTAURANT_CONFIG, formatMinor, toMinor } from '../constants-reexport';

// Re-export sanity: constants re-exported through index
import { computeTotals, couponDiscount, couponIsValid } from '../pricing';
import { canTransition, canCustomerCancel, canRoleSetStatus } from '../order-flow';
import type { CartLine, Coupon } from '../types';

const line = (unitPriceMinor: number, quantity = 1): CartLine => ({
  key: `k-${unitPriceMinor}-${quantity}`,
  menuItemId: 'm1',
  name: 'Paneer Tikka',
  imageUrl: 'https://example.com/x.jpg',
  unitPriceMinor,
  addOns: [],
  quantity,
});

const config = { ...DEFAULT_RESTAURANT_CONFIG };

const activeCoupon: Coupon = {
  code: 'GROVE10',
  description: '10% off',
  discountPercent: 10,
  maxDiscountMinor: 5000,
  minOrderMinor: 19900,
  expiresAt: new Date(Date.now() + 86400000).toISOString(),
  isActive: true,
  usageLimit: 100,
  usedCount: 0,
};

describe('money', () => {
  it('formats minor units in Indian grouping', () => {
    expect(formatMinor(24900)).toBe('₹249');
    expect(formatMinor(88750)).toBe('₹887.50');
    expect(formatMinor(100000)).toBe('₹1,000');
    expect(formatMinor(0)).toBe('₹0');
  });

  it('converts rupees to paise without float drift', () => {
    expect(toMinor(19.99)).toBe(1999);
    expect(toMinor(0.1) + toMinor(0.2)).toBe(30);
  });
});

describe('computeTotals', () => {
  it('matches the reference cart: ₹827 items, ₹40 delivery, ₹20 platform, ₹887 total', () => {
    // Paneer Tikka 249 + Butter Chicken 299 + Veg Pizza 279 = 827
    const lines = [line(24900), line(29900), line(27900)];
    const t = computeTotals({ lines, coupon: null, config, orderType: 'delivery' });
    expect(t.subtotalMinor).toBe(82700);
    expect(t.deliveryFeeMinor).toBe(4000);
    expect(t.platformFeeMinor).toBe(2000);
    // taxes = 5% of 827 = 41.35 -> 41.35 rounded to 4135? 5% of 82700 = 4135
    expect(t.taxesMinor).toBe(4135);
    expect(t.grandTotalMinor).toBe(82700 + 4135 + 4000 + 2000);
  });

  it('applies percent coupon with cap and enforces minimum order', () => {
    const lines = [line(24900, 2)]; // 498 < min 199? no, 498 > 199 ok
    const t = computeTotals({ lines, coupon: activeCoupon, config, orderType: 'delivery' });
    expect(t.discountMinor).toBe(4980); // 10% of 49800 = 4980
    expect(t.couponCode).toBe('GROVE10');
  });

  it('rejects coupon below minimum order', () => {
    const { applied, discountMinor } = couponDiscount(activeCoupon, 10000);
    expect(applied).toBe(false);
    expect(discountMinor).toBe(0);
  });

  it('rejects expired coupon', () => {
    const expired: Coupon = { ...activeCoupon, expiresAt: new Date(Date.now() - 1000).toISOString() };
    expect(couponIsValid(expired, 50000)).toBe(false);
  });

  it('gives free delivery above threshold and no fee for takeaway', () => {
    const big = [line(49900)];
    expect(computeTotals({ lines: big, coupon: null, config, orderType: 'delivery' }).deliveryFeeMinor).toBe(0);
    expect(computeTotals({ lines: [line(24900)], coupon: null, config, orderType: 'takeaway' }).deliveryFeeMinor).toBe(0);
  });

  it('flags minimum-order violation for delivery', () => {
    const t = computeTotals({ lines: [line(10000)], coupon: null, config, orderType: 'delivery' });
    expect(t.issues.length).toBe(1);
    expect(t.issues[0]).toContain('Minimum order');
  });

  it('discount never exceeds item total', () => {
    const flat: Coupon = { ...activeCoupon, discountPercent: undefined, discountFlatMinor: 999999, minOrderMinor: 0 };
    expect(couponDiscount(flat, 10000).discountMinor).toBe(10000);
  });
});

describe('order flow', () => {
  it('allows only valid transitions', () => {
    expect(canTransition('pending', 'confirmed')).toBe(true);
    expect(canTransition('preparing', 'delivered')).toBe(false);
    expect(canTransition('delivered', 'cancelled')).toBe(false);
    expect(canTransition('out_for_delivery', 'delivered')).toBe(true);
  });

  it('customers can only cancel early orders', () => {
    expect(canCustomerCancel('pending')).toBe(true);
    expect(canCustomerCancel('confirmed')).toBe(true);
    expect(canCustomerCancel('preparing')).toBe(false);
  });

  it('kitchen staff cannot mark delivered', () => {
    expect(canRoleSetStatus('kitchen', 'preparing')).toBe(true);
    expect(canRoleSetStatus('kitchen', 'delivered')).toBe(false);
    expect(canRoleSetStatus('delivery', 'out_for_delivery')).toBe(true);
  });
});
