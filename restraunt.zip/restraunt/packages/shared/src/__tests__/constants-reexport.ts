export { DEFAULT_RESTAURANT_CONFIG, formatMinor, toMinor } from '../index';
