import { describe, expect, it } from 'vitest';
import {
  addressSchema,
  checkoutSchema,
  loginSchema,
  registerSchema,
  reservationSchema,
} from '../validation';

describe('loginSchema', () => {
  it('accepts email', () => {
    expect(loginSchema.safeParse({ identifier: 'piyush@gmail.com', password: 'secret1' }).success).toBe(true);
  });
  it('accepts 10-digit Indian mobile', () => {
    expect(loginSchema.safeParse({ identifier: '9876543210', password: 'secret1' }).success).toBe(true);
  });
  it('rejects invalid email', () => {
    const r = loginSchema.safeParse({ identifier: 'nope', password: 'secret1' });
    expect(r.success).toBe(false);
  });
});

describe('registerSchema', () => {
  it('requires matching passwords', () => {
    const r = registerSchema.safeParse({
      fullName: 'Piyush Singh',
      email: 'p@x.com',
      phone: '9876543210',
      password: 'passw0rd',
      confirmPassword: 'different',
    });
    expect(r.success).toBe(false);
  });
  it('rejects non-Indian mobile prefix', () => {
    const r = registerSchema.safeParse({
      fullName: 'Piyush Singh',
      email: 'p@x.com',
      phone: '1234567890',
      password: 'passw0rd',
      confirmPassword: 'passw0rd',
    });
    expect(r.success).toBe(false);
  });
});

describe('addressSchema', () => {
  it('validates pincode', () => {
    expect(addressSchema.safeParse({
      label: 'Home', line1: '123 Green Park', city: 'Delhi', pincode: '110016', isDefault: true,
    }).success).toBe(true);
    expect(addressSchema.safeParse({
      label: 'Home', line1: '123 Green Park', city: 'Delhi', pincode: '011016',
    }).success).toBe(false);
  });
});

describe('checkoutSchema', () => {
  const base = {
    type: 'delivery' as const,
    paymentMethod: 'razorpay' as const,
    contactPhone: '9876543210',
    deliveryInstructions: '',
    couponCode: '',
  };
  it('requires address for delivery', () => {
    expect(checkoutSchema.safeParse({ ...base, addressId: null }).success).toBe(false);
    expect(checkoutSchema.safeParse({ ...base, addressId: 'addr_1' }).success).toBe(true);
  });
  it('does not require address for takeaway', () => {
    expect(checkoutSchema.safeParse({ ...base, type: 'takeaway', addressId: null }).success).toBe(true);
  });
});

describe('reservationSchema', () => {
  it('rejects past dates and bad times', () => {
    expect(reservationSchema.safeParse({ date: '2020-01-01', time: '19:00', guests: 2, seating: 'any' }).success).toBe(false);
    expect(reservationSchema.safeParse({ date: '2030-01-01', time: '25:00', guests: 2, seating: 'any' }).success).toBe(false);
  });
  it('accepts a valid future booking', () => {
    const d = new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10);
    expect(reservationSchema.safeParse({ date: d, time: '19:00', guests: 4, seating: 'indoor', specialRequests: '' }).success).toBe(true);
  });
});
