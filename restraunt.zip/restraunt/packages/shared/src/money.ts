/**
 * Money is ALWAYS integer minor units (paise). Never floats.
 * formatMinor(24900) === "₹249"
 */
export const toMinor = (rupees: number): number => Math.round(rupees * 100);

export const toMajor = (minor: number): number => minor / 100;

export const formatMinor = (minor: number, currency = '₹'): string => {
  const sign = minor < 0 ? '-' : '';
  const abs = Math.abs(minor);
  const rupees = Math.floor(abs / 100);
  const paise = abs % 100;
  const grouped = rupees.toLocaleString('en-IN');
  return paise === 0
    ? `${sign}${currency}${grouped}`
    : `${sign}${currency}${grouped}.${paise.toString().padStart(2, '0')}`;
};

export const clampMinor = (value: number): number =>
  Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0;
