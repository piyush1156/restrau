import { z } from 'zod';

const phoneRegex = /^[6-9]\d{9}$/;
const nameRegex = /^[A-Za-z\u0900-\u097F][A-Za-z\u0900-\u097F .'-]{1,60}$/;

export const emailSchema = z
  .string()
  .trim()
  .min(1, 'Email is required')
  .email('Enter a valid email address');

export const phoneSchema = z
  .string()
  .trim()
  .transform((v) => v.replace(/[\s-]/g, ''))
  .refine((v) => phoneRegex.test(v), 'Enter a valid 10-digit Indian mobile number');

export const loginSchema = z
  .object({
    identifier: z
      .string()
      .trim()
      .min(1, 'Email or phone number is required')
      .refine(
        (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || phoneRegex.test(v.replace(/[\s-]/g, '')),
        'Enter a valid email or 10-digit phone number',
      ),
    password: z.string().min(6, 'Password must be at least 6 characters'),
  })
  .strict();

export const registerSchema = z
  .object({
    fullName: z
      .string()
      .trim()
      .min(2, 'Name must be at least 2 characters')
      .regex(nameRegex, 'Enter a valid name'),
    email: emailSchema,
    phone: phoneSchema,
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[0-9]/, 'Password must contain a number')
      .regex(/[A-Za-z]/, 'Password must contain a letter'),
    confirmPassword: z.string(),
  })
  .strict()
  .refine((d) => d.password === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

export const forgotPasswordSchema = z.object({ email: emailSchema }).strict();

export const addressSchema = z
  .object({
    label: z.enum(['Home', 'Work', 'Other'], {
      errorMap: () => ({ message: 'Choose a label' }),
    }),
    line1: z.string().trim().min(4, 'Flat / street is required').max(120),
    line2: z.string().trim().max(120).optional().or(z.literal('')),
    landmark: z.string().trim().max(80).optional().or(z.literal('')),
    city: z.string().trim().min(2, 'City is required').max(60),
    pincode: z
      .string()
      .trim()
      .regex(/^[1-9]\d{5}$/, 'Enter a valid 6-digit pincode'),
    isDefault: z.boolean().optional().default(false),
  })
  .strict();

export const checkoutSchema = z
  .object({
    addressId: z.string().min(1, 'Select a delivery address').nullable(),
    type: z.enum(['delivery', 'takeaway', 'dine_in']),
    paymentMethod: z.enum(['razorpay', 'cod']),
    deliveryInstructions: z.string().trim().max(200).optional().or(z.literal('')),
    contactPhone: phoneSchema,
    couponCode: z.string().trim().toUpperCase().max(24).optional().or(z.literal('')),
  })
  .strict()
  .refine((d) => !(d.type === 'delivery' && !d.addressId), {
    message: 'A delivery address is required',
    path: ['addressId'],
  });

export const reservationSchema = z
  .object({
    date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, 'Pick a date')
      .refine((d) => new Date(`${d}T00:00:00`).getTime() >= new Date(new Date().toDateString()).getTime(), 'Date cannot be in the past'),
    time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Pick a time slot'),
    guests: z
      .number({ invalid_type_error: 'Choose guest count' })
      .int()
      .min(1, 'At least 1 guest')
      .max(20, 'For groups above 20, call the restaurant'),
    seating: z.enum(['indoor', 'outdoor', 'any']),
    specialRequests: z.string().trim().max(200).optional().or(z.literal('')),
  })
  .strict();

export const chatMessageSchema = z
  .object({ message: z.string().trim().min(1, 'Type a message').max(500) })
  .strict();

export const reviewSchema = z
  .object({
    rating: z.number().int().min(1, 'Pick a rating').max(5),
    comment: z.string().trim().min(3, 'Write a few words').max(500),
  })
  .strict();

export const couponCodeSchema = z
  .object({ code: z.string().trim().min(3).max(24).transform((v) => v.toUpperCase()) })
  .strict();

export const adminMenuItemSchema = z
  .object({
    name: z.string().trim().min(2).max(80),
    categoryId: z.string().min(1),
    description: z.string().trim().min(5).max(400),
    priceMinor: z.number().int().min(100, 'Price must be at least ₹1'),
    discountedPriceMinor: z.number().int().min(100).nullable().optional(),
    imageUrl: z.string().url().or(z.string().startsWith('/')),
    isVeg: z.boolean(),
    isAvailable: z.boolean().default(true),
    isSpecial: z.boolean().default(false),
    ingredients: z.array(z.string().max(40)).max(30).default([]),
    allergens: z.array(z.string().max(40)).max(30).default([]),
    addOns: z
      .array(
        z.object({
          name: z.string().trim().min(1).max(40),
          priceMinor: z.number().int().min(0),
        }),
      )
      .max(10)
      .default([]),
  })
  .strict();

export const adminCouponSchema = z
  .object({
    code: z
      .string()
      .trim()
      .min(3)
      .max(24)
      .transform((v) => v.toUpperCase()),
    description: z.string().trim().min(3).max(140),
    discountPercent: z.number().int().min(1).max(90).optional(),
    discountFlatMinor: z.number().int().min(100).optional(),
    maxDiscountMinor: z.number().int().min(100).nullable().optional(),
    minOrderMinor: z.number().int().min(0),
    expiresAt: z.string().datetime({ offset: true }),
    usageLimit: z.number().int().min(1).nullable().optional(),
  })
  .strict()
  .refine((d) => d.discountPercent != null || d.discountFlatMinor != null, {
    message: 'Provide a percent or flat discount',
  });

export const adminOrderStatusSchema = z
  .object({
    status: z.enum([
      'pending',
      'confirmed',
      'preparing',
      'ready',
      'out_for_delivery',
      'delivered',
      'cancelled',
    ]),
    cancelReason: z.string().trim().max(200).optional(),
  })
  .strict();

export const adminReservationStatusSchema = z
  .object({ status: z.enum(['confirmed', 'rejected', 'cancelled', 'completed']) })
  .strict();

export const loginInputSchema = loginSchema;
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type AddressInput = z.infer<typeof addressSchema>;
export type CheckoutInput = z.infer<typeof checkoutSchema>;
export type ReservationInput = z.infer<typeof reservationSchema>;
export type ChatMessageInput = z.infer<typeof chatMessageSchema>;
export type ReviewInput = z.infer<typeof reviewSchema>;
export type AdminMenuItemInput = z.infer<typeof adminMenuItemSchema>;
export type AdminCouponInput = z.infer<typeof adminCouponSchema>;
