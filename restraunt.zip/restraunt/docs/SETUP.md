# Setup guide

## 0. Requirements

- Node.js 20+
- npm 10+ (workspaces)
- Expo Go on a phone, or Android Studio / Xcode for a simulator
- A Supabase project (free tier is enough for development)
- Optional: Razorpay test account, OpenAI-compatible API key, Resend account

## 1. Install

```bash
git clone <your-repo>
cd the-grove
npm install
```

Workspaces install `packages/shared`, `apps/mobile`, `apps/admin` and `backend` together.

## 2. Environment files

```bash
cp .env.example .env                     # documentation only; real values live in each app
cp apps/mobile/.env.example apps/mobile/.env
cp backend/.env.example backend/.env
cp apps/admin/.env.example apps/admin/.env
```

`apps/mobile/.env`:

```dotenv
EXPO_PUBLIC_API_MODE=auto        # demo | remote | auto
EXPO_PUBLIC_API_URL=             # e.g. http://192.168.1.10:4000 (no trailing slash)
EXPO_PUBLIC_RAZORPAY_KEY_ID=     # rzp_test_… public key only
```

`backend/.env` (server-only secrets):

```dotenv
PORT=4000
CORS_ORIGINS=http://localhost:3000
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=…      # never ship to the app
SUPABASE_ANON_KEY=…
PAYMENTS_DEMO=true               # dev only; refused in production
COD_ENABLED=true
```

`apps/admin/.env`:

```dotenv
NEXT_PUBLIC_API_URL=http://localhost:4000
```

## 3. Database

1. Create a project at supabase.com.
2. Apply migrations in order (`supabase/migrations/`):
   ```bash
   npx supabase link --project-ref <project-ref>
   npx supabase db push
   ```
   Or paste every `.sql` file in `supabase/migrations/` into the SQL editor in filename order.
3. Seed:
   ```bash
   # via psql
   psql "$DATABASE_URL" -f supabase/seed.sql
   # or paste supabase/seed.sql into the SQL editor
   ```
4. Create an account (app registration or Supabase Auth) and grant staff access:
   ```sql
   select public.grant_staff('owner@thegrove.in', 'owner');
   ```
   This updates `profiles.role` and inserts into `staff_roles`; it is executable only by the
   service role.

### Storage (food & profile images)

1. Storage → New bucket → `menu-images` (public), `avatars` (public read, authenticated write).
2. Add policies:
   ```sql
   create policy "public read menu images" on storage.objects for select
     using (bucket_id = 'menu-images');
   create policy "staff upload menu images" on storage.objects for insert to authenticated
     with check (bucket_id = 'menu-images' and public.is_staff());
   ```
3. Upload images and paste their public URLs in Admin → Menu → Image URL.

## 4. Run

```bash
npm run dev:backend     # http://localhost:4000/health
npm run dev:admin       # http://localhost:3000  (sign in with a staff account)
npm run dev:mobile      # Expo
```

Health output shows whether the database, payments and assistant are configured.

### Testing on a physical phone

The API must be reachable on your LAN:

```bash
# find your IP (macOS/Linux)
ipconfig getifaddr en0 || hostname -I
# Windows
ipconfig
```

Set `EXPO_PUBLIC_API_URL=http://<LAN-IP>:4000` and restart Expo with `npx expo start -c`.
If `auto` mode cannot reach the API it silently falls back to demo data — set
`EXPO_PUBLIC_API_MODE=remote` while debugging so failures are visible.

## 5. Razorpay test mode

1. Razorpay Dashboard → Settings → API Keys → generate **test** keys.
2. Backend: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_PUBLIC_KEY_ID` (same as key id), `PAYMENTS_DEMO=false`.
3. Webhook: Settings → Webhooks → add `https://<api-host>/payments/webhook` with events
   `payment.captured`, `payment.failed`, `refund.processed`; put the signing secret in
   `RAZORPAY_WEBHOOK_SECRET`.
4. Mobile: `EXPO_PUBLIC_RAZORPAY_KEY_ID=rzp_test_…` (not required — the server returns the key id,
   but it is useful for local overrides).
5. Build a development/preview client (Expo Go lacks the native Razorpay module):
   ```bash
   cd apps/mobile && npx eas-cli build -p android --profile development
   ```
6. Test card `4111 1111 1111 1111`, any future expiry, CVV `123`; UPI success/failure flows are
   available in test mode. **Never enable live keys during development.**

## 6. AI assistant

Without `OPENAI_API_KEY` the server uses a deterministic rule engine that answers from menu,
opening hours and the caller's own orders. With a key:

```dotenv
OPENAI_API_KEY=sk-…
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```

The system prompt contains only approved restaurant data and the signed-in customer's recent
orders; the assistant is instructed never to invent statuses, prices or availability and to
escalate to human support. Provider errors fall back to the rule engine automatically.

## 7. Notifications

- Push: `EXPO_PUSH_ENABLED=true`; the app registers its Expo push token (Settings → notifications).
  Until tokens are registered the server still writes in-app notifications.
- Email: `RESEND_API_KEY` + `EMAIL_FROM` with a verified domain.
- SMS/WhatsApp: intentionally not wired to a provider. Add one (e.g. Twilio) in
  `backend/src/lib/notifications.ts` only after the sender and templates are approved.

## 8. Tests and checks

```bash
npm test                                  # shared + backend unit tests
npm run typecheck                         # shared, backend, admin
cd apps/mobile && npm run typecheck
cd apps/admin && npm run build            # production build check
```

Live end-to-end (sandbox only, never production):

```bash
cd backend
E2E_BASE_URL=http://localhost:4000 E2E_EMAIL=you@example.com E2E_PASSWORD=… \
  npx vitest run src/tests/customer-journey.e2e.test.ts
```

## 9. Troubleshooting

| Symptom | Fix |
| --- | --- |
| App shows demo data although the backend runs | `EXPO_PUBLIC_API_MODE=remote`, correct LAN IP, restart Expo with `-c` |
| `401` everywhere after signing in | Token expired or backend keys mismatched; sign out and back in. Check `SUPABASE_ANON_KEY`. |
| `503 database not configured` | `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` missing in `backend/.env` |
| Coupon says "does not exist" | Run `supabase/seed.sql`; codes are case-insensitive but must exist |
| Payment sheet does not open | Expo Go has no native Razorpay; use a development/preview build |
| `Signature mismatch` on payment | Wrong `RAZORPAY_KEY_SECRET`, or a payment from another order/key |
| CORS error in admin | Add the admin origin to `CORS_ORIGINS` and restart the API |
| Reservation says slot unavailable | Table already booked; the partial unique index prevents double booking |
| EAS build fails on `projectId` | Run `npx eas-cli init` inside `apps/mobile` |
| Images blank | URL unreachable → the app shows a branded placeholder; fix the URL in Admin → Menu |
| Admin login rejects staff | Account role must be owner/manager/kitchen/delivery; run `grant_staff` |
