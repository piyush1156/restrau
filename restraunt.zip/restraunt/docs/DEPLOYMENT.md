# Deployment

## 1. Supabase (production)

1. Create a dedicated production project (do not reuse the dev project).
2. Apply migrations with `npx supabase db push` and seed only the catalogue:
   `psql "$DATABASE_URL" -f supabase/seed.sql` (seed is idempotent).
3. Auth → URL configuration: add your API domain and the app deep link
   (`thegrove://reset-password`) to the redirect allow-list.
4. Auth → Providers: enable Email. Enable phone OTP only if you have an SMS provider.
5. Storage: create `menu-images` and `avatars` buckets with the policies from `docs/SETUP.md`.
6. Schedule `expire_unpaid_orders()` every 5 minutes (pg_cron or an external scheduler):
   ```sql
   select cron.schedule('expire-unpaid', '*/5 * * * *', $$select public.expire_unpaid_orders()$$);
   ```
7. Enable daily backups (Supabase Pro) and test a restore before launch.
8. Rotate the service-role key if it was ever used outside the server.

## 2. API (Render / Fly / Railway / any Node host)

Build command: `npm install && npm run build --workspace backend`
Start command: `node backend/dist/index.js`

Environment (server-only):

```dotenv
NODE_ENV=production
PORT=4000
CORS_ORIGINS=https://admin.yourdomain.com
SUPABASE_URL=…
SUPABASE_SERVICE_ROLE_KEY=…
SUPABASE_ANON_KEY=…
PASSWORD_RESET_REDIRECT_URL=thegrove://reset-password
RAZORPAY_KEY_ID=rzp_live_…
RAZORPAY_KEY_SECRET=…
RAZORPAY_PUBLIC_KEY_ID=rzp_live_…
RAZORPAY_WEBHOOK_SECRET=…
PAYMENTS_DEMO=false
COD_ENABLED=true
OPENAI_API_KEY=…            # optional
EXPO_PUSH_ENABLED=true
RESEND_API_KEY=…           # optional
```

The server refuses to boot in production if `PAYMENTS_DEMO=true` or CORS contains `*`.

Checks after deploy:

```bash
curl https://api.yourdomain.com/health
# { "ok":true, "db":true, "payments":"live", "ai":"enabled" }
```

Put the API behind HTTPS (required by Razorpay and by iOS ATS). Keep the service-role key in the
host's secret store, never in a repo.

### Razorpay webhook

Dashboard → Webhooks → `https://api.yourdomain.com/payments/webhook`
Events: `payment.captured`, `payment.failed`, `refund.processed`.
Copy the signing secret into `RAZORPAY_WEBHOOK_SECRET` and redeploy. Unverified webhooks are
rejected with `400`.

## 3. Admin dashboard (Vercel)

1. Import the repo, set **root directory** to `apps/admin`.
2. Build: `npm run build`; output: Next.js default.
3. Env: `NEXT_PUBLIC_API_URL=https://api.yourdomain.com`.
4. Add the Vercel domain to the API's `CORS_ORIGINS`.
5. Protect the deployment with your host's access control (SSO/IP allow-list) in addition to
   staff login. The dashboard is internal.

## 4. Android APK / AAB

```bash
cd apps/mobile
npx eas-cli login
npx eas-cli init                       # writes the real projectId into app.json
```

Add production env to `eas.json` (or `eas secret:create`):

```json
"production": {
  "autoIncrement": true,
  "android": { "buildType": "app-bundle" },
  "env": {
    "EXPO_PUBLIC_API_MODE": "remote",
    "EXPO_PUBLIC_API_URL": "https://api.yourdomain.com"
  }
}
```

Build an installable **APK** (internal testing):

```bash
npx eas-cli build -p android --profile preview --non-interactive
```

Build a Play Store **AAB**:

```bash
npx eas-cli build -p android --profile production
```

Local build (needs Android SDK + JDK 17):

```bash
npx eas-cli build -p android --profile preview --local
```

### Building an APK without local tools or an Expo account

`.github/workflows/android-apk.yml` builds a release APK on GitHub Actions:

1. Push the repository to GitHub.
2. Actions → **Android APK** → **Run workflow**.
3. Download the **the-grove-apk** artifact — it contains `app-release.apk`.

By default the APK runs in demo mode (`EXPO_PUBLIC_API_MODE=demo`), so it works
standalone. Add repository variables `EXPO_PUBLIC_API_MODE=remote` and
`EXPO_PUBLIC_API_URL=https://api.yourdomain.com` to point it at a deployed API.
The artifact is signed with the debug keystore (installable for testing, not
Play Store). This workflow is provided untested against your environment; if
Gradle reports a native-module incompatibility, use the EAS build above.

Install on a device: `adb install -r path/to/app.apk`.

Play Store: create the app, upload the AAB, complete data-safety (payments, location: none) and
content rating, then roll out to internal testing first. `versionCode` is managed by EAS
(`appVersionSource: "remote"`).

## 5. iOS

Prerequisites: Apple Developer Program membership, a bundle id
(`com.thegrove.restaurant` is already set), and App Store Connect access.

```bash
cd apps/mobile
npx eas-cli build -p ios --profile production
npx eas-cli submit -p ios --latest
```

Info required: privacy nutrition labels, account deletion path (Settings → Privacy → Request
account deletion is implemented), and payment disclosure (physical goods → external payment,
which is allowed for restaurant orders).

## 6. Production checklist

- [ ] `PAYMENTS_DEMO=false`, live Razorpay keys, webhook secret set and verified
- [ ] `CORS_ORIGINS` lists only real origins; API behind HTTPS
- [ ] Service-role key only in server env; no secret in the mobile bundle (`expo export` + search)
- [ ] Migrations applied; RLS enabled on every table; `grant_staff` restricted to service role
- [ ] Staff accounts have the minimum role they need; owner account has 2FA on email
- [ ] `expire_unpaid_orders()` scheduled
- [ ] Backups on and one restore tested
- [ ] Menu prices and allergen data reviewed by the restaurant
- [ ] Push tokens and email sender verified (if enabled)
- [ ] Demo orders cleared (`truncate orders cascade`) before launch
- [ ] Monitoring: API 5xx alerts, webhook failures, low order volume alert
- [ ] Load test `/menu` and `/orders` at expected dinner rush concurrency

## 7. Operational notes

- **Revenue definition:** paid orders only, excluding cancelled orders, in IST. Used consistently
  in the dashboard, reports and CSV.
- **Refunds:** cancelling a paid order marks it for refund; complete the refund in the Razorpay
  dashboard (or add the refund API call in `backend/src/routes/orders.ts`). The webhook updates
  the status to `refunded`.
- **Live driver tracking:** no maps provider is integrated. The app shows a clear fallback and
  only exposes a partner phone when one is assigned. Adding a provider is a contained change in
  the order tracking screen + `delivery_assignments`.
- **Scaling:** the API is stateless; run 2+ instances behind a load balancer. Enable Supabase
  connection pooling for high traffic and add Redis-based rate limiting if you run multiple
  instances (the in-memory limiter is per instance).
