# Database

Postgres via Supabase. Files:

| File | Purpose |
| --- | --- |
| `supabase/migrations/20260101000000_init.sql` | enums, tables, constraints, indexes, triggers |
| `supabase/migrations/20260101000100_rls.sql` | Row Level Security policies |
| `supabase/migrations/20260101000200_backend_functions.sql` | atomic RPCs used by the API |
| `supabase/migrations/20260101000300_notification_prefs.sql` | customer notification/privacy preferences |
| `supabase/seed.sql` | categories, dishes, add-ons, coupons, tables, hours, `grant_staff()` |

## Money and time

- All money columns are `integer` **paise** (₹1 = 100). No floats anywhere.
- `orders` stores a full price snapshot: item total, discount, tax, delivery, platform fee and
  grand total, with a check constraint that they add up.
- `order_items.unit_price_minor` and `add_ons` jsonb snapshot the price at checkout.
- Timestamps are `timestamptz`; the API and app render in `Asia/Kolkata`.

## Tables

| Table | Key columns | Notes |
| --- | --- | --- |
| `profiles` | id → auth.users, role, locale, push_tokens, notify_* / share_analytics | role trigger blocks self-promotion; preferences gate push/email |
| `addresses` | user_id, label, pincode, is_default | one default per user (partial unique index) |
| `categories` | name, slug, sort_order | public read |
| `menu_items` | category_id, price_minor, discounted_price_minor, is_veg / is_special flags, ingredients[], allergens[] | discounted price must be < price |
| `menu_item_images` | menu_item_id, url | gallery (optional) |
| `add_ons` / `item_add_ons` | price_minor / join table | reusable extras |
| `favourites` | (user_id, menu_item_id) PK | cascade on delete |
| `coupons` | code citext, percent/flat, cap, min order, expiry, usage | check: at least one discount type |
| `orders` | order_number `TG######`, status, payment_status, totals, address_snapshot, coupon_code | status/type/payment enums; totals check |
| `order_items` | order_id, name/image snapshot, unit_price_minor, add_ons jsonb | cascade with order |
| `order_status_history` | order_id, status, changed_by, note | written by the API with actor + reason |
| `payments` | order_id, provider_order_id, provider_payment_id, amount_minor, signature_verified | unique provider ids |
| `coupon_redemptions` | coupon_code, user_id, order_id | one per coupon per order |
| `idempotency_keys` | key PK, user_id, scope, response jsonb | checkout replay protection |
| `reservations` | date, time, guests, table_id, status | active-slot unique index + conflict trigger |
| `restaurant_tables` | table_number, capacity, seating | `seating` indoor/outdoor |
| `restaurant_opening_hours` | day 0–6, opens_at, closes_at, is_closed | drives server slot generation |
| `delivery_assignments` | order_id unique, partner_id | delivery staff |
| `reviews` | menu_item_id, user_id, rating, comment | trigger recalculates rating & count |
| `notifications` | user_id, channel, payload, read_at | in-app + push/email delivery attempts |
| `support_conversations` / `support_messages` | user_id / conversation_id, role, body | assistant transcripts for human follow-up |
| `staff_roles` | user_id PK, role, granted_by | source of truth for staff access |
| `audit_logs` | actor_id, action, entity, before/after jsonb | admin changes |

## Integrity rules

- Foreign keys with deliberate delete behaviour: order history keeps price snapshots even if a
  dish is hidden (`on delete set null`), profiles cascade their own addresses/favourites.
- `orders.grand_total_minor = items_total − discount + taxes + delivery + platform` (check).
- `orders` requires an address snapshot when `type = 'delivery'`.
- Reservations: partial unique index on `(table_id, reservation_date, reservation_time)` where
  status is `pending`/`confirmed`, plus a trigger that raises on conflict. Cancelled/rejected
  rows free the slot.
- Coupons: percent between 1–90, cap optional, usage limit optional, expiry required.
- Reviews: one per dish per order per user; rating 1–5.
- UI hide + API role check + RLS policy are three independent layers; none relies on the client.

## RLS summary

| Data | Customer | Staff |
| --- | --- | --- |
| profiles | read/update own | read all; only owner/manager may change roles (trigger) |
| addresses | CRUD own | read (fulfilment) |
| categories, menu, add-ons, images | read | read; writes via API service role |
| favourites | CRUD own | – |
| coupons | read active only | read (admin API) |
| orders, order_items, payments, history | read own only | read all staff |
| reservations | read own, cancel own only | read all; status writes via API |
| reviews | read all, insert for own delivered order | read all |
| notifications | read/update own | – |
| support conversations | own | read all |
| staff_roles, audit_logs | – | owner/manager read |
| idempotency_keys | no access | service role only |

Writes to orders/payments/coupons go through the API using the service role, which is why those
tables have no customer insert/update policies.

## Helper functions

- `current_role_of(uuid)`, `is_staff()`, `is_admin()`, `has_role(user_role[])` — used by policies.
- `increment_coupon_usage(code)` — atomic usage increment, raises when exhausted.
- `revenue_between(from, to)` — daily orders/revenue (paid only).
- `expire_unpaid_orders()` — cancels online orders unpaid after 30 minutes (call from a cron).
- `sync_menu_item_rating()` — trigger on reviews.
- `log_order_status()` — trigger on orders.
- `assert_no_reservation_conflict()` — trigger on reservations.
- `grant_staff(email, role)` — service-role-only helper used during setup.

## Useful queries

```sql
-- today's paid revenue (IST)
select coalesce(sum(grand_total_minor),0)/100.0 as revenue
from orders
where payment_status = 'paid'
  and (created_at at time zone 'Asia/Kolkata')::date = (now() at time zone 'Asia/Kolkata')::date;

-- free tables for 19:30 with 4 guests
select t.table_number, t.capacity, t.seating
from restaurant_tables t
where t.is_active and t.capacity >= 4
  and t.id not in (
    select table_id from reservations
    where reservation_date = date '2026-11-10' and reservation_time = time '19:30'
      and status in ('pending','confirmed') and table_id is not null
  );

-- expire stale unpaid orders (schedule every 5 minutes)
select expire_unpaid_orders();
```
