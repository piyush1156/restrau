# API reference

Base URL: `http://localhost:4000` (dev). All bodies are JSON. Errors always look like:

```json
{ "error": { "code": "bad_request", "message": "Please check the highlighted fields.", "details": {} } }
```

Auth: `Authorization: Bearer <supabase access token>`. Mutating checkout calls require
`Idempotency-Key: <8–100 chars>`.

## Health

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/health` | – | service status, db/payments/AI mode |

## Auth & profile

| Method | Path | Auth | Body / notes |
| --- | --- | --- | --- |
| POST | `/auth/register` | – | `fullName, email, phone, password, confirmPassword` → `{ profile, token }` |
| POST | `/auth/login` | – | `identifier` (email or phone), `password` → `{ profile, token }` |
| POST | `/auth/logout` | user | invalidates the client session (stateless JWT) |
| POST | `/auth/reset-password` | – | `{ email }` → always `200` (no account enumeration) |
| GET | `/me` | user | current profile |
| PATCH | `/me` | user | `fullName? phone? avatarUrl? locale? pushTokens?` |
| POST | `/auth/delete-request` | user | flags account for deletion (7-day grace) |

`/login` and `/register` also exist without the `/auth` prefix for compatibility; both are rate-limited.

## Menu, favourites, addresses, coupons

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/menu?category=&search=` | – | `{ data: MenuItem[] }` |
| GET | `/menu/categories` | – | `{ data: Category[] }` |
| GET | `/menu/:id` | – | `{ data: MenuItem }` |
| GET | `/menu/:id/reviews` | – | latest 50 reviews |
| POST | `/menu/:id/reviews` | user | `{ rating 1..5, comment }` |
| GET | `/favourites` | user | `{ data: MenuItem[] }` |
| POST | `/favourites/:menuItemId` | user | idempotent |
| DELETE | `/favourites/:menuItemId` | user | |
| GET | `/addresses` | user | default first |
| POST | `/addresses` | user | `{ label, line1, line2?, landmark?, city, pincode, isDefault? }` |
| PATCH | `/addresses/:id` | user | ownership checked |
| DELETE | `/addresses/:id` | user | |
| GET | `/coupons` | – | active, unexpired public offers |
| POST | `/coupons/validate` | – | `{ code, subtotalMinor?, lines? }` → `{ data: Coupon }` |

## Checkout & orders

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| POST | `/checkout/reprice` | – | `{ lines }` → `{ lines, removed:[{key,name,reason}] }`; prices/availability from DB |
| POST | `/checkout/validate` | – | coupon validation with live rules |
| POST | `/orders` | user | `{ checkout, lines, couponCode?, idempotencyKey? }` + `Idempotency-Key` → `201 { data: Order }` |
| GET | `/orders?status=all\|active\|delivered\|cancelled&page=&pageSize=` | user | paginated, own orders only |
| GET | `/orders/:id` | user | own order |
| POST | `/orders/:id/cancel` | user | allowed while `pending`/`confirmed`; `{ reason? }` |
| POST | `/payments/create-order` | user | `{ orderId }` → `{ razorpayOrderId, amountMinor, currency, keyId, demo }` |
| POST | `/payments/verify` | user | `{ orderId, razorpayOrderId, razorpayPaymentId, razorpaySignature }` |
| POST | `/payments/webhook` | signature | raw body; `X-Razorpay-Signature` |

Order creation steps: re-price → coupon + totals → address snapshot → insert order + items +
history → coupon usage → idempotency response. Any failure releases the idempotency key.

## Reservations

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/reservations/availability?date=YYYY-MM-DD&guests=2` | – | `{ slots, bookedTimes, tables, seatingFull }` |
| POST | `/reservations` | user | `{ date, time, guests, seating, specialRequests? }` → `201 { data }` |
| GET | `/reservations` | user | own bookings |
| POST | `/reservations/:id/cancel` | user | future bookings only |

Conflicts return `409`. The database enforces one active booking per table/slot.

## Assistant

| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| POST | `/chat/messages` | optional | `{ message }` → `ChatMessage`; AI or rule-based |
| GET | `/chat/status` | – | `{ online: true }` |

## Admin (staff roles)

| Method | Path | Roles | Notes |
| --- | --- | --- | --- |
| GET | `/admin/dashboard` | all staff | stats, 7-day revenue, popular dishes, recent orders |
| GET | `/admin/orders` | all staff | filters `status, from, to, q, page, pageSize` |
| PATCH | `/admin/orders/:id/status` | per target status | transition + role checked; cancel needs reason |
| POST | `/admin/orders/:id/assign` | owner, manager | `{ partnerId }` (delivery role) |
| GET | `/admin/menu` | owner, manager | raw rows for editing |
| POST | `/admin/menu` | owner, manager | create dish |
| PATCH | `/admin/menu/:id` | owner, manager | partial update |
| PATCH | `/admin/menu/:id/availability` | all staff | sold-out toggle |
| DELETE | `/admin/menu/:id` | owner, manager | soft delete (hide) |
| GET | `/admin/coupons` | owner, manager | |
| POST | `/admin/coupons` | owner, manager | |
| PATCH | `/admin/coupons/:id` | owner, manager | pause/activate, expiry, usage limit |
| GET | `/admin/reservations?date=` | all staff | bookings + table inventory |
| PATCH | `/admin/reservations/:id/status` | owner, manager | confirm/reject/cancel/complete |
| GET | `/admin/reports?from&to` | owner, manager | totals, daily, by type, top items |
| GET | `/admin/reports/export.csv` | owner, manager | CSV download |
| GET | `/admin/customers?q=` | owner, manager | privacy-scoped fields |
| GET | `/admin/staff` | owner, manager | staff roles |
| POST | `/admin/staff` | owner | `{ email, role }` |
| GET | `/admin/audit` | owner, manager | last 100 admin changes |

All admin writes are recorded in `audit_logs` and customer-affecting status changes create a
notification.

## Rate limits

| Scope | Limit |
| --- | --- |
| Global per IP | 300 req/min |
| Login/register/reset | 20 per 15 min |
| Chat messages | 20 per min |

## Status codes

`200` ok · `201` created · `400` validation/business rule · `401` missing/expired session ·
`403` role not permitted · `404` not found (also used instead of `403` for other users' records) ·
`409` conflict (availability, coupon, idempotency in progress) · `429` rate limited ·
`502` payment provider error · `503` not configured / upstream unavailable.
