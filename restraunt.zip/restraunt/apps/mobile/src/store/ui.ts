import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { groveApi } from '@/services/client';

interface FavouriteState {
  ids: string[];
  toggle: (menuItemId: string) => Promise<void>;
  isFavourite: (menuItemId: string) => boolean;
  hydrateFromServer: (ids: string[]) => void;
  reset: () => void;
}

export const useFavouritesStore = create<FavouriteState>()(
  persist(
    (set, get) => ({
      ids: [],
      isFavourite: (id) => get().ids.includes(id),
      toggle: async (id) => {
        const wasFav = get().ids.includes(id);
        // optimistic update, revert on failure
        set({ ids: wasFav ? get().ids.filter((x) => x !== id) : [...get().ids, id] });
        try {
          if (wasFav) await groveApi.removeFavourite(id);
          else await groveApi.addFavourite(id);
        } catch {
          set({ ids: wasFav ? [...get().ids, id] : get().ids.filter((x) => x !== id) });
          throw new Error('Could not update favourites. Please try again.');
        }
      },
      hydrateFromServer: (ids) => set({ ids }),
      reset: () => set({ ids: [] }),
    }),
    { name: 'grove-favourites-v1', storage: createJSONStorage(() => AsyncStorage) },
  ),
);

interface ToastState {
  message: string | null;
  type: 'success' | 'error' | 'info';
  show: (message: string, type?: ToastState['type']) => void;
  hide: () => void;
}

export const useToastStore = create<ToastState>((set) => ({
  message: null,
  type: 'info',
  show: (message, type = 'info') => set({ message, type }),
  hide: () => set({ message: null }),
}));

interface DrawerState {
  open: boolean;
  setOpen: (open: boolean) => void;
}

export const useDrawerStore = create<DrawerState>((set) => ({
  open: false,
  setOpen: (open) => set({ open }),
}));
