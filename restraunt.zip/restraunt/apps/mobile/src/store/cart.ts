import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { AddOn, CartLine, Coupon, OrderType } from '@grove/shared';
import { computeTotals, type PriceBreakdown } from '@grove/shared';

export interface CartState {
  lines: CartLine[];
  couponCode: string | null;
  orderType: OrderType;
  /** Monotonic key so checkout can act as an idempotency key. */
  checkoutAttemptId: string;
  addItem: (input: {
    menuItemId: string;
    name: string;
    imageUrl: string;
    basePriceMinor: number;
    addOns: AddOn[];
    quantity: number;
    specialInstructions?: string;
  }) => void;
  setQuantity: (key: string, quantity: number) => void;
  removeLine: (key: string) => void;
  clear: () => void;
  setCoupon: (code: string | null) => void;
  setOrderType: (type: OrderType) => void;
  newCheckoutAttempt: () => void;
  /** Replace lines with server-repriced versions (checkout validation). */
  syncLines: (lines: CartLine[]) => void;
}

const lineKey = (menuItemId: string, addOns: AddOn[], instructions: string): string =>
  `${menuItemId}|${[...addOns.map((a) => a.id)].sort().join(',')}|${instructions.trim().toLowerCase()}`;

const newId = (): string =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      lines: [],
      couponCode: null,
      orderType: 'delivery',
      checkoutAttemptId: newId(),

      addItem: ({ menuItemId, name, imageUrl, basePriceMinor, addOns, quantity, specialInstructions }) => {
        const instructions = specialInstructions?.trim() ?? '';
        const key = lineKey(menuItemId, addOns, instructions);
        const unitPriceMinor = basePriceMinor + addOns.reduce((s, a) => s + a.priceMinor, 0);
        set((state) => {
          const existing = state.lines.find((l) => l.key === key);
          if (existing) {
            return {
              lines: state.lines.map((l) =>
                l.key === key ? { ...l, quantity: Math.min(l.quantity + quantity, 20) } : l,
              ),
              // cart changed → next checkout attempt is a new order
              checkoutAttemptId: newId(),
            };
          }
          const line: CartLine = {
            key,
            menuItemId,
            name,
            imageUrl,
            unitPriceMinor,
            addOns,
            quantity,
            specialInstructions: instructions || undefined,
          };
          return { lines: [...state.lines, line], checkoutAttemptId: newId() };
        });
      },

      setQuantity: (key, quantity) =>
        set((state) => ({
          lines:
            quantity <= 0
              ? state.lines.filter((l) => l.key !== key)
              : state.lines.map((l) => (l.key === key ? { ...l, quantity: Math.min(quantity, 20) } : l)),
          checkoutAttemptId: newId(),
        })),

      removeLine: (key) =>
        set((state) => ({
          lines: state.lines.filter((l) => l.key !== key),
          checkoutAttemptId: newId(),
        })),

      clear: () => set({ lines: [], couponCode: null, checkoutAttemptId: newId() }),

      setCoupon: (code) => set({ couponCode: code, checkoutAttemptId: newId() }),
      setOrderType: (type) => set({ orderType: type, checkoutAttemptId: newId() }),
      newCheckoutAttempt: () => set({ checkoutAttemptId: newId() }),
      syncLines: (lines) => set({ lines }),
    }),
    {
      name: 'grove-cart-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        lines: s.lines,
        couponCode: s.couponCode,
        orderType: s.orderType,
        checkoutAttemptId: s.checkoutAttemptId,
      }),
    },
  ),
);

/** Cart totals computed from live coupon data fetched by the caller. */
export const useCartTotals = (coupon: Coupon | null, config: {
  taxBps: number;
  deliveryFeeMinor: number;
  platformFeeMinor: number;
  freeDeliveryAboveMinor: number;
  minOrderMinor: number;
  currency: string;
  name: string;
  tagline: string;
  codEnabled: boolean;
  timezone: string;
}): PriceBreakdown => {
  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);
  return computeTotals({ lines, coupon, config, orderType });
};

export const cartCount = (lines: CartLine[]): number => lines.reduce((s, l) => s + l.quantity, 0);
