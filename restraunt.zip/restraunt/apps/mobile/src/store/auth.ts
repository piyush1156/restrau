import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { Locale, Profile } from '@grove/shared';
import { groveApi } from '@/services/client';

interface AuthState {
  status: 'loading' | 'signedOut' | 'signedIn';
  profile: Profile | null;
  token: string | null;
  locale: Locale;
  /** True when running against the built-in demo backend. */
  isDemo: boolean;
  onboarded: boolean;
  bootstrap: () => Promise<void>;
  completeOnboarding: () => void;
  signIn: (identifier: string, password: string) => Promise<void>;
  signUp: (input: { fullName: string; email: string; phone: string; password: string }) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (
    patch: Partial<
      Pick<
        Profile,
        | 'fullName'
        | 'phone'
        | 'avatarUrl'
        | 'locale'
        | 'pushTokens'
        | 'notifyOrderUpdates'
        | 'notifyOffers'
        | 'notifyReservations'
        | 'shareAnalytics'
      >
    >,
  ) => Promise<void>;
  setLocale: (locale: Locale) => void;
  _hydrate: (profile: Profile, token: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      status: 'loading',
      profile: null,
      token: null,
      locale: 'en',
      isDemo: false,
      onboarded: false,

      completeOnboarding: () => set({ onboarded: true }),

      bootstrap: async () => {
        const { token } = get();
        if (!token) {
          set({ status: 'signedOut' });
          return;
        }
        try {
          const profile = await groveApi.getProfile();
          set({ profile, status: 'signedIn' });
        } catch {
          // expired / revoked session
          set({ profile: null, token: null, status: 'signedOut' });
        }
      },

      signIn: async (identifier, password) => {
        const res = await groveApi.login(identifier, password);
        set({ profile: res.profile, token: res.token, status: 'signedIn', isDemo: res.isDemo ?? false });
      },

      signUp: async (input) => {
        const res = await groveApi.register(input);
        set({ profile: res.profile, token: res.token, status: 'signedIn', isDemo: res.isDemo ?? false });
      },

      signOut: async () => {
        try {
          await groveApi.logout();
        } finally {
          set({ profile: null, token: null, status: 'signedOut' });
        }
      },

      updateProfile: async (patch) => {
        const profile = await groveApi.updateProfile(patch);
        set({ profile });
      },

      setLocale: (locale) => {
        set({ locale });
        groveApi.updateProfile({ locale }).catch(() => undefined);
      },

      _hydrate: (profile, token) => set({ profile, token, status: 'signedIn' }),
    }),
    {
      name: 'grove-auth-v1',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ token: s.token, profile: s.profile, locale: s.locale, isDemo: s.isDemo, onboarded: s.onboarded }),
    },
  ),
);

/** Locale-aware copy for the two supported languages. */
export const strings = {
  en: {
    home: 'Home',
    menu: 'Menu',
    orders: 'Orders',
    profile: 'Profile',
    search: 'Search for food, drinks...',
    addToCart: 'Add to Cart',
    viewCart: 'View Cart',
    popular: 'Popular Dishes',
    orderNow: 'Order Now',
    login: 'Login',
    signUp: 'Sign Up',
    logout: 'Logout',
    checkout: 'Checkout',
    payNow: 'Pay Now',
    bookTable: 'Book Your Table',
    emptyCart: 'Your cart is empty',
    emptyFavourites: 'No favourites yet',
    emptyOrders: 'No orders yet',
  },
  hi: {
    home: 'होम',
    menu: 'मेनू',
    orders: 'ऑर्डर',
    profile: 'प्रोफ़ाइल',
    search: 'खाना, पीना खोजें...',
    addToCart: 'कार्ट में डालें',
    viewCart: 'कार्ट देखें',
    popular: 'लोकप्रिय व्यंजन',
    orderNow: 'अभी ऑर्डर करें',
    login: 'लॉगिन',
    signUp: 'साइन अप',
    logout: 'लॉगआउट',
    checkout: 'चेकआउट',
    payNow: 'अभी भुगतान करें',
    bookTable: 'अपनी टेबुक करें',
    emptyCart: 'आपका कार्ट खाली है',
    emptyFavourites: 'अभी तक कोई पसंदीदा नहीं',
    emptyOrders: 'अभी तक कोई ऑर्डर नहीं',
  },
} as const;

export const useStrings = (): (typeof strings)['en'] => {
  const locale = useAuthStore((s) => s.locale);
  return strings[locale] ?? strings.en;
};
