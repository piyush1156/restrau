import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useEffect, useRef, useState } from 'react';
import { groveApi } from '@/services/client';
import type { Order } from '@grove/shared';

export const qk = {
  menu: (category: string, search: string) => ['menu', category, search] as const,
  categories: ['categories'] as const,
  item: (id: string) => ['item', id] as const,
  favourites: ['favourites'] as const,
  orders: (filter: string) => ['orders', filter] as const,
  order: (id: string) => ['order', id] as const,
  addresses: ['addresses'] as const,
  reservations: ['reservations'] as const,
  availability: (date: string, guests: number) => ['availability', date, guests] as const,
  coupons: ['coupons'] as const,
};

export const useMenu = (category = 'all', search = '') =>
  useQuery({
    queryKey: qk.menu(category, search),
    queryFn: () => groveApi.getMenu({ category, search }),
    staleTime: 60_000,
  });

export const useCategories = () =>
  useQuery({ queryKey: qk.categories, queryFn: () => groveApi.getCategories(), staleTime: Infinity });

export const useMenuItem = (id: string) =>
  useQuery({ queryKey: qk.item(id), queryFn: () => groveApi.getMenuItem(id), enabled: Boolean(id) });

export const useFavourites = (enabled = true) =>
  useQuery({ queryKey: qk.favourites, queryFn: () => groveApi.getFavourites(), enabled });

export const useOrders = (filter: 'all' | 'active' | 'delivered' | 'cancelled' = 'all') =>
  useQuery({ queryKey: qk.orders(filter), queryFn: () => groveApi.getOrders({ status: filter }) });

export const useAddresses = (enabled = true) =>
  useQuery({ queryKey: qk.addresses, queryFn: () => groveApi.getAddresses(), enabled });

export const useReservations = (enabled = true) =>
  useQuery({ queryKey: qk.reservations, queryFn: () => groveApi.getReservations(), enabled });

export const useAvailability = (date: string, guests: number) =>
  useQuery({
    queryKey: qk.availability(date, guests),
    queryFn: () => groveApi.getAvailability(date, guests),
    enabled: Boolean(date) && guests > 0,
  });

/**
 * Polls a single order so the tracking screen reflects real status data.
 * Falls back to 30s polling when realtime is not configured.
 */
export const useOrderPolling = (orderId: string | undefined, options?: { refetchInterval?: number }) => {
  const query = useQuery({
    queryKey: qk.order(orderId ?? ''),
    queryFn: () => groveApi.getOrder(orderId!),
    enabled: Boolean(orderId),
    refetchInterval: options?.refetchInterval ?? 15_000,
    refetchIntervalInBackground: true,
  });
  return query;
};

export const useCancelOrder = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, reason }: { id: string; reason?: string }) => groveApi.cancelOrder(id, reason),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['orders'] }),
  });
};

export const useToggleFavourite = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, next }: { id: string; next: boolean }) =>
      next ? groveApi.addFavourite(id) : groveApi.removeFavourite(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.favourites }),
  });
};

/** Debounced value for search inputs (keeps typing smooth). */
export const useDebounced = <T,>(value: T, delay = 350): T => {
  const [debounced, setDebounced] = useState(value);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setDebounced(value), delay);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [value, delay]);
  return debounced;
};

/** Simple retry helper for network failures. */
export const useRetry = () => {
  const [attempt, setAttempt] = useState(0);
  const retry = useCallback(() => setAttempt((a) => a + 1), []);
  return { attempt, retry };
};

export type { Order };
