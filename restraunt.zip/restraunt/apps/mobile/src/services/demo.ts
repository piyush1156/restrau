import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  Address,
  CartLine,
  Category,
  ChatMessage,
  Coupon,
  MenuItem,
  Order,
  OrderTotals,
  Paginated,
  Profile,
  Reservation,
  RestaurantTable,
} from '@grove/shared';
import {
  ACTIVE_ORDER_STATUSES,
  canTransition,
  computeTotals,
  couponDiscount,
  DEFAULT_RESTAURANT_CONFIG,
} from '@grove/shared';
import type { AddressInput, ReservationInput } from '@grove/shared';
import {
  SEED_CATEGORIES,
  SEED_COUPONS,
  SEED_MENU,
  SEED_TABLES,
  generateSlots,
} from '@/data/seed';
import { buildReply, makeMessage } from './chatbot';
import type {
  AuthResult,
  AvailabilityResult,
  CheckoutValidation,
  GroveApi,
  OrdersFilter,
  PaymentOrderResult,
  PlaceOrderInput,
  VerifyPaymentInput,
} from './types';

const DB_KEY = 'grove-demo-db-v1';
const CONFIG = DEFAULT_RESTAURANT_CONFIG;

/**
 * Offline demo backend.
 * Everything (accounts, orders, reservations, favourites, addresses) is persisted
 * on-device with AsyncStorage. It mirrors the remote API contract exactly, so the
 * app behaves identically once EXPO_PUBLIC_API_URL points at the real backend.
 *
 * Demo credentials: any email/phone + 6+ char password works.
 * Staff login (for permission tests): admin@thegrove.in / admin12345
 */
interface DemoUser extends Profile {
  password: string;
}

interface DemoDb {
  users: DemoUser[];
  sessionToken: string | null;
  orders: Order[];
  reservations: Reservation[];
  favourites: Record<string, string[]>;
  addresses: Record<string, Address[]>;
  reviews: { id: string; menuItemId: string; userId: string; rating: number; comment: string; createdAt: string }[];
  coupons: Coupon[];
  usedIdempotencyKeys: Record<string, string>;
}

const emptyDb = (): DemoDb => ({
  users: [],
  sessionToken: null,
  orders: [],
  reservations: [],
  favourites: {},
  addresses: {},
  reviews: [],
  coupons: SEED_COUPONS.map((c) => ({ ...c })),
  usedIdempotencyKeys: {},
});

const uid = (prefix: string): string =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

const orderNumber = (): string =>
  `TG${Math.floor(100000 + Math.random() * 900000)}`;

/** Demo orders progress through the real status machine over time so tracking works. */
const advanceOrder = (order: Order): Order => {
  if (order.status === 'cancelled' || order.status === 'delivered') return order;
  if (order.paymentMethod === 'razorpay' && order.paymentStatus !== 'paid') return order;

  const elapsed = (Date.now() - new Date(order.createdAt).getTime()) / 1000;
  const sequence: Order['status'][] =
    order.type === 'delivery'
      ? ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered']
      : ['pending', 'confirmed', 'preparing', 'ready', 'delivered'];
  const thresholds = [0, 8, 25, 55, 95];
  let status: Order['status'] = order.status;
  for (let i = sequence.length - 1; i >= 0; i--) {
    if (elapsed >= thresholds[i] && sequence.indexOf(order.status) <= i) {
      status = sequence[i];
      break;
    }
  }
  // never skip backwards, never skip more than allowed is handled by thresholds
  if (status !== order.status && canTransition(order.status, status)) {
    return { ...order, status, updatedAt: new Date().toISOString() };
  }
  return order;
};

export class DemoProvider implements GroveApi {
  private db: DemoDb | null = null;
  private token: string | null = null;

  mode(): 'demo' | 'remote' {
    return 'demo';
  }

  setToken(token: string | null): void {
    this.token = token;
  }

  private async load(): Promise<DemoDb> {
    if (this.db) return this.db;
    try {
      const raw = await AsyncStorage.getItem(DB_KEY);
      this.db = raw ? { ...emptyDb(), ...(JSON.parse(raw) as DemoDb) } : emptyDb();
      this.token = this.db.sessionToken;
    } catch {
      this.db = emptyDb();
    }
    return this.db;
  }

  private async save(): Promise<void> {
    if (!this.db) return;
    await AsyncStorage.setItem(DB_KEY, JSON.stringify(this.db));
  }

  private currentUser(): DemoUser {
    const db = this.db;
    const user = db?.users.find((u) => u.id === db.sessionToken) ?? null;
    if (!user) throw new Error('Please sign in to continue.');
    return user;
  }

  private async withUser<T>(fn: (user: DemoUser, db: DemoDb) => Promise<T> | T): Promise<T> {
    const db = await this.load();
    const user = this.currentUser();
    const result = await fn(user, db);
    await this.save();
    return result;
  }

  private profileOf(user: DemoUser): Profile {
    const { password: _pw, ...profile } = user;
    return profile;
  }

  // ---------------------------------------------------------------- auth
  async login(identifier: string, password: string): Promise<AuthResult> {
    const db = await this.load();
    const key = identifier.trim().toLowerCase();
    let user = db.users.find((u) => u.email.toLowerCase() === key || u.phone === key);
    if (user && user.password !== password) throw new Error('Incorrect password. Please try again.');
    if (!user) {
      const isEmail = key.includes('@');
      user = {
        id: uid('usr'),
        fullName: isEmail ? key.split('@')[0].replace(/[._]/g, ' ') : 'Guest User',
        email: isEmail ? key : `${key}@demo.thegrove.local`,
        phone: isEmail ? null : key,
        role: key === 'admin@thegrove.in' ? 'owner' : 'customer',
        locale: 'en',
        avatarUrl: null,
        createdAt: new Date().toISOString(),
        password,
      };
      db.users.push(user);
    }
    db.sessionToken = user.id;
    this.token = user.id;
    await this.save();
    return { profile: this.profileOf(user), token: user.id, isDemo: true };
  }

  async register(input: {
    fullName: string;
    email: string;
    phone: string;
    password: string;
  }): Promise<AuthResult> {
    const db = await this.load();
    const email = input.email.toLowerCase();
    if (db.users.some((u) => u.email.toLowerCase() === email)) {
      throw new Error('An account with this email already exists. Try logging in.');
    }
    const user: DemoUser = {
      id: uid('usr'),
      fullName: input.fullName,
      email,
      phone: input.phone,
      role: 'customer',
      locale: 'en',
      avatarUrl: null,
      createdAt: new Date().toISOString(),
      password: input.password,
    };
    db.users.push(user);
    db.sessionToken = user.id;
    db.favourites[user.id] = [];
    db.addresses[user.id] = [
      {
        id: uid('addr'),
        label: 'Home',
        line1: '123, Green Park',
        line2: 'Near Metro Station',
        city: 'New Delhi',
        pincode: '110016',
        isDefault: true,
      },
    ];
    this.token = user.id;
    await this.save();
    return { profile: this.profileOf(user), token: user.id, isDemo: true };
  }

  async logout(): Promise<void> {
    const db = await this.load();
    db.sessionToken = null;
    this.token = null;
    await this.save();
  }

  async getProfile(): Promise<Profile> {
    await this.load();
    return this.profileOf(this.currentUser());
  }

  async updateProfile(patch: Partial<Profile>): Promise<Profile> {
    return this.withUser((user) => {
      Object.assign(user, patch);
      return this.profileOf(user);
    });
  }

  async requestPasswordReset(email: string): Promise<void> {
    await this.load();
    // Demo mode: no email is sent. Remote backend dispatches a real email.
    void email;
  }

  async requestAccountDeletion(): Promise<void> {
    await this.load();
    // Demo mode records the request against the local profile only.
    this.currentUser();
  }

  // ---------------------------------------------------------------- menu
  async getCategories(): Promise<Category[]> {
    await this.load();
    return [...SEED_CATEGORIES];
  }

  async getMenu(params?: { category?: string; search?: string }): Promise<MenuItem[]> {
    await this.load();
    let items = [...SEED_MENU];
    if (params?.category && params.category !== 'all') {
      items = items.filter((m) => m.categorySlug === params.category || m.categoryId === params.category);
    }
    if (params?.search?.trim()) {
      const q = params.search.trim().toLowerCase();
      items = items.filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q) ||
          m.ingredients.some((i) => i.toLowerCase().includes(q)),
      );
    }
    return items;
  }

  async getMenuItem(id: string): Promise<MenuItem> {
    await this.load();
    const item = SEED_MENU.find((m) => m.id === id);
    if (!item) throw new Error('Dish not found.');
    return item;
  }

  // ----------------------------------------------------------- favourites
  async getFavourites(): Promise<MenuItem[]> {
    return this.withUser((user, db) =>
      (db.favourites[user.id] ?? [])
        .map((id) => SEED_MENU.find((m) => m.id === id))
        .filter((m): m is MenuItem => Boolean(m)),
    );
  }

  async addFavourite(menuItemId: string): Promise<void> {
    await this.withUser((user, db) => {
      db.favourites[user.id] = [...new Set([...(db.favourites[user.id] ?? []), menuItemId])];
    });
  }

  async removeFavourite(menuItemId: string): Promise<void> {
    await this.withUser((user, db) => {
      db.favourites[user.id] = (db.favourites[user.id] ?? []).filter((id) => id !== menuItemId);
    });
  }

  // ------------------------------------------------------------ addresses
  async getAddresses(): Promise<Address[]> {
    return this.withUser((user, db) => [...(db.addresses[user.id] ?? [])]);
  }

  async saveAddress(input: AddressInput & { id?: string }): Promise<Address> {
    return this.withUser((user, db) => {
      const list = db.addresses[user.id] ?? [];
      let saved: Address;
      if (input.id) {
        const idx = list.findIndex((a) => a.id === input.id);
        saved = { ...list[idx], ...input } as Address;
        list[idx] = saved;
      } else {
        saved = { ...(input as AddressInput), id: uid('addr') } as Address;
        list.push(saved);
      }
      if (saved.isDefault) {
        db.addresses[user.id] = list.map((a) => ({ ...a, isDefault: a.id === saved.id }));
      } else {
        db.addresses[user.id] = list;
      }
      return saved;
    });
  }

  async deleteAddress(id: string): Promise<void> {
    await this.withUser((user, db) => {
      db.addresses[user.id] = (db.addresses[user.id] ?? []).filter((a) => a.id !== id);
    });
  }

  // -------------------------------------------------------------- coupons
  async getPublicCoupons(): Promise<Coupon[]> {
    const db = await this.load();
    return db.coupons.filter((c) => c.isActive);
  }

  async validateCoupon(code: string, subtotalMinor: number): Promise<Coupon> {
    const db = await this.load();
    const coupon = db.coupons.find((c) => c.code === code.trim().toUpperCase());
    if (!coupon) throw new Error('This coupon code does not exist.');
    const { applied, discountMinor } = couponDiscount(coupon, subtotalMinor);
    if (!applied) {
      if (new Date(coupon.expiresAt) < new Date()) throw new Error('This coupon has expired.');
      if (subtotalMinor < coupon.minOrderMinor)
        throw new Error(
          `Add items worth ${Math.ceil((coupon.minOrderMinor - subtotalMinor) / 100)} more to use ${coupon.code}.`,
        );
      if (coupon.usageLimit != null && coupon.usedCount >= coupon.usageLimit)
        throw new Error('This coupon has reached its usage limit.');
      throw new Error('This coupon is not applicable to your cart.');
    }
    return coupon;
  }

  // -------------------------------------------------------------- checkout
  async validateCart(lines: CartLine[]): Promise<CheckoutValidation> {
    await this.load();
    const removed: CheckoutValidation['removed'] = [];
    const current: CartLine[] = [];
    for (const line of lines) {
      const item = SEED_MENU.find((m) => m.id === line.menuItemId);
      if (!item) {
        removed.push({ key: line.key, name: line.name, reason: 'removed_from_menu' });
        continue;
      }
      if (!item.isAvailable) {
        removed.push({ key: line.key, name: line.name, reason: 'unavailable' });
        continue;
      }
      const unit =
        (item.discountedPriceMinor ?? item.priceMinor) +
        line.addOns.reduce((s, a) => {
          const live = item.addOns.find((x) => x.id === a.id);
          return s + (live ? live.priceMinor : a.priceMinor);
        }, 0);
      if (unit !== line.unitPriceMinor) {
        removed.push({ key: line.key, name: line.name, reason: 'price_changed' });
      }
      current.push({ ...line, unitPriceMinor: unit, imageUrl: item.imageUrl, name: item.name });
    }
    return { lines: current, removed };
  }

  async placeOrder(input: PlaceOrderInput): Promise<Order> {
    return this.withUser((user, db) => {
      // idempotency: replaying the same attempt returns the same order
      const existingId = db.usedIdempotencyKeys[input.idempotencyKey];
      if (existingId) {
        const existing = db.orders.find((o) => o.id === existingId);
        if (existing) return advanceOrder(existing);
      }

      const validated = this.validateCartSync(input.lines);
      if (validated.removed.some((r) => r.reason === 'unavailable' || r.reason === 'removed_from_menu')) {
        throw new Error(
          `Some items are no longer available: ${validated.removed
            .filter((r) => r.reason !== 'price_changed')
            .map((r) => r.name)
            .join(', ')}.`,
        );
      }

      const totals = computeTotals({
        lines: validated.lines,
        coupon: input.couponCode
          ? db.coupons.find((c) => c.code === input.couponCode) ?? null
          : null,
        config: CONFIG,
        orderType: input.checkout.type,
      });
      if (totals.issues.length) throw new Error(totals.issues.join(' '));

      if (input.checkout.type === 'delivery' && !input.checkout.addressId) {
        throw new Error('A delivery address is required.');
      }
      if (input.checkout.paymentMethod === 'cod' && !CONFIG.codEnabled) {
        throw new Error('Cash on Delivery is currently disabled by the restaurant.');
      }

      const address =
        input.checkout.type === 'delivery'
          ? (db.addresses[user.id] ?? []).find((a) => a.id === input.checkout.addressId) ?? null
          : null;

      const orderTotals: OrderTotals = {
        itemsTotalMinor: totals.itemsTotalMinor,
        subtotalMinor: totals.subtotalMinor,
        discountMinor: totals.discountMinor,
        taxesMinor: totals.taxesMinor,
        deliveryFeeMinor: totals.deliveryFeeMinor,
        platformFeeMinor: totals.platformFeeMinor,
        grandTotalMinor: totals.grandTotalMinor,
      };

      const order: Order = {
        id: uid('ord'),
        orderNumber: orderNumber(),
        userId: user.id,
        customerName: user.fullName,
        customerPhone: input.checkout.contactPhone,
        type: input.checkout.type,
        status: 'pending',
        paymentMethod: input.checkout.paymentMethod,
        paymentStatus: input.checkout.paymentMethod === 'cod' ? 'pending' : 'created',
        items: validated.lines.map((l, i) => ({
          id: `oi_${i}_${l.key.slice(0, 12)}`,
          menuItemId: l.menuItemId,
          name: l.name,
          imageUrl: l.imageUrl,
          quantity: l.quantity,
          unitPriceMinor: l.unitPriceMinor,
          addOns: l.addOns.map((a) => ({ id: a.id, name: a.name, priceMinor: a.priceMinor })),
          specialInstructions: l.specialInstructions ?? null,
        })),
        totals: orderTotals,
        address,
        deliveryInstructions: input.checkout.deliveryInstructions || null,
        couponCode: totals.couponCode,
        deliveryPartner: null,
        estimatedAt: new Date(Date.now() + 35 * 60000).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (totals.couponCode) {
        const c = db.coupons.find((x) => x.code === totals.couponCode);
        if (c) c.usedCount += 1;
      }
      db.usedIdempotencyKeys[input.idempotencyKey] = order.id;
      db.orders.unshift(order);
      return order;
    });
  }

  private validateCartSync(lines: CartLine[]): CheckoutValidation {
    const removed: CheckoutValidation['removed'] = [];
    const current: CartLine[] = [];
    for (const line of lines) {
      const item = SEED_MENU.find((m) => m.id === line.menuItemId);
      if (!item || !item.isAvailable) {
        removed.push({
          key: line.key,
          name: line.name,
          reason: item ? 'unavailable' : 'removed_from_menu',
        });
        continue;
      }
      const unit = (item.discountedPriceMinor ?? item.priceMinor) + line.addOns.reduce((s, a) => s + a.priceMinor, 0);
      current.push({ ...line, unitPriceMinor: unit });
    }
    return { lines: current, removed };
  }

  // ---------------------------------------------------------------- orders
  async getOrders(filter?: OrdersFilter): Promise<Paginated<Order>> {
    return this.withUser((user, db) => {
      db.orders = db.orders.map(advanceOrder);
      let list = db.orders.filter((o) => o.userId === user.id);
      const f = filter?.status ?? 'all';
      if (f === 'active') list = list.filter((o) => ACTIVE_ORDER_STATUSES.includes(o.status));
      if (f === 'delivered') list = list.filter((o) => o.status === 'delivered');
      if (f === 'cancelled') list = list.filter((o) => o.status === 'cancelled');
      const page = filter?.page ?? 1;
      const pageSize = filter?.pageSize ?? 50;
      const start = (page - 1) * pageSize;
      return {
        data: list.slice(start, start + pageSize),
        page,
        pageSize,
        total: list.length,
      };
    });
  }

  async getOrder(id: string): Promise<Order> {
    return this.withUser((_user, db) => {
      db.orders = db.orders.map(advanceOrder);
      const order = db.orders.find((o) => o.id === id || o.orderNumber === id);
      if (!order) throw new Error('Order not found.');
      return order;
    });
  }

  async cancelOrder(id: string, reason?: string): Promise<Order> {
    return this.withUser((user, db) => {
      const order = db.orders.find((o) => o.id === id);
      if (!order) throw new Error('Order not found.');
      if (order.userId !== user.id && user.role === 'customer') throw new Error('Not authorised.');
      if (!['pending', 'confirmed'].includes(order.status)) {
        throw new Error('This order can no longer be cancelled. Please call the restaurant.');
      }
      order.status = 'cancelled';
      order.cancelReason = reason ?? 'Cancelled by customer';
      order.updatedAt = new Date().toISOString();
      return order;
    });
  }

  // ------------------------------------------------------------- payments
  async createPaymentOrder(orderId: string): Promise<PaymentOrderResult> {
    const db = await this.load();
    const order = db.orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Order not found.');
    return {
      razorpayOrderId: `order_demo_${order.orderNumber}`,
      amountMinor: order.totals.grandTotalMinor,
      currency: 'INR',
      keyId: 'rzp_demo_key',
      demo: true,
    };
  }

  async verifyPayment(input: VerifyPaymentInput): Promise<Order> {
    return this.withUser((_user, db) => {
      const order = db.orders.find((o) => o.id === input.orderId);
      if (!order) throw new Error('Order not found.');
      if (order.paymentStatus === 'paid') return order;
      if (!input.razorpayPaymentId || !input.razorpayOrderId) {
        order.paymentStatus = 'failed';
        order.updatedAt = new Date().toISOString();
        throw new Error('Payment verification failed. No money was deducted — please retry.');
      }
      order.paymentStatus = 'paid';
      order.status = canTransition(order.status, 'confirmed') ? 'confirmed' : order.status;
      order.updatedAt = new Date().toISOString();
      return order;
    });
  }

  // ---------------------------------------------------------- reservations
  async getAvailability(date: string, guests: number): Promise<AvailabilityResult> {
    const db = await this.load();
    const [y, m, d] = date.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    const slots = generateSlots(undefined, dateObj);
    const active = db.reservations.filter((r) => r.date === date && r.status !== 'cancelled' && r.status !== 'rejected');
    const bookedTimes = [...new Set(active.map((r) => r.time))];
    const tables = SEED_TABLES.filter((t) => t.is_active && t.capacity >= Math.max(2, guests));
    const indoorBooked = active.filter((r) => r.seating === 'indoor').length;
    const outdoorBooked = active.filter((r) => r.seating === 'outdoor').length;
    return {
      slots,
      bookedTimes,
      tables,
      seatingFull: { indoor: indoorBooked >= 4, outdoor: outdoorBooked >= 4 },
    };
  }

  async createReservation(input: ReservationInput): Promise<Reservation> {
    return this.withUser((user, db) => {
      const conflicting = db.reservations.filter(
        (r) =>
          r.date === input.date &&
          r.time === input.time &&
          r.status !== 'cancelled' &&
          r.status !== 'rejected',
      );
      if (conflicting.length >= SEED_TABLES.length) {
        throw new Error('All tables are booked for this slot. Please pick another time.');
      }
      const usedTableNumbers = conflicting.map((r) => r.tableNumber).filter((n): n is number => Boolean(n));
      const seating = input.seating === 'any' ? 'indoor' : input.seating;
      const table =
        SEED_TABLES.find(
          (t) =>
            t.capacity >= input.guests &&
            t.seating === seating &&
            !usedTableNumbers.includes(t.tableNumber),
        ) ??
        SEED_TABLES.find((t) => t.capacity >= input.guests && !usedTableNumbers.includes(t.tableNumber));
      if (!table) {
        throw new Error(`No table fits ${input.guests} guests at ${input.time}. Try another slot.`);
      }

      const reservation: Reservation = {
        id: uid('res'),
        code: `GRV${Math.floor(10000 + Math.random() * 90000)}`,
        userId: user.id,
        customerName: user.fullName,
        customerPhone: user.phone ?? '',
        date: input.date,
        time: input.time,
        guests: input.guests,
        seating: input.seating,
        tableNumber: table.tableNumber,
        specialRequests: input.specialRequests || null,
        status: 'confirmed',
        createdAt: new Date().toISOString(),
      };
      db.reservations.unshift(reservation);
      return reservation;
    });
  }

  async getReservations(): Promise<Reservation[]> {
    return this.withUser((user, db) => db.reservations.filter((r) => r.userId === user.id));
  }

  async cancelReservation(id: string): Promise<Reservation> {
    return this.withUser((user, db) => {
      const res = db.reservations.find((r) => r.id === id);
      if (!res) throw new Error('Reservation not found.');
      if (res.userId !== user.id) throw new Error('Not authorised.');
      if (res.status === 'cancelled') return res;
      res.status = 'cancelled';
      return res;
    });
  }

  // ------------------------------------------------------------------ chat
  async sendChat(message: string): Promise<ChatMessage> {
    const db = await this.load();
    const user = db.users.find((u) => u.id === db.sessionToken) ?? null;
    const orders = user ? db.orders.filter((o) => o.userId === user.id) : [];
    const reply = buildReply(message, {
      menu: SEED_MENU,
      orders,
      isAuthenticated: Boolean(user),
      locale: user?.locale ?? 'en',
    });
    await new Promise((r) => setTimeout(r, 500)); // typing indicator
    return makeMessage('assistant', reply);
  }

  async addReview(menuItemId: string, input: { rating: number; comment: string }): Promise<void> {
    await this.withUser((user, db) => {
      db.reviews.push({
        id: uid('rev'),
        menuItemId,
        userId: user.id,
        rating: input.rating,
        comment: input.comment,
        createdAt: new Date().toISOString(),
      });
    });
  }

  // ----------------------------------------------------------------- staff
  async adminDashboard() {
    await this.load();
    const orders = this.db?.orders ?? [];
    const today = new Date().toDateString();
    const todayOrders = orders.filter((o) => new Date(o.createdAt).toDateString() === today);
    const paidOrders = orders.filter((o) => o.paymentStatus === 'paid');
    const stats = {
      totalOrders: orders.length,
      todayOrders: todayOrders.length,
      todayRevenueMinor: todayOrders
        .filter((o) => o.paymentStatus === 'paid')
        .reduce((s, o) => s + o.totals.grandTotalMinor, 0),
      pendingOrders: orders.filter((o) => o.status === 'pending').length,
      preparingOrders: orders.filter((o) => o.status === 'preparing' || o.status === 'confirmed').length,
      completedOrders: orders.filter((o) => o.status === 'delivered').length,
      cancelledOrders: orders.filter((o) => o.status === 'cancelled').length,
      avgOrderValueMinor: paidOrders.length
        ? Math.round(paidOrders.reduce((s, o) => s + o.totals.grandTotalMinor, 0) / paidOrders.length)
        : 0,
    };
    const days = [...Array(7)].map((_, i) => {
      const d = new Date(Date.now() - (6 - i) * 86400000);
      const label = d.toLocaleDateString('en-IN', { weekday: 'short' });
      const dayOrders = orders.filter((o) => new Date(o.createdAt).toDateString() === d.toDateString());
      return {
        label,
        orders: dayOrders.length,
        revenueMinor: dayOrders
          .filter((o) => o.paymentStatus === 'paid')
          .reduce((s, o) => s + o.totals.grandTotalMinor, 0),
      };
    });
    return { stats, revenue: days };
  }

  async adminListOrders(): Promise<Order[]> {
    await this.load();
    return (this.db?.orders ?? []).map(advanceOrder);
  }

  async setOrderStatus(orderId: string, status: Order['status'], cancelReason?: string): Promise<Order> {
    return this.withUser((_user, db) => {
      const order = db.orders.find((o) => o.id === orderId);
      if (!order) throw new Error('Order not found.');
      if (!canTransition(order.status, status)) {
        throw new Error(`Cannot move order from ${order.status} to ${status}.`);
      }
      order.status = status;
      if (cancelReason) order.cancelReason = cancelReason;
      order.updatedAt = new Date().toISOString();
      return order;
    });
  }
}
