import type { CartLine, Paginated, Profile } from '@grove/shared';
import type {
  AuthResult,
  AvailabilityResult,
  CheckoutValidation,
  GroveApi,
  OrdersFilter,
  PaymentOrderResult,
  PlaceOrderInput,
  VerifyPaymentInput,
} from './types';
import type { AddressInput, MenuItem, Category, ChatMessage, Coupon, Order, Reservation, ReservationInput } from '@grove/shared';

export class ApiRequestError extends Error {
  constructor(
    message: string,
    readonly code: string,
    readonly status?: number,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiRequestError';
  }
}

/** Remote provider: talks to the Express backend (see /backend). */
export class RemoteProvider implements GroveApi {
  private token: string | null = null;

  constructor(private readonly baseUrl: string) {}

  mode(): 'demo' | 'remote' {
    return 'remote';
  }

  setToken(token: string | null): void {
    this.token = token;
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    try {
      const res = await fetch(`${this.baseUrl}${path}`, {
        ...init,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}),
          ...(init.headers ?? {}),
        },
      });
      const text = await res.text();
      const body = text ? JSON.parse(text) : {};
      if (!res.ok) {
        throw new ApiRequestError(
          body?.error?.message ?? body?.message ?? `Request failed (${res.status})`,
          body?.error?.code ?? 'request_failed',
          res.status,
          body?.error?.details,
        );
      }
      return body as T;
    } catch (err) {
      if (err instanceof ApiRequestError) throw err;
      if ((err as Error).name === 'AbortError') {
        throw new ApiRequestError('The request timed out. Check your connection and retry.', 'timeout');
      }
      throw new ApiRequestError('Network unavailable. Please check your connection.', 'network');
    } finally {
      clearTimeout(timer);
    }
  }

  async login(identifier: string, password: string): Promise<AuthResult> {
    return this.request<AuthResult>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
  }

  async register(input: {
    fullName: string;
    email: string;
    phone: string;
    password: string;
  }): Promise<AuthResult> {
    return this.request<AuthResult>('/auth/register', { method: 'POST', body: JSON.stringify(input) });
  }

  async logout(): Promise<void> {
    await this.request('/auth/logout', { method: 'POST' }).catch(() => undefined);
  }

  async getProfile(): Promise<Profile> {
    return this.request<Profile>('/me');
  }

  async updateProfile(patch: Partial<Profile>): Promise<Profile> {
    return this.request<Profile>('/me', { method: 'PATCH', body: JSON.stringify(patch) });
  }

  async requestPasswordReset(email: string): Promise<void> {
    await this.request('/auth/reset-password', { method: 'POST', body: JSON.stringify({ email }) });
  }

  async requestAccountDeletion(): Promise<void> {
    await this.request('/auth/delete-request', { method: 'POST' });
  }

  async getCategories(): Promise<Category[]> {
    const res = await this.request<{ data: Category[] }>('/menu/categories');
    return res.data;
  }

  async getMenu(params?: { category?: string; search?: string }): Promise<MenuItem[]> {
    const qs = new URLSearchParams();
    if (params?.category && params.category !== 'all') qs.set('category', params.category);
    if (params?.search) qs.set('search', params.search);
    const res = await this.request<{ data: MenuItem[] }>(`/menu${qs.toString() ? `?${qs}` : ''}`);
    return res.data;
  }

  async getMenuItem(id: string): Promise<MenuItem> {
    const res = await this.request<{ data: MenuItem }>(`/menu/${id}`);
    return res.data;
  }

  async getFavourites(): Promise<MenuItem[]> {
    const res = await this.request<{ data: MenuItem[] }>('/favourites');
    return res.data;
  }

  async addFavourite(menuItemId: string): Promise<void> {
    await this.request(`/favourites/${menuItemId}`, { method: 'POST' });
  }

  async removeFavourite(menuItemId: string): Promise<void> {
    await this.request(`/favourites/${menuItemId}`, { method: 'DELETE' });
  }

  async getAddresses() {
    const res = await this.request<{ data: Awaited<ReturnType<GroveApi['getAddresses']>> }>('/addresses');
    return res.data;
  }

  async saveAddress(input: AddressInput & { id?: string }) {
    const res = await this.request<{ data: Awaited<ReturnType<GroveApi['saveAddress']>> }>(
      input.id ? `/addresses/${input.id}` : '/addresses',
      { method: input.id ? 'PATCH' : 'POST', body: JSON.stringify(input) },
    );
    return res.data;
  }

  async deleteAddress(id: string): Promise<void> {
    await this.request(`/addresses/${id}`, { method: 'DELETE' });
  }

  async getPublicCoupons(): Promise<Coupon[]> {
    const res = await this.request<{ data: Coupon[] }>('/coupons');
    return res.data;
  }

  async validateCoupon(code: string, subtotalMinor: number): Promise<Coupon> {
    const res = await this.request<{ data: Coupon }>('/checkout/validate', {
      method: 'POST',
      body: JSON.stringify({ couponCode: code, subtotalMinor }),
    });
    return res.data;
  }

  async validateCart(lines: CartLine[]): Promise<CheckoutValidation> {
    return this.request<CheckoutValidation>('/checkout/reprice', {
      method: 'POST',
      body: JSON.stringify({ lines }),
    });
  }

  async placeOrder(input: PlaceOrderInput): Promise<Order> {
    const res = await this.request<{ data: Order }>('/orders', {
      method: 'POST',
      body: JSON.stringify(input),
      headers: { 'Idempotency-Key': input.idempotencyKey },
    });
    return res.data;
  }

  async getOrders(filter?: OrdersFilter): Promise<Paginated<Order>> {
    const qs = new URLSearchParams();
    if (filter?.status && filter.status !== 'all') qs.set('status', filter.status);
    qs.set('page', String(filter?.page ?? 1));
    qs.set('pageSize', String(filter?.pageSize ?? 50));
    return this.request<Paginated<Order>>(`/orders?${qs}`);
  }

  async getOrder(id: string): Promise<Order> {
    const res = await this.request<{ data: Order }>(`/orders/${id}`);
    return res.data;
  }

  async cancelOrder(id: string, reason?: string): Promise<Order> {
    const res = await this.request<{ data: Order }>(`/orders/${id}/cancel`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
    return res.data;
  }

  async createPaymentOrder(orderId: string): Promise<PaymentOrderResult> {
    return this.request<PaymentOrderResult>('/payments/create-order', {
      method: 'POST',
      body: JSON.stringify({ orderId }),
    });
  }

  async verifyPayment(input: VerifyPaymentInput): Promise<Order> {
    const res = await this.request<{ data: Order }>('/payments/verify', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    return res.data;
  }

  async getAvailability(date: string, guests: number): Promise<AvailabilityResult> {
    return this.request<AvailabilityResult>(
      `/reservations/availability?date=${date}&guests=${guests}`,
    );
  }

  async createReservation(input: ReservationInput): Promise<Reservation> {
    const res = await this.request<{ data: Reservation }>('/reservations', {
      method: 'POST',
      body: JSON.stringify(input),
    });
    return res.data;
  }

  async getReservations(): Promise<Reservation[]> {
    const res = await this.request<{ data: Reservation[] }>('/reservations');
    return res.data;
  }

  async cancelReservation(id: string): Promise<Reservation> {
    const res = await this.request<{ data: Reservation }>(`/reservations/${id}/cancel`, {
      method: 'POST',
    });
    return res.data;
  }

  async sendChat(message: string): Promise<ChatMessage> {
    return this.request<ChatMessage>('/chat/messages', {
      method: 'POST',
      body: JSON.stringify({ message }),
    });
  }

  async addReview(menuItemId: string, input: { rating: number; comment: string }): Promise<void> {
    await this.request(`/menu/${menuItemId}/reviews`, { method: 'POST', body: JSON.stringify(input) });
  }

  async adminDashboard() {
    return this.request('/admin/dashboard');
  }

  async adminListOrders(): Promise<Order[]> {
    const res = await this.request<{ data: Order[] }>('/admin/orders');
    return res.data;
  }

  async setOrderStatus(orderId: string, status: Order['status'], cancelReason?: string): Promise<Order> {
    const res = await this.request<{ data: Order }>(`/admin/orders/${orderId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, cancelReason }),
    });
    return res.data;
  }
}
