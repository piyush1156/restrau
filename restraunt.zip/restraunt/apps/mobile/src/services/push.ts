import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';

/**
 * Requests notification permission and returns an Expo push token.
 * Returns null when permission is denied, the EAS project is not configured, or
 * the runtime cannot issue tokens (e.g. Expo Go on Android for remote push).
 * Callers must treat null as "no push", never as an error the customer sees.
 */
export const registerForPush = async (): Promise<string | null> => {
  try {
    const current = await Notifications.getPermissionsAsync();
    let status = current.status;
    if (status !== 'granted') {
      const requested = await Notifications.requestPermissionsAsync();
      status = requested.status;
    }
    if (status !== 'granted') return null;

    const projectId = (Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined)?.eas
      ?.projectId;
    if (!projectId || projectId.startsWith('REPLACE')) return null;

    const token = await Notifications.getExpoPushTokenAsync({ projectId });
    return token.data ?? null;
  } catch {
    return null;
  }
};
