import type {
  Address,
  AddressInput,
  Category,
  ChatMessage,
  CheckoutInput,
  Coupon,
  MenuItem,
  Order,
  Paginated,
  Profile,
  Reservation,
  ReservationInput,
  RestaurantTable,
  Role,
} from '@grove/shared';

export interface AuthResult {
  profile: Profile;
  token: string;
  isDemo?: boolean;
}

export interface CheckoutValidation {
  /** Lines repriced against the live menu; drop lines for sold-out dishes. */
  lines: import('@grove/shared').CartLine[];
  removed: { key: string; name: string; reason: 'unavailable' | 'price_changed' | 'removed_from_menu' }[];
}

export interface PlaceOrderInput {
  checkout: CheckoutInput;
  lines: import('@grove/shared').CartLine[];
  totals: import('@grove/shared').OrderTotals;
  /** Client-generated idempotency key; duplicate submissions return the same order. */
  idempotencyKey: string;
  couponCode: string | null;
}

export interface PaymentOrderResult {
  razorpayOrderId: string;
  amountMinor: number;
  currency: string;
  keyId: string;
  demo: boolean;
}

export interface VerifyPaymentInput {
  orderId: string;
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}

export interface AvailabilityResult {
  slots: string[];
  bookedTimes: string[];
  tables: RestaurantTable[];
  seatingFull: Record<'indoor' | 'outdoor', boolean>;
}

export interface OrdersFilter {
  status?: 'active' | 'delivered' | 'cancelled' | 'all';
  page?: number;
  pageSize?: number;
}

export interface AdminSummary {
  stats: import('@grove/shared').DashboardStats;
  revenue: import('@grove/shared').RevenuePoint[];
}

export interface GroveApi {
  mode(): 'demo' | 'remote';
  setToken(token: string | null): void;

  // auth
  login(identifier: string, password: string): Promise<AuthResult>;
  register(input: { fullName: string; email: string; phone: string; password: string }): Promise<AuthResult>;
  logout(): Promise<void>;
  getProfile(): Promise<Profile>;
  updateProfile(patch: Partial<Profile>): Promise<Profile>;
  requestPasswordReset(email: string): Promise<void>;
  requestAccountDeletion(): Promise<void>;

  // menu
  getCategories(): Promise<Category[]>;
  getMenu(params?: { category?: string; search?: string }): Promise<MenuItem[]>;
  getMenuItem(id: string): Promise<MenuItem>;

  // favourites
  getFavourites(): Promise<MenuItem[]>;
  addFavourite(menuItemId: string): Promise<void>;
  removeFavourite(menuItemId: string): Promise<void>;

  // addresses
  getAddresses(): Promise<Address[]>;
  saveAddress(input: AddressInput & { id?: string }): Promise<Address>;
  deleteAddress(id: string): Promise<void>;

  // coupons
  getPublicCoupons(): Promise<Coupon[]>;
  validateCoupon(code: string, subtotalMinor: number): Promise<Coupon>;

  // orders
  validateCart(lines: import('@grove/shared').CartLine[]): Promise<CheckoutValidation>;
  placeOrder(input: PlaceOrderInput): Promise<Order>;
  getOrders(filter?: OrdersFilter): Promise<Paginated<Order>>;
  getOrder(id: string): Promise<Order>;
  cancelOrder(id: string, reason?: string): Promise<Order>;

  // payments
  createPaymentOrder(orderId: string): Promise<PaymentOrderResult>;
  verifyPayment(input: VerifyPaymentInput): Promise<Order>;

  // reservations
  getAvailability(date: string, guests: number): Promise<AvailabilityResult>;
  createReservation(input: ReservationInput): Promise<Reservation>;
  getReservations(): Promise<Reservation[]>;
  cancelReservation(id: string): Promise<Reservation>;

  // chat + reviews
  sendChat(message: string): Promise<ChatMessage>;
  addReview(menuItemId: string, input: { rating: number; comment: string }): Promise<void>;

  // staff
  adminDashboard(): Promise<AdminSummary>;
  adminListOrders(): Promise<Order[]>;
  setOrderStatus(orderId: string, status: Order['status'], cancelReason?: string): Promise<Order>;
}
