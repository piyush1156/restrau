import type { ChatMessage, MenuItem, Order, RestaurantTable } from '@grove/shared';
import { formatMinor } from '@grove/shared';
import {
  SEED_CATEGORIES,
  SEED_COUPONS,
  SEED_MENU,
  SEED_OPENING_HOURS,
  RESTAURANT_PHONE,
} from '@/data/seed';

/**
 * Rule-based restaurant assistant.
 * Used when no AI key is configured (and as automatic fallback on error).
 * It only answers from approved restaurant data: menu, hours, policies and —
 * for private order details — orders passed in by the caller after auth checks.
 * It never invents order status, prices, reservations or payment results.
 */

export interface ChatContext {
  menu?: MenuItem[];
  orders?: Order[];
  tables?: RestaurantTable[];
  locale?: 'en' | 'hi';
  isAuthenticated?: boolean;
}

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const includesAny = (text: string, words: string[]): boolean => words.some((w) => text.includes(w));

const listItems = (items: MenuItem[], max = 4): string =>
  items
    .slice(0, max)
    .map((m) => `• ${m.name} — ${formatMinor(m.discountedPriceMinor ?? m.priceMinor)} (★ ${m.rating})`)
    .join('\n');

export const buildReply = (message: string, ctx: ChatContext = {}): string => {
  const text = message.trim().toLowerCase();
  const menu = ctx.menu?.length ? ctx.menu : SEED_MENU;
  const hi = ctx.locale === 'hi';

  // ---- language ----
  if (includesAny(text, ['hindi me', 'हिंदी', 'hindi bolo'])) {
    return 'ज़रूर! अब मैं हिंदी में जवाब दूँगा। आज क्या जानना चाहेंगे — मेनू, ऑर्डर या टेबुकिंग?';
  }
  if (includesAny(text, ['in english', 'english me'])) {
    return 'Sure! Ask me about today’s specials, recommendations, your order, or a table booking.';
  }

  // ---- order tracking (private data: only when authenticated) ----
  if (includesAny(text, ['track', 'order status', 'ऑर्डर', 'order kahan', 'where is my order'])) {
    if (!ctx.isAuthenticated) {
      return 'Please sign in so I can show your orders securely. I never show another customer’s order details.';
    }
    const orders = ctx.orders ?? [];
    if (orders.length === 0) {
      return hi
        ? 'आपका कोई ऑर्डर नहीं मिला। मेनू से कुछ ऑर्डर करना चाहेंगे?'
        : 'You have no orders yet. Would you like to browse the menu and place one?';
    }
    const latest = [...orders].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))[0];
    return hi
      ? `आपका नवीनतम ऑर्डर #${latest.orderNumber} — स्थिति: ${latest.status}। ट्रैक करने के लिए Orders टैब खोलें।`
      : `Your latest order #${latest.orderNumber} is currently "${latest.status}". Open the Orders tab for the full timeline.`;
  }

  // ---- booking ----
  if (includesAny(text, ['book', 'table', 'reservation', 'टेबल', 'बुक'])) {
    const day = DAYS[new Date().getDay()];
    const hours = SEED_OPENING_HOURS[new Date().getDay()];
    return hi
      ? `टेबल बुक करने के लिए Table Booking स्क्रीन खोलें। आज (${day}) टाइमिंग: ${hours.opensAt}–${hours.closesAt}। समूह 20+ लोगों के लिए कॉल करें: ${RESTAURANT_PHONE}`
      : `Open the Table Booking screen to reserve a table. Today (${day}) we're open ${hours.opensAt}–${hours.closesAt}. For parties over 20, please call ${RESTAURANT_PHONE}.`;
  }

  // ---- specials ----
  if (includesAny(text, ['special', 'today', 'offer', 'deal', 'आज', 'खास'])) {
    const specials = menu.filter((m) => m.isSpecial && m.isAvailable);
    const coupons = SEED_COUPONS.filter((c) => c.isActive && new Date(c.expiresAt) > new Date());
    const couponLine = coupons.length
      ? `\n\nOffers: ${coupons.map((c) => `${c.code} (${c.description})`).join(', ')}`
      : '';
    return `${hi ? 'आज की खास डिशेज:' : 'Today’s specials:'}\n${listItems(specials)}${couponLine}`;
  }

  // ---- vegetarian ----
  if (includesAny(text, ['veg', 'vegetarian', 'शाकाहारी'])) {
    const veg = menu.filter((m) => m.isVeg && m.isAvailable);
    return `${hi ? 'शाकाहारी व्यंजन:' : 'Vegetarian dishes:'}\n${listItems(veg, 6)}`;
  }

  // ---- recommendation ----
  if (includesAny(text, ['recommend', 'suggest', 'what should i eat', 'क्या खाऊँ', 'बताओ'])) {
    const top = [...menu]
      .filter((m) => m.isAvailable)
      .sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);
    const pick = top[0];
    const second = top[1];
    return hi
      ? `आपके लिए सुझाव: ${pick.name} (★ ${pick.rating}) — ${formatMinor(pick.discountedPriceMinor ?? pick.priceMinor)}। एक और विकल्प: ${second.name}।`
      : `I'd go with ${pick.name} — ★ ${pick.rating}, ${formatMinor(pick.discountedPriceMinor ?? pick.priceMinor)}. Another great pick: ${second.name}.`;
  }

  // ---- allergen / ingredient ----
  if (includesAny(text, ['allerg', 'ingredient', 'contain', 'spicy', 'allergy'])) {
    const dish = menu.find((m) => text.includes(m.name.toLowerCase().split(' ')[0].toLowerCase()));
    if (dish) {
      const allergens = dish.allergens.length ? dish.allergens.join(', ') : 'none listed';
      return `${dish.name} — ${dish.description}\nIngredients: ${dish.ingredients.join(', ')}.\nAllergens: ${allergens}.`;
    }
    return 'Which dish should I check? Tell me the dish name and I’ll share its ingredients and allergens.';
  }

  // ---- hours ----
  if (includesAny(text, ['hours', 'open', 'timing', 'close', 'समय', 'खुल'])) {
    const today = SEED_OPENING_HOURS[new Date().getDay()];
    return today.isClosed
      ? 'We’re closed today. Tomorrow we open at 9 AM.'
      : `Today we’re open from ${today.opensAt} to ${today.closesAt}. Kitchen takes last orders 45 minutes before closing.`;
  }

  // ---- contact ----
  if (includesAny(text, ['contact', 'support', 'human', 'call', 'help', 'शिकायत'])) {
    return `You can reach our team at ${RESTAURANT_PHONE} (9 AM–11 PM), or use Help & Support in Profile. I can also continue here if I couldn’t solve it.`;
  }

  // ---- search dish by name ----
  const found = menu.find((m) => text.includes(m.name.toLowerCase()));
  if (found) {
    const price = formatMinor(found.discountedPriceMinor ?? found.priceMinor);
    return `${found.name} — ${price}, ★ ${found.rating} (${found.reviewCount} reviews).\n${found.description}\n${found.isAvailable ? 'Available now ✅' : 'Currently sold out.'}`;
  }

  // ---- default ----
  const suggestions = hi
    ? ['आज की खास डिशेज', 'शाकाहारी विकल्प', 'मेरा ऑर्डर ट्रैक करें', 'टेबल बुक करें']
    : ['Show me today’s specials', 'Recommend a dish', 'Track my order', 'Book a table'];
  return `${hi ? 'मैं मेनू, ऑफर, ऑर्डर स्टेटस और टेबुकिंग में मदद कर सकता हूँ। कृपया चुनें:' : 'I can help with menu, offers, order status and bookings. Try one of these:'}\n${suggestions
    .map((s) => `• ${s}`)
    .join('\n')}`;
};

export const SUGGESTED_PROMPTS: { en: string[]; hi: string[] } = {
  en: [
    'Show me today’s specials',
    'Recommend a dish for me',
    'Track my order',
    'Book a table',
    'Show vegetarian dishes',
    'Explain an ingredient or allergen',
    'Contact restaurant support',
  ],
  hi: [
    'आज की खास डिशेज',
    'मेरे लिए एक डिश बताओ',
    'मेरा ऑर्डर ट्रैक करें',
    'टेबल बुक करें',
    'शाकाहारी व्यंजन दिखाओ',
    'सामग्री या एलर्जेन बताओ',
    'रेस्टोरेंट सपोर्ट से बात करें',
  ],
};

export const makeMessage = (role: ChatMessage['role'], text: string): ChatMessage => ({
  id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  role,
  text,
  createdAt: new Date().toISOString(),
});
