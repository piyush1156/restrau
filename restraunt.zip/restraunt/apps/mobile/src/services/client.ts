import { DemoProvider } from './demo';
import { RemoteProvider } from './remote';
import type { GroveApi } from './types';

const MODE = process.env.EXPO_PUBLIC_API_MODE ?? 'auto';
const RAW_BASE = (process.env.EXPO_PUBLIC_API_URL ?? '').replace(/\/+$/, '');

const normalize = (url: string): string => (url.endsWith('/api') ? url : url);

/**
 * Chooses the backend at startup:
 *   EXPO_PUBLIC_API_MODE=demo   → always the built-in offline demo
 *   EXPO_PUBLIC_API_MODE=remote → always the remote API (fails loudly if down)
 *   EXPO_PUBLIC_API_MODE=auto   → remote API when /health answers, demo otherwise
 */
class Client implements GroveApi {
  private readonly demo = new DemoProvider();
  private readonly remote: RemoteProvider | null = RAW_BASE ? new RemoteProvider(normalize(RAW_BASE)) : null;
  private impl: GroveApi;
  private ready: Promise<void>;

  constructor() {
    this.impl = this.remote && MODE === 'remote' ? this.remote : this.demo;
    this.ready = this.detect();
  }

  private async detect(): Promise<void> {
    if (MODE === 'demo' || !this.remote) {
      this.impl = this.demo;
      return;
    }
    if (MODE === 'remote') {
      this.impl = this.remote;
      return;
    }
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2500);
      const res = await fetch(`${RAW_BASE}/health`, { signal: controller.signal });
      clearTimeout(timer);
      this.impl = res.ok ? this.remote : this.demo;
    } catch {
      this.impl = this.demo;
    }
  }

  private async api(): Promise<GroveApi> {
    await this.ready;
    return this.impl;
  }

  mode(): 'demo' | 'remote' {
    return this.impl.mode();
  }

  setToken(token: string | null): void {
    this.demo.setToken(token);
    this.remote?.setToken(token);
  }

  async login(...args: Parameters<GroveApi['login']>) {
    const res = await (await this.api()).login(...args);
    this.setToken(res.token);
    return res;
  }

  async register(...args: Parameters<GroveApi['register']>) {
    const res = await (await this.api()).register(...args);
    this.setToken(res.token);
    return res;
  }

  async logout(): Promise<void> {
    await (await this.api()).logout();
    this.setToken(null);
  }

  async getProfile() {
    return (await this.api()).getProfile();
  }
  async updateProfile(patch: Parameters<GroveApi['updateProfile']>[0]) {
    return (await this.api()).updateProfile(patch);
  }
  async requestPasswordReset(email: string) {
    return (await this.api()).requestPasswordReset(email);
  }
  async requestAccountDeletion() {
    return (await this.api()).requestAccountDeletion();
  }
  async getCategories() {
    return (await this.api()).getCategories();
  }
  async getMenu(params?: Parameters<GroveApi['getMenu']>[0]) {
    return (await this.api()).getMenu(params);
  }
  async getMenuItem(id: string) {
    return (await this.api()).getMenuItem(id);
  }
  async getFavourites() {
    return (await this.api()).getFavourites();
  }
  async addFavourite(id: string) {
    return (await this.api()).addFavourite(id);
  }
  async removeFavourite(id: string) {
    return (await this.api()).removeFavourite(id);
  }
  async getAddresses() {
    return (await this.api()).getAddresses();
  }
  async saveAddress(input: Parameters<GroveApi['saveAddress']>[0]) {
    return (await this.api()).saveAddress(input);
  }
  async deleteAddress(id: string) {
    return (await this.api()).deleteAddress(id);
  }
  async getPublicCoupons() {
    return (await this.api()).getPublicCoupons();
  }
  async validateCoupon(code: string, subtotalMinor: number) {
    return (await this.api()).validateCoupon(code, subtotalMinor);
  }
  async validateCart(lines: Parameters<GroveApi['validateCart']>[0]) {
    return (await this.api()).validateCart(lines);
  }
  async placeOrder(input: Parameters<GroveApi['placeOrder']>[0]) {
    return (await this.api()).placeOrder(input);
  }
  async getOrders(filter?: Parameters<GroveApi['getOrders']>[0]) {
    return (await this.api()).getOrders(filter);
  }
  async getOrder(id: string) {
    return (await this.api()).getOrder(id);
  }
  async cancelOrder(id: string, reason?: string) {
    return (await this.api()).cancelOrder(id, reason);
  }
  async createPaymentOrder(orderId: string) {
    return (await this.api()).createPaymentOrder(orderId);
  }
  async verifyPayment(input: Parameters<GroveApi['verifyPayment']>[0]) {
    return (await this.api()).verifyPayment(input);
  }
  async getAvailability(date: string, guests: number) {
    return (await this.api()).getAvailability(date, guests);
  }
  async createReservation(input: Parameters<GroveApi['createReservation']>[0]) {
    return (await this.api()).createReservation(input);
  }
  async getReservations() {
    return (await this.api()).getReservations();
  }
  async cancelReservation(id: string) {
    return (await this.api()).cancelReservation(id);
  }
  async sendChat(message: string) {
    return (await this.api()).sendChat(message);
  }
  async addReview(menuItemId: string, input: { rating: number; comment: string }) {
    return (await this.api()).addReview(menuItemId, input);
  }
  async adminDashboard() {
    return (await this.api()).adminDashboard();
  }
  async adminListOrders() {
    return (await this.api()).adminListOrders();
  }
  async setOrderStatus(orderId: string, status: OrderStatus, cancelReason?: string) {
    return (await this.api()).setOrderStatus(orderId, status, cancelReason);
  }
}

type OrderStatus = import('@grove/shared').OrderStatus;

export const groveApi = new Client();
export { ApiRequestError } from './remote';
