import { Alert, Platform } from 'react-native';
import type { PaymentOrderResult } from './types';

const PUBLIC_KEY = process.env.EXPO_PUBLIC_RAZORPAY_KEY_ID ?? '';

export interface PaymentSuccess {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}

export class PaymentCancelled extends Error {
  constructor() {
    super('Payment was cancelled.');
    this.name = 'PaymentCancelled';
  }
}

interface RazorpayOptions {
  description: string;
  image?: string;
  currency: string;
  key: string;
  amount: number;
  name: string;
  order_id: string;
  prefill?: { email?: string; contact?: string; name?: string };
  theme?: { color?: string };
}

/**
 * Opens Razorpay Checkout and returns IDs that are ALWAYS verified server-side.
 * - Real key + native module → real Checkout.
 * - Otherwise → an explicit demo sheet (never pretends a real charge happened).
 */
export const openRazorpayCheckout = async (
  paymentOrder: PaymentOrderResult,
  customer: { name: string; email?: string; contact?: string },
): Promise<PaymentSuccess> => {
  const useRealCheckout =
    !paymentOrder.demo && paymentOrder.keyId?.startsWith('rzp_') && paymentOrder.keyId !== 'rzp_demo_key';

  if (useRealCheckout) {
    try {
      // Loaded lazily so the app also runs in Expo Go without the native module.
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const Razorpay = require('react-native-razorpay').default;
      const options: RazorpayOptions = {
        description: 'The Grove Restaurant & Cafe order payment',
        currency: paymentOrder.currency,
        key: paymentOrder.keyId,
        amount: paymentOrder.amountMinor,
        name: 'The Grove',
        order_id: paymentOrder.razorpayOrderId,
        prefill: {
          name: customer.name,
          email: customer.email,
          contact: customer.contact,
        },
        theme: { color: '#FF7900' },
      };
      const res = await Razorpay.open(options);
      return {
        razorpayOrderId: paymentOrder.razorpayOrderId,
        razorpayPaymentId: res?.razorpay_payment_id ?? '',
        razorpaySignature: res?.razorpay_signature ?? '',
      };
    } catch (err: unknown) {
      const code = (err as { code?: number })?.code;
      if (code === 0) throw new PaymentCancelled();
      throw new Error(
        `Could not open Razorpay (${(err as Error)?.message ?? 'unknown error'}). You can retry or choose Cash on Delivery.`,
      );
    }
  }

  // ---- Demo sheet: clearly labelled, no real money moves. ----
  return new Promise<PaymentSuccess>((resolve, reject) => {
    const amountText = `₹${Math.round(paymentOrder.amountMinor / 100)}`;
    Alert.alert(
      'Demo payment (test mode)',
      `Razorpay test checkout for ${amountText}.\n\nNo real money is charged. In production this opens the real Razorpay sheet (UPI, Card, NetBanking).`,
      [
        {
          text: 'Simulate success',
          onPress: () =>
            resolve({
              razorpayOrderId: paymentOrder.razorpayOrderId,
              razorpayPaymentId: `pay_demo_${Date.now().toString(36)}`,
              razorpaySignature: `sig_demo_${Platform.OS}_${Date.now().toString(36)}`,
            }),
        },
        { text: 'Cancel payment', style: 'cancel', onPress: () => reject(new PaymentCancelled()) },
      ],
      { cancelable: true, onDismiss: () => reject(new PaymentCancelled()) },
    );
  });
};
