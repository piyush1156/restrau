import { Colors, Radius, Shadow, Spacing } from '@grove/shared';

export { Colors, Radius, Shadow, Spacing };

/** Typography scale (pt). System font keeps bundles small and rendering crisp. */
export const Typography = {
  display: { fontSize: 30, fontWeight: '700' as const, color: Colors.textPrimary, letterSpacing: 0.2 },
  h1: { fontSize: 24, fontWeight: '700' as const, color: Colors.textPrimary },
  h2: { fontSize: 20, fontWeight: '700' as const, color: Colors.textPrimary },
  h3: { fontSize: 17, fontWeight: '600' as const, color: Colors.textPrimary },
  body: { fontSize: 15, fontWeight: '400' as const, color: Colors.textPrimary },
  bodyBold: { fontSize: 15, fontWeight: '600' as const, color: Colors.textPrimary },
  secondary: { fontSize: 13, fontWeight: '400' as const, color: Colors.textSecondary },
  caption: { fontSize: 12, fontWeight: '400' as const, color: Colors.textSecondary },
  price: { fontSize: 16, fontWeight: '700' as const, color: Colors.primary },
  button: { fontSize: 16, fontWeight: '700' as const, color: Colors.white },
} as const;
