import { describe, expect, it } from 'vitest';
import { addDays, formatSlot, money, pluralize } from '../utils/format';

describe('money', () => {
  it('formats paise in Indian grouping', () => {
    expect(money(24900)).toBe('₹249');
    expect(money(88750)).toBe('₹887.50');
    expect(money(0)).toBe('₹0');
  });
});

describe('formatSlot', () => {
  it('renders 24h slots as 12h labels', () => {
    expect(formatSlot('09:00')).toBe('9:00 AM');
    expect(formatSlot('12:00')).toBe('12:00 PM');
    expect(formatSlot('13:30')).toBe('1:30 PM');
    expect(formatSlot('00:15')).toBe('12:15 AM');
    expect(formatSlot('23:45')).toBe('11:45 PM');
  });
});

describe('date helpers', () => {
  it('adds days without mutating the input', () => {
    const base = new Date(2026, 0, 31, 12, 0, 0);
    const next = addDays(base, 1);
    expect(next.getMonth()).toBe(1);
    expect(next.getDate()).toBe(1);
    expect(base.getMonth()).toBe(0);
    expect(base.getDate()).toBe(31);
  });
});

describe('pluralize', () => {
  it('handles singular and plural', () => {
    expect(pluralize(1, 'guest')).toBe('1 guest');
    expect(pluralize(3, 'guest')).toBe('3 guests');
  });
});
