import { ActivityIndicator, Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

interface Props {
  label: string;
  onPress?: () => void;
  variant?: Variant;
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  accessibilityHint?: string;
}

export const AppButton = ({
  label,
  onPress,
  variant = 'primary',
  loading = false,
  disabled = false,
  icon,
  style,
  accessibilityHint,
}: Props) => {
  const isDisabled = disabled || loading;
  const palette: Record<Variant, { bg: string; fg: string; border?: string }> = {
    primary: { bg: Colors.primary, fg: Colors.white },
    secondary: { bg: Colors.primarySoft, fg: Colors.primary },
    ghost: { bg: Colors.white, fg: Colors.textPrimary, border: Colors.border },
    danger: { bg: Colors.dangerSoft, fg: Colors.danger },
  };
  const p = palette[variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      style={({ pressed }) => [
        styles.base,
        variant === 'primary' && Shadow.floating,
        {
          backgroundColor: isDisabled ? Colors.disabled : p.bg,
          borderColor: p.border ?? 'transparent',
          opacity: pressed && !isDisabled ? 0.92 : 1,
          transform: [{ scale: pressed && !isDisabled ? 0.99 : 1 }],
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={p.fg} />
      ) : (
        <View style={styles.row}>
          {icon}
          <Text style={[styles.label, { color: isDisabled ? Colors.textMuted : p.fg }]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  base: {
    minHeight: 52,
    borderRadius: Radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    borderWidth: 1,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  label: { ...Typography.button },
});
