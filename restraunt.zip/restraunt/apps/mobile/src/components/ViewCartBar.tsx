import { ChevronRight, ShoppingBag } from 'lucide-react-native';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { CartLine, Coupon, RestaurantConfig } from '@grove/shared';
import { computeTotals } from '@grove/shared';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { money } from '@/utils/format';

interface Props {
  lines: CartLine[];
  orderType: 'delivery' | 'takeaway' | 'dine_in';
  config: RestaurantConfig;
  coupon?: Coupon | null;
  onPress: () => void;
  label?: string;
}

/** Sticky bottom bar: shows live cart total and routes to cart/checkout. */
export const ViewCartBar = ({ lines, orderType, config, coupon, onPress, label = 'View Cart' }: Props) => {
  const insets = useSafeAreaInsets();
  if (lines.length === 0) return null;

  const totals = computeTotals({ lines, coupon: coupon ?? null, config, orderType });
  const count = lines.reduce((s, l) => s + l.quantity, 0);

  return (
    <View style={[styles.wrap, { paddingBottom: Math.max(insets.bottom, 10) }]} pointerEvents="box-none">
      <Pressable
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={`${label}, ${count} items, total ${money(totals.grandTotalMinor)}`}
        style={({ pressed }) => [styles.bar, pressed && { transform: [{ scale: 0.99 }] }]}
      >
        <View style={styles.badge}>
          <ShoppingBag size={18} color={Colors.white} />
          <View style={styles.countPill}>
            <Text style={styles.countText}>{count}</Text>
          </View>
        </View>
        <Text style={styles.label}>{label}</Text>
        <View style={styles.right}>
          <Text style={styles.total}>{money(totals.grandTotalMinor)}</Text>
          <ChevronRight size={20} color={Colors.white} />
        </View>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primary,
    borderRadius: Radius.pill,
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
    ...Shadow.floating,
  },
  badge: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.22)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  countPill: {
    position: 'absolute',
    top: -6,
    right: -8,
    backgroundColor: Colors.white,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  countText: { fontSize: 11, fontWeight: '800', color: Colors.primary },
  label: { ...Typography.button, flex: 1 },
  right: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  total: { ...Typography.button, fontSize: 17 },
});
