import { Eye, EyeOff, AlertCircle } from 'lucide-react-native';
import { useState, type ComponentProps, type ReactNode } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, type TextInputProps } from 'react-native';
import { Colors, Radius, Typography } from '@/constants/theme';

interface Props extends Omit<TextInputProps, 'style'> {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: ReactNode;
  containerStyle?: ComponentProps<typeof View>['style'];
}

export const TextField = ({ label, error, hint, leftIcon, secureTextEntry, ...rest }: Props) => {
  const [hidden, setHidden] = useState(Boolean(secureTextEntry));
  const [focused, setFocused] = useState(false);

  return (
    <View style={styles.wrap}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <View
        style={[
          styles.field,
          focused && styles.focused,
          Boolean(error) && styles.errored,
        ]}
      >
        {leftIcon ? <View style={styles.left}>{leftIcon}</View> : null}
        <TextInput
          {...rest}
          secureTextEntry={hidden}
          onFocus={(e) => {
            setFocused(true);
            rest.onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            rest.onBlur?.(e);
          }}
          placeholderTextColor={Colors.textMuted}
          style={styles.input}
          accessibilityLabel={rest.placeholder ?? label}
        />
        {secureTextEntry ? (
          <Pressable
            onPress={() => setHidden((h) => !h)}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel={hidden ? 'Show password' : 'Hide password'}
          >
            {hidden ? <Eye size={20} color={Colors.textSecondary} /> : <EyeOff size={20} color={Colors.textSecondary} />}
          </Pressable>
        ) : null}
      </View>
      {error ? (
        <View style={styles.msgRow}>
          <AlertCircle size={14} color={Colors.danger} />
          <Text style={styles.error}>{error}</Text>
        </View>
      ) : hint ? (
        <Text style={styles.hint}>{hint}</Text>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: { marginBottom: 16 },
  label: { ...Typography.secondary, marginBottom: 6, fontWeight: '600', color: Colors.textPrimary },
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 52,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.backgroundAlt,
    paddingHorizontal: 14,
    gap: 8,
  },
  focused: { borderColor: Colors.primary, backgroundColor: Colors.white },
  errored: { borderColor: Colors.danger, backgroundColor: Colors.dangerSoft },
  left: { marginRight: 2 },
  input: { flex: 1, fontSize: 15, color: Colors.textPrimary, paddingVertical: 12 },
  msgRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  error: { ...Typography.caption, color: Colors.danger },
  hint: { ...Typography.caption, marginTop: 6 },
});
