import { Plus, Check } from 'lucide-react-native';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { MenuItem } from '@grove/shared';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { money } from '@/utils/format';
import { Price, RatingPill, VegBadge } from './Bits';
import { SafeImage } from './SafeImage';

interface Props {
  item: MenuItem;
  onPress: () => void;
  onAdd: () => void;
  variant?: 'row' | 'grid';
  inCart?: boolean;
  style?: object;
}

export const FoodCard = ({ item, onPress, onAdd, variant = 'row', inCart = false, style }: Props) => {
  const price = item.discountedPriceMinor ?? item.priceMinor;
  const soldOut = !item.isAvailable;

  if (variant === 'grid') {
    return (
      <Pressable
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={`${item.name}, ${money(price)}`}
        style={({ pressed }) => [styles.grid, pressed && styles.pressed, style]}
      >
        <View>
          <SafeImage uri={item.imageUrl} label={item.name} style={styles.gridImage} rounded={Radius.lg} />
          <View style={styles.vegOnImage}>
            <VegBadge isVeg={item.isVeg} />
          </View>
          {soldOut ? <View style={styles.soldOut}><Text style={styles.soldOutText}>Sold out</Text></View> : null}
        </View>
        <Text style={styles.gridName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.gridDesc} numberOfLines={2}>{item.description}</Text>
        <View style={styles.gridFooter}>
          <View>
            <Price value={money(price)} size="sm" />
            <View style={{ marginTop: 4 }}>
              <RatingPill rating={item.rating} />
            </View>
          </View>
          <Pressable
            onPress={onAdd}
            disabled={soldOut}
            accessibilityRole="button"
            accessibilityLabel={`Add ${item.name} to cart`}
            style={({ pressed }) => [
              styles.addBtn,
              inCart && styles.addBtnActive,
              soldOut && styles.addBtnDisabled,
              pressed && { transform: [{ scale: 0.94 }] },
            ]}
          >
            {inCart ? <Check size={18} color={Colors.white} /> : <Plus size={18} color={soldOut ? Colors.textMuted : Colors.primary} />}
          </Pressable>
        </View>
      </Pressable>
    );
  }

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${item.name}, ${money(price)}`}
      style={({ pressed }) => [styles.row, pressed && styles.pressed, style]}
    >
      <View>
        <SafeImage uri={item.imageUrl} label={item.name} style={styles.rowImage} rounded={Radius.lg} />
        {soldOut ? <View style={styles.soldOut}><Text style={styles.soldOutText}>Sold out</Text></View> : null}
      </View>
      <View style={styles.rowBody}>
        <View style={styles.rowTitleLine}>
          <VegBadge isVeg={item.isVeg} />
          <Text style={styles.rowName} numberOfLines={1}>{item.name}</Text>
        </View>
        <Text style={styles.rowDesc} numberOfLines={2}>{item.description}</Text>
        <View style={styles.rowFooter}>
          <View style={styles.rowPriceLine}>
            <Price value={money(price)} />
            {item.discountedPriceMinor ? (
              <Price value={money(item.priceMinor)} strike />
            ) : null}
          </View>
          <View style={styles.rowMeta}>
            <RatingPill rating={item.rating} />
            <Pressable
              onPress={onAdd}
              disabled={soldOut}
              accessibilityRole="button"
              accessibilityLabel={`Add ${item.name} to cart`}
              style={({ pressed }) => [
                styles.addBtn,
                inCart && styles.addBtnActive,
                soldOut && styles.addBtnDisabled,
                pressed && { transform: [{ scale: 0.94 }] },
              ]}
            >
              {inCart ? <Check size={18} color={Colors.white} /> : <Plus size={18} color={soldOut ? Colors.textMuted : Colors.primary} />}
            </Pressable>
          </View>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  pressed: { opacity: 0.9, transform: [{ scale: 0.995 }] },
  row: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
    marginBottom: 14,
    ...Shadow.soft,
  },
  rowImage: { width: 96, height: 96 },
  rowBody: { flex: 1, justifyContent: 'space-between' },
  rowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  rowName: { ...Typography.h3, fontSize: 16, flexShrink: 1 },
  rowDesc: { ...Typography.caption, marginTop: 3, lineHeight: 16 },
  rowFooter: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  rowPriceLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  rowMeta: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  addBtnDisabled: { borderColor: Colors.border, backgroundColor: Colors.disabled },
  grid: {
    width: 176,
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 10,
    marginRight: 12,
    ...Shadow.soft,
  },
  gridImage: { width: '100%', height: 116 },
  vegOnImage: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: Colors.white,
    padding: 3,
    borderRadius: 6,
  },
  gridName: { ...Typography.bodyBold, marginTop: 10 },
  gridDesc: { ...Typography.caption, marginTop: 2, lineHeight: 16, minHeight: 32 },
  gridFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 8 },
  soldOut: {
    position: 'absolute',
    bottom: 6,
    left: 6,
    backgroundColor: 'rgba(23,23,23,0.82)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radius.sm,
  },
  soldOutText: { color: Colors.white, fontSize: 11, fontWeight: '700' },
});
