import { Minus, Plus, Trash2 } from 'lucide-react-native';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Colors, Radius, Typography } from '@/constants/theme';

interface Props {
  value: number;
  onChange: (next: number) => void;
  min?: number;
  max?: number;
  /** Shows a remove/delete affordance when value hits the minimum. */
  onRemove?: () => void;
  compact?: boolean;
  label?: string;
}

export const QuantityStepper = ({
  value,
  onChange,
  min = 1,
  max = 20,
  onRemove,
  compact = false,
  label = 'quantity',
}: Props) => {
  const size = compact ? 30 : 36;
  const atMin = value <= min;

  return (
    <View
      style={[styles.wrap, compact && styles.wrapCompact]}
      accessibilityLabel={`${label}: ${value}`}
      accessibilityRole="adjustable"
    >
      <Pressable
        onPress={() => (atMin && onRemove ? onRemove() : onChange(value - 1))}
        hitSlop={8}
        accessibilityRole="button"
        accessibilityLabel={atMin && onRemove ? `Remove ${label}` : `Decrease ${label}`}
        style={[styles.btn, { width: size, height: size }, atMin && onRemove && styles.btnRemove]}
      >
        {atMin && onRemove ? (
          <Trash2 size={15} color={Colors.danger} />
        ) : (
          <Minus size={16} color={atMin ? Colors.textMuted : Colors.textPrimary} />
        )}
      </Pressable>
      <Text style={[styles.value, compact && { fontSize: 14 }]} accessibilityLiveRegion="polite">
        {value}
      </Text>
      <Pressable
        onPress={() => onChange(Math.min(value + 1, max))}
        hitSlop={8}
        accessibilityRole="button"
        accessibilityLabel={`Increase ${label}`}
        disabled={value >= max}
        style={[styles.btn, styles.btnPlus, { width: size, height: size }, value >= max && styles.btnDisabled]}
      >
        <Plus size={16} color={Colors.white} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 4,
    gap: 6,
  },
  wrapCompact: { padding: 2, gap: 2 },
  btn: {
    borderRadius: 16,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  btnPlus: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  btnRemove: { backgroundColor: Colors.white },
  btnDisabled: { backgroundColor: Colors.disabled, borderColor: Colors.disabled },
  value: { ...Typography.bodyBold, minWidth: 22, textAlign: 'center' },
});
