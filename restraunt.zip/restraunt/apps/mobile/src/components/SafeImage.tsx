import { Image, type ImageProps } from 'expo-image';
import { ChefHat } from 'lucide-react-native';
import { useState, type ComponentProps } from 'react';
import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { Colors, Radius } from '@/constants/theme';

interface Props extends Omit<ImageProps, 'source'> {
  uri?: string | null;
  style?: StyleProp<ViewStyle>;
  /** Show dish name initial inside the placeholder. */
  label?: string;
  rounded?: number;
}

/**
 * Renders remote food photography with a branded fallback:
 * soft orange surface + chef-hat mark when the URL is unreachable.
 * (Prevents broken-image rectangles even offline or on slow networks.)
 */
export const SafeImage = ({ uri, style, label, rounded = Radius.md, ...rest }: Props) => {
  const [failed, setFailed] = useState(false);

  if (!uri || failed) {
    return (
      <View style={[styles.fallback, { borderRadius: rounded }, style]} accessibilityLabel={label ? `${label} image placeholder` : 'image placeholder'}>
        <ChefHat size={28} color={Colors.primary} strokeWidth={1.6} />
        {label ? (
          <Text numberOfLines={1} style={styles.initial}>
            {label.charAt(0).toUpperCase()}
          </Text>
        ) : null}
      </View>
    );
  }

  return (
    <Image
      source={{ uri }}
      style={[{ borderRadius: rounded }, style as ComponentProps<typeof Image>['style']]}
      contentFit="cover"
      transition={220}
      cachePolicy="memory-disk"
      onError={() => setFailed(true)}
      {...rest}
    />
  );
};

const styles = StyleSheet.create({
  fallback: {
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  initial: {
    marginTop: 2,
    fontSize: 13,
    fontWeight: '700',
    color: Colors.primary,
  },
});
