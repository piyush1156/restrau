import { useEffect } from 'react';
import { StyleSheet, Text } from 'react-native';
import Animated, { FadeInUp, FadeOutUp } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { useToastStore } from '@/store/ui';

/** Global toast host — mounted once in the root layout. */
export const ToastHost = () => {
  const { message, type, hide } = useToastStore();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(hide, 3000);
    return () => clearTimeout(timer);
  }, [message, hide]);

  if (!message) return null;

  const tone =
    type === 'success'
      ? { bg: Colors.successSoft, fg: Colors.success }
      : type === 'error'
        ? { bg: Colors.dangerSoft, fg: Colors.danger }
        : { bg: Colors.textPrimary, fg: Colors.white };

  return (
    <Animated.View
      entering={FadeInUp.duration(240)}
      exiting={FadeOutUp.duration(180)}
      pointerEvents="none"
      accessibilityRole="alert"
      style={[styles.toast, { top: insets.top + 8, backgroundColor: tone.bg }]}
    >
      <Text style={[styles.text, { color: tone.fg }]}>{message}</Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  toast: {
    position: 'absolute',
    left: 16,
    right: 16,
    borderRadius: Radius.md,
    paddingHorizontal: 16,
    paddingVertical: 12,
    zIndex: 1000,
    ...Shadow.card,
  },
  text: { ...Typography.secondary, fontWeight: '600', textAlign: 'center', lineHeight: 18 },
});
