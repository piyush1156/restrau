import { Check } from 'lucide-react-native';
import { StyleSheet, Text, View } from 'react-native';
import type { Order, OrderStatus } from '@grove/shared';
import { ORDER_STATUS_LABELS, trackingStepsFor } from '@grove/shared';
import { Colors, Radius, Typography } from '@/constants/theme';

/** Order status timeline: highlights completed steps from real status data. */
export const OrderTimeline = ({ order }: { order: Order }) => {
  const steps = trackingStepsFor(order.type);
  const cancelled = order.status === 'cancelled';
  let currentIdx = steps.indexOf(order.status as OrderStatus);
  // Delivery orders pass through 'ready' which isn't in their timeline —
  // show them as preparing-complete rather than leaving the timeline blank.
  if (currentIdx < 0 && order.status === 'ready') currentIdx = steps.indexOf('preparing');
  if (currentIdx < 0) currentIdx = 0;

  if (cancelled) {
    return (
      <View style={styles.card}>
        <Text style={styles.title}>Order cancelled</Text>
        <Text style={styles.sub}>
          {order.cancelReason ? `${order.cancelReason}. ` : ''}
          Any paid amount is refunded to the original payment method within 5–7 business days.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.card}>
      <Text style={styles.title}>Order status</Text>
      <View style={styles.row}>
        {steps.map((step, i) => {
          const done = currentIdx >= i;
          const active = i === currentIdx;
          return (
            <View key={step} style={styles.step}>
              <View style={styles.markerCol}>
                <View
                  style={[
                    styles.dot,
                    done && styles.dotDone,
                    active && styles.dotActive,
                  ]}
                >
                  {done ? <Check size={13} color={Colors.white} /> : null}
                </View>
                {i < steps.length - 1 ? (
                  <View style={[styles.line, currentIdx > i && styles.lineDone]} />
                ) : null}
              </View>
              <Text style={[styles.stepLabel, (done || active) && styles.stepLabelDone]}>
                {ORDER_STATUS_LABELS[step]}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
  },
  title: { ...Typography.h3, marginBottom: 14 },
  sub: { ...Typography.secondary, lineHeight: 19 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  step: { alignItems: 'center', flex: 1 },
  markerCol: { flexDirection: 'row', alignItems: 'center', width: '100%', justifyContent: 'center' },
  dot: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.disabled,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.disabled,
  },
  dotDone: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  dotActive: { borderColor: Colors.primary, backgroundColor: Colors.primary, transform: [{ scale: 1.08 }] },
  line: { height: 3, flex: 1, backgroundColor: Colors.disabled, borderRadius: 2, marginHorizontal: 2 },
  lineDone: { backgroundColor: Colors.primary },
  stepLabel: { ...Typography.caption, marginTop: 8, textAlign: 'center', fontSize: 11 },
  stepLabelDone: { color: Colors.textPrimary, fontWeight: '700' },
});
