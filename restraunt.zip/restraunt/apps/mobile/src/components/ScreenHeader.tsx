import { ChevronLeft } from 'lucide-react-native';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Typography } from '@/constants/theme';

interface Props {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
  subtitle?: string;
  /** true when the screen sits below the app tabs (needs no top inset). */
  bordered?: boolean;
}

export const ScreenHeader = ({ title, onBack, right, subtitle, bordered = true }: Props) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.wrap,
        { paddingTop: insets.top + 8 },
        bordered && styles.bordered,
      ]}
    >
      <View style={styles.side}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Go back"
            style={styles.back}
          >
            <ChevronLeft size={24} color={Colors.textPrimary} />
          </Pressable>
        ) : null}
      </View>
      <View style={styles.center}>
        <Text style={styles.title} numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      <View style={[styles.side, styles.rightSide]}>{right}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: Colors.white,
  },
  bordered: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  side: { width: 44, justifyContent: 'center' },
  rightSide: { alignItems: 'flex-end' },
  center: { flex: 1, alignItems: 'center' },
  back: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { ...Typography.h3 },
  subtitle: { ...Typography.caption, marginTop: 2 },
});
