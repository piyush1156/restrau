import { ChefHat, Heart, Home, Menu as MenuIcon, CalendarDays, TicketPercent, Settings, CircleHelp, LogOut, ShoppingBag, X, ClipboardList } from 'lucide-react-native';
import { router } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeOut, SlideInLeft, SlideOutLeft } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { useDrawerStore, useToastStore } from '@/store/ui';
import { SafeImage } from './SafeImage';

interface NavItem {
  label: string;
  icon: React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
  href: string;
}

const ITEMS: NavItem[] = [
  { label: 'Home', icon: Home, href: '/' },
  { label: 'Menu', icon: MenuIcon, href: '/(tabs)/menu' },
  { label: 'Orders', icon: ClipboardList, href: '/(tabs)/orders' },
  { label: 'Table Booking', icon: CalendarDays, href: '/booking' },
  { label: 'Favourites', icon: Heart, href: '/favourites' },
  { label: 'Offers & Coupons', icon: TicketPercent, href: '/offers' },
  { label: 'Settings', icon: Settings, href: '/settings' },
  { label: 'Help & Support', icon: CircleHelp, href: '/help' },
];

/** Slide-in side menu. Opens over content but keeps bottom tabs reachable via close. */
export const DrawerMenu = () => {
  const open = useDrawerStore((s) => s.open);
  const setOpen = useDrawerStore((s) => s.setOpen);
  const insets = useSafeAreaInsets();
  const profile = useAuthStore((s) => s.profile);
  const signOut = useAuthStore((s) => s.signOut);
  const toast = useToastStore((s) => s.show);

  if (!open) return null;

  const navigate = (href: string) => {
    setOpen(false);
    // small delay so the drawer exit animation doesn't fight navigation
    setTimeout(() => router.push(href as never), 120);
  };

  const onLogout = () => {
    setOpen(false);
    setTimeout(async () => {
      await signOut();
      toast('Logged out successfully', 'success');
    }, 150);
  };

  return (
    <Animated.View entering={FadeIn.duration(160)} exiting={FadeOut.duration(140)} style={styles.overlay}>
      <Pressable style={styles.backdrop} onPress={() => setOpen(false)} accessibilityLabel="Close menu" />
      <Animated.View
        entering={SlideInLeft.springify().damping(18)}
        exiting={SlideOutLeft.duration(180)}
        style={[styles.panel, { paddingTop: insets.top + 16 }]}
      >
        <View style={styles.headerRow}>
          <SafeImage uri={profile?.avatarUrl ?? null} label={profile?.fullName ?? 'G'} style={styles.avatar} rounded={26} />
          <View style={{ flex: 1 }}>
            <Text style={styles.name} numberOfLines={1}>
              {profile?.fullName ?? 'Guest'}
            </Text>
            <Text style={styles.email} numberOfLines={1}>
              {profile?.email ?? 'Sign in to order'}
            </Text>
          </View>
          <Pressable onPress={() => setOpen(false)} hitSlop={10} style={styles.close} accessibilityRole="button" accessibilityLabel="Close menu">
            <X size={20} color={Colors.textPrimary} />
          </Pressable>
        </View>

        <View style={styles.divider} />

        <View style={{ flex: 1 }}>
          {ITEMS.map((item) => (
            <Pressable
              key={item.href}
              onPress={() => navigate(item.href)}
              accessibilityRole="menuitem"
              style={({ pressed }) => [styles.item, pressed && { backgroundColor: Colors.primarySoft }]}
            >
              <item.icon size={20} color={Colors.primary} strokeWidth={1.8} />
              <Text style={styles.itemText}>{item.label}</Text>
            </Pressable>
          ))}
        </View>

        <Pressable
          onPress={onLogout}
          accessibilityRole="button"
          style={({ pressed }) => [styles.item, styles.logout, pressed && { backgroundColor: Colors.dangerSoft }]}
        >
          <LogOut size={20} color={Colors.danger} strokeWidth={1.8} />
          <Text style={[styles.itemText, { color: Colors.danger }]}>Logout</Text>
        </Pressable>

        <View style={styles.brand}>
          <ChefHat size={16} color={Colors.primary} />
          <Text style={styles.brandText}>The Grove • Good Food • Good Mood</Text>
        </View>
      </Animated.View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, zIndex: 100 },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(23,23,23,0.35)' },
  panel: {
    width: '82%',
    maxWidth: 340,
    backgroundColor: Colors.white,
    borderTopRightRadius: Radius.xxl,
    borderBottomRightRadius: Radius.xxl,
    paddingHorizontal: 18,
    paddingBottom: 20,
    ...Shadow.card,
  },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 52, height: 52 },
  name: { ...Typography.h3 },
  email: { ...Typography.caption, marginTop: 2 },
  close: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 14 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    minHeight: 48,
    paddingHorizontal: 10,
    borderRadius: Radius.md,
    marginBottom: 4,
  },
  itemText: { ...Typography.body, fontWeight: '500' },
  logout: { marginTop: 8, borderWidth: 1, borderColor: Colors.dangerSoft },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center', marginTop: 14 },
  brandText: { ...Typography.caption, color: Colors.textMuted },
});
