import { AlertTriangle, Star, UtensilsCrossed } from 'lucide-react-native';
import { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import type { OrderStatus, ReservationStatus } from '@grove/shared';
import { ORDER_STATUS_LABELS, RESERVATION_STATUS_LABELS } from '@grove/shared';

/* ------------------------------------------------------------------ VegBadge */
export const VegBadge = ({ isVeg, size = 16 }: { isVeg: boolean; size?: number }) => {
  const color = isVeg ? Colors.veg : Colors.nonVeg;
  return (
    <View
      accessibilityLabel={isVeg ? 'Vegetarian' : 'Non-vegetarian'}
      style={[styles.vegBox, { borderColor: color, width: size + 4, height: size + 4 }]}
    >
      <View style={[styles.vegDot, { backgroundColor: color, width: size / 2, height: size / 2 }]} />
    </View>
  );
};

/* --------------------------------------------------------------- RatingPill */
export const RatingPill = ({ rating, count, size = 'sm' }: { rating: number; count?: number; size?: 'sm' | 'md' }) => (
  <View style={styles.rating}>
    <Star size={size === 'md' ? 14 : 12} color={Colors.primary} fill={Colors.primary} />
    <Text style={[styles.ratingText, size === 'md' && { fontSize: 14 }]}>
      {rating.toFixed(1)}
      {count != null ? <Text style={styles.ratingCount}> ({count >= 1000 ? `${(count / 1000).toFixed(1)}k` : count} reviews)</Text> : null}
    </Text>
  </View>
);

/* --------------------------------------------------------------------- Chip */
export const Chip = ({
  label,
  active = false,
  onPress,
  style,
}: {
  label: string;
  active?: boolean;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) => (
  <Pressable
    onPress={onPress}
    accessibilityRole="button"
    accessibilityState={{ selected: active }}
    style={[styles.chip, active && styles.chipActive, style]}
  >
    <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
  </Pressable>
);

/* ---------------------------------------------------------------- Skeleton */
export const Skeleton = ({ height = 16, width = '100%' as number | `${number}%`, style }: { height?: number; width?: number | `${number}%`; style?: StyleProp<ViewStyle> }) => {
  const opacity = useRef(new Animated.Value(0.4)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 650, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.4, duration: 650, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);
  return <Animated.View style={[styles.skeleton, { height, width, opacity }, style]} />;
};

export const CardSkeleton = () => (
  <View style={styles.skelCard}>
    <Skeleton height={110} width="100%" />
    <Skeleton height={14} width="70%" style={{ marginTop: 12 }} />
    <Skeleton height={12} width="45%" style={{ marginTop: 8 }} />
  </View>
);

/* -------------------------------------------------------------- EmptyState */
export const EmptyState = ({
  title,
  subtitle,
  actionLabel,
  onAction,
  tone = 'neutral',
}: {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
  tone?: 'neutral' | 'error';
}) => (
  <View style={styles.empty}>
    <View style={[styles.emptyIcon, tone === 'error' && { backgroundColor: Colors.dangerSoft }]}>
      {tone === 'error' ? (
        <AlertTriangle size={26} color={Colors.danger} />
      ) : (
        <UtensilsCrossed size={26} color={Colors.primary} />
      )}
    </View>
    <Text style={styles.emptyTitle}>{title}</Text>
    {subtitle ? <Text style={styles.emptySub}>{subtitle}</Text> : null}
    {actionLabel && onAction ? (
      <Pressable onPress={onAction} style={styles.emptyBtn} accessibilityRole="button">
        <Text style={styles.emptyBtnText}>{actionLabel}</Text>
      </Pressable>
    ) : null}
  </View>
);

/* -------------------------------------------------------------- StatusBadge */
const statusPalette: Record<OrderStatus | ReservationStatus, { bg: string; fg: string }> = {
  pending: { bg: Colors.warningSoft, fg: Colors.warning },
  confirmed: { bg: Colors.primarySoft, fg: Colors.primary },
  preparing: { bg: Colors.primarySoft, fg: Colors.primary },
  ready: { bg: Colors.primarySoft, fg: Colors.primary },
  out_for_delivery: { bg: Colors.primarySoft, fg: Colors.primary },
  delivered: { bg: Colors.successSoft, fg: Colors.success },
  completed: { bg: Colors.successSoft, fg: Colors.success },
  cancelled: { bg: Colors.dangerSoft, fg: Colors.danger },
  rejected: { bg: Colors.dangerSoft, fg: Colors.danger },
};

export const StatusBadge = ({ status }: { status: OrderStatus | ReservationStatus }) => {
  const p = statusPalette[status] ?? { bg: Colors.disabled, fg: Colors.textSecondary };
  const label = ORDER_STATUS_LABELS[status as OrderStatus] ?? RESERVATION_STATUS_LABELS[status as ReservationStatus] ?? status;
  return (
    <View style={[styles.badge, { backgroundColor: p.bg }]}>
      <Text style={[styles.badgeText, { color: p.fg }]}>{label}</Text>
    </View>
  );
};

/* ------------------------------------------------------------- Price display */
export const Price = ({ value, size = 'md', strike = false }: { value: string; size?: 'sm' | 'md' | 'lg'; strike?: boolean }) => (
  <Text
    style={[
      strike ? styles.priceStrike : styles.price,
      size === 'lg' && { fontSize: 22 },
      size === 'sm' && { fontSize: 14 },
    ]}
  >
    {value}
  </Text>
);

const styles = StyleSheet.create({
  vegBox: { borderWidth: 1.4, borderRadius: 4, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.white },
  vegDot: { borderRadius: 99 },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: Radius.sm,
    alignSelf: 'flex-start',
  },
  ratingText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  ratingCount: { fontSize: 11, fontWeight: '500', color: Colors.textSecondary },
  chip: {
    minHeight: 40,
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    marginRight: 8,
  },
  chipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary, ...Shadow.soft },
  chipText: { fontSize: 14, fontWeight: '600', color: Colors.textSecondary },
  chipTextActive: { color: Colors.white },
  skeleton: { backgroundColor: '#EDEDED', borderRadius: 8 },
  skelCard: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
    marginBottom: 14,
  },
  empty: { alignItems: 'center', paddingHorizontal: 32, paddingVertical: 40 },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  emptyTitle: { ...Typography.h3, textAlign: 'center' },
  emptySub: { ...Typography.secondary, textAlign: 'center', marginTop: 6, lineHeight: 19 },
  emptyBtn: {
    marginTop: 18,
    backgroundColor: Colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: Radius.pill,
  },
  emptyBtnText: { color: Colors.white, fontWeight: '700', fontSize: 15 },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.pill, alignSelf: 'flex-start' },
  badgeText: { fontSize: 12, fontWeight: '700' },
  price: { ...Typography.price },
  priceStrike: { fontSize: 13, color: Colors.textMuted, textDecorationLine: 'line-through', fontWeight: '500' },
});
