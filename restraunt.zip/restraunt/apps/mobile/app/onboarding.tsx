import { router } from 'expo-router';
import { ChefHat, Clock3, ShieldCheck } from 'lucide-react-native';
import { StyleSheet, Text, View } from 'react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { AppButton } from '@/components/AppButton';
import { SafeImage } from '@/components/SafeImage';
import { Colors, Radius, Typography } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';

const HIGHLIGHTS = [
  { icon: ChefHat, title: 'Fresh, made to order', sub: 'Real kitchen, real ingredients — no shortcuts.' },
  { icon: Clock3, title: 'Track every order', sub: 'Live status from confirmation to your door.' },
  { icon: ShieldCheck, title: 'Secure payments', sub: 'Razorpay-verified payments & COD where enabled.' },
];

export default function Onboarding() {
  const complete = useAuthStore((s) => s.completeOnboarding);

  const start = () => {
    complete();
    router.replace('/(auth)/login');
  };

  return (
    <View style={styles.container}>
      <Animated.View entering={FadeInUp.duration(500)} style={styles.hero}>
        <SafeImage
          uri="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=70"
          style={styles.heroImage}
          rounded={Radius.xxl}
          label="Restaurant interior"
        />
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(150).duration(500)} style={styles.body}>
        <Text style={styles.brand}>The Grove</Text>
        <Text style={styles.tagline}>RESTAURANT & CAFE • Good Food • Good Mood</Text>

        <View style={styles.points}>
          {HIGHLIGHTS.map((h) => (
            <View key={h.title} style={styles.point}>
              <View style={styles.pointIcon}>
                <h.icon size={18} color={Colors.primary} strokeWidth={1.9} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.pointTitle}>{h.title}</Text>
                <Text style={styles.pointSub}>{h.sub}</Text>
              </View>
            </View>
          ))}
        </View>
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(300).duration(500)} style={styles.footer}>
        <AppButton label="Get Started" onPress={start} accessibilityHint="Continues to sign in" />
        <Text style={styles.legal}>By continuing you agree to our Terms & Privacy Policy.</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.white, paddingHorizontal: 24, paddingTop: 24 },
  hero: { flex: 0.9, borderRadius: Radius.xxl, overflow: 'hidden' },
  heroImage: { width: '100%', height: '100%' },
  body: { marginTop: 24, flex: 1 },
  brand: { fontSize: 30, fontWeight: '800', color: Colors.textPrimary, letterSpacing: 0.4 },
  tagline: { ...Typography.secondary, color: Colors.primary, fontWeight: '700', marginTop: 4 },
  points: { marginTop: 20, gap: 14 },
  point: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  pointIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pointTitle: { ...Typography.bodyBold, fontSize: 15 },
  pointSub: { ...Typography.caption, marginTop: 1 },
  footer: { paddingBottom: 24 },
  legal: { ...Typography.caption, textAlign: 'center', marginTop: 14 },
});
