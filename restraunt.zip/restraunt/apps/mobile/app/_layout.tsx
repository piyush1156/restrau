import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ToastHost } from '@/components/Toast';
import { Colors } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { groveApi } from '@/services/client';
import { registerForPush } from '@/services/push';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 2, staleTime: 30_000, refetchOnWindowFocus: false },
  },
});

export default function RootLayout() {
  const token = useAuthStore((s) => s.token);
  const bootstrap = useAuthStore((s) => s.bootstrap);
  const status = useAuthStore((s) => s.status);
  const pushTokens = useAuthStore((s) => s.profile?.pushTokens);
  const updateProfile = useAuthStore((s) => s.updateProfile);

  // keep the API client in sync with the persisted session token
  useEffect(() => {
    groveApi.setToken(token);
  }, [token]);

  // restore session exactly once at startup (no artificial delay)
  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  // Register the push token once per signed-in session (best effort, never blocking).
  useEffect(() => {
    if (status !== 'signedIn') return;
    let alive = true;
    void (async () => {
      const pushToken = await registerForPush();
      if (!alive || !pushToken) return;
      if (pushTokens?.includes(pushToken)) return;
      try {
        await updateProfile({ pushTokens: [...(pushTokens ?? []), pushToken].slice(0, 5) });
      } catch {
        // Push registration failure must never interrupt ordering.
      }
    })();
    return () => {
      alive = false;
    };
  }, [status, pushTokens, updateProfile]);

  return (
    <GestureHandlerRootView style={styles.root}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <StatusBar style="dark" backgroundColor={Colors.background} />
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: Colors.background },
              animation: 'slide_from_right',
            }}
          >
            <Stack.Screen name="index" options={{ animation: 'fade' }} />
            <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
            <Stack.Screen name="(auth)" options={{ animation: 'fade' }} />
            <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
            <Stack.Screen name="cart" options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="checkout" options={{ animation: 'slide_from_bottom' }} />
          </Stack>
          <ToastHost />
        </QueryClientProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
});
