import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { ChefHat, Lock, Mail, Phone, UserRound } from 'lucide-react-native';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { AppButton } from '@/components/AppButton';
import { TextField } from '@/components/TextField';
import { Colors, Radius, Typography } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { useToastStore } from '@/store/ui';
import { registerSchema, type RegisterInput } from '@grove/shared';

export default function Register() {
  const signUp = useAuthStore((s) => s.signUp);
  const toast = useToastStore((s) => s.show);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: '', email: '', phone: '', password: '', confirmPassword: '' },
    mode: 'onTouched',
  });

  const onSubmit = async (values: RegisterInput) => {
    setServerError(null);
    try {
      await signUp({
        fullName: values.fullName,
        email: values.email,
        phone: values.phone,
        password: values.password,
      });
      toast('Account created — welcome to The Grove!', 'success');
      router.replace('/(tabs)');
    } catch (e) {
      setServerError(e instanceof Error ? e.message : 'Could not create the account.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.brandBlock}>
          <View style={styles.logo}>
            <ChefHat size={30} color={Colors.primary} strokeWidth={1.7} />
          </View>
          <Text style={styles.heading}>Create Account</Text>
          <Text style={styles.sub}>Join The Grove — Good Food, Good Mood</Text>
        </View>

        {serverError ? (
          <View style={styles.serverError} accessibilityRole="alert">
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </View>
        ) : null}

        <Controller
          control={control}
          name="fullName"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Full Name"
              placeholder="Piyush Singh"
              autoCapitalize="words"
              leftIcon={<UserRound size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.fullName?.message}
            />
          )}
        />

        <Controller
          control={control}
          name="email"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Email"
              placeholder="you@example.com"
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon={<Mail size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.email?.message}
            />
          )}
        />

        <Controller
          control={control}
          name="phone"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Phone Number"
              placeholder="10-digit mobile number"
              keyboardType="phone-pad"
              leftIcon={<Phone size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={(v) => onChange(v.replace(/[^0-9]/g, '').slice(0, 10))}
              onBlur={onBlur}
              error={errors.phone?.message}
            />
          )}
        />

        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Password"
              placeholder="Min 8 chars, letters & numbers"
              secureTextEntry
              autoComplete="new-password"
              leftIcon={<Lock size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.password?.message}
              hint="At least 8 characters with a letter and a number."
            />
          )}
        />

        <Controller
          control={control}
          name="confirmPassword"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Confirm Password"
              placeholder="Re-enter your password"
              secureTextEntry
              leftIcon={<Lock size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.confirmPassword?.message}
              returnKeyType="done"
              onSubmitEditing={handleSubmit(onSubmit)}
            />
          )}
        />

        <AppButton label="Create Account" onPress={handleSubmit(onSubmit)} loading={isSubmitting} />

        <View style={styles.loginRow}>
          <Text style={styles.secondary}>Already have an account? </Text>
          <Pressable onPress={() => router.replace('/(auth)/login')} accessibilityRole="link">
            <Text style={styles.link}>Login</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.white },
  scroll: { paddingHorizontal: 24, paddingTop: 56, paddingBottom: 40 },
  brandBlock: { alignItems: 'center', marginBottom: 24 },
  logo: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#FFE3C7',
  },
  heading: { ...Typography.h1, marginTop: 12 },
  sub: { ...Typography.secondary, marginTop: 4 },
  serverError: {
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#F6C6CB',
  },
  serverErrorText: { color: Colors.danger, fontSize: 13, textAlign: 'center' },
  loginRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  secondary: { ...Typography.secondary },
  link: { color: Colors.primary, fontWeight: '800', fontSize: 14 },
});
