import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { ChefHat, Lock, UserRound } from 'lucide-react-native';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { AppButton } from '@/components/AppButton';
import { TextField } from '@/components/TextField';
import { Colors, Radius, Typography } from '@/constants/theme';
import { useAuthStore, useStrings } from '@/store/auth';
import { useToastStore } from '@/store/ui';
import { loginSchema, type LoginInput } from '@grove/shared';

const GOOGLE_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_CLIENT_ID;
const APPLE_CLIENT_ID = process.env.EXPO_PUBLIC_APPLE_CLIENT_ID;

export default function Login() {
  const signIn = useAuthStore((s) => s.signIn);
  const toast = useToastStore((s) => s.show);
  const t = useStrings();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { identifier: '', password: '' },
    mode: 'onTouched',
  });

  const onSubmit = async (values: LoginInput) => {
    setServerError(null);
    try {
      await signIn(values.identifier, values.password);
      toast('Welcome back!', 'success');
      router.replace('/(tabs)');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Could not sign in. Please try again.';
      setServerError(msg);
    }
  };

  // Social buttons render ONLY when a provider is actually configured.
  const hasSocial = Boolean(GOOGLE_CLIENT_ID || APPLE_CLIENT_ID);

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.brandBlock}>
          <View style={styles.logo}>
            <ChefHat size={34} color={Colors.primary} strokeWidth={1.7} />
          </View>
          <Text style={styles.brand}>The Grove</Text>
          <Text style={styles.brandSub}>RESTAURANT & CAFE</Text>
        </View>

        <Text style={styles.heading}>Welcome Back</Text>
        <Text style={styles.sub}>Sign in to your account</Text>

        {serverError ? (
          <View style={styles.serverError} accessibilityRole="alert">
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </View>
        ) : null}

        <Controller
          control={control}
          name="identifier"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Email or Phone Number"
              placeholder="you@example.com or 9876543210"
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
              leftIcon={<UserRound size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.identifier?.message}
              returnKeyType="next"
            />
          )}
        />

        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, onBlur, value } }) => (
            <TextField
              label="Password"
              placeholder="Enter your password"
              secureTextEntry
              autoComplete="password"
              leftIcon={<Lock size={18} color={Colors.textSecondary} />}
              value={value}
              onChangeText={onChange}
              onBlur={onBlur}
              error={errors.password?.message}
              returnKeyType="done"
              onSubmitEditing={handleSubmit(onSubmit)}
            />
          )}
        />

        <Pressable
          onPress={() => router.push('/(auth)/forgot-password')}
          style={styles.forgot}
          accessibilityRole="button"
        >
          <Text style={styles.forgotText}>Forgot Password?</Text>
        </Pressable>

        <AppButton label={t.login} onPress={handleSubmit(onSubmit)} loading={isSubmitting} />

        {hasSocial ? (
          <View style={styles.orRow}>
            <View style={styles.hr} />
            <Text style={styles.orText}>OR</Text>
            <View style={styles.hr} />
          </View>
        ) : (
          <Text style={styles.demoNote}>
            Tip: in demo mode any email + 6 character password signs you in instantly.
          </Text>
        )}

        <View style={styles.signupRow}>
          <Text style={styles.secondary}>Don’t have an account? </Text>
          <Pressable onPress={() => router.push('/(auth)/register')} accessibilityRole="link">
            <Text style={styles.link}>{t.signUp}</Text>
          </Pressable>
        </View>

        <View style={styles.legal}>
          <Pressable onPress={() => router.push('/legal/terms')}>
            <Text style={styles.legalLink}>Terms & Conditions</Text>
          </Pressable>
          <Text style={styles.legalDot}>•</Text>
          <Pressable onPress={() => router.push('/legal/privacy')}>
            <Text style={styles.legalLink}>Privacy Policy</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.white },
  scroll: { paddingHorizontal: 24, paddingTop: 64, paddingBottom: 40 },
  brandBlock: { alignItems: 'center', marginBottom: 28 },
  logo: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#FFE3C7',
  },
  brand: { fontSize: 26, fontWeight: '800', color: Colors.textPrimary, marginTop: 10, letterSpacing: 0.4 },
  brandSub: { fontSize: 11, letterSpacing: 4, color: Colors.textSecondary, marginTop: 2, fontWeight: '600' },
  heading: { ...Typography.h1, textAlign: 'center' },
  sub: { ...Typography.secondary, textAlign: 'center', marginTop: 4, marginBottom: 22 },
  serverError: {
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#F6C6CB',
  },
  serverErrorText: { color: Colors.danger, fontSize: 13, textAlign: 'center' },
  forgot: { alignSelf: 'flex-end', marginBottom: 18, marginTop: -6, paddingVertical: 4 },
  forgotText: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 18 },
  hr: { flex: 1, height: 1, backgroundColor: Colors.border },
  orText: { ...Typography.caption, fontWeight: '700', color: Colors.textMuted },
  demoNote: { ...Typography.caption, textAlign: 'center', marginVertical: 16, lineHeight: 17 },
  signupRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 8 },
  secondary: { ...Typography.secondary },
  link: { color: Colors.primary, fontWeight: '800', fontSize: 14 },
  legal: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 26 },
  legalLink: { ...Typography.caption, color: Colors.textSecondary, textDecorationLine: 'underline' },
  legalDot: { ...Typography.caption },
});
