import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Mail } from 'lucide-react-native';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { AppButton } from '@/components/AppButton';
import { ScreenHeader } from '@/components/ScreenHeader';
import { TextField } from '@/components/TextField';
import { Colors, Radius, Typography } from '@/constants/theme';
import { groveApi } from '@/services/client';
import { forgotPasswordSchema } from '@grove/shared';
import type { z } from 'zod';

type FormValues = z.infer<typeof forgotPasswordSchema>;

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: '' },
    mode: 'onTouched',
  });

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    try {
      await groveApi.requestPasswordReset(values.email);
      setSent(true);
    } catch (e) {
      setServerError(e instanceof Error ? e.message : 'Could not send the reset link.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScreenHeader title="Reset Password" onBack={() => router.back()} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {sent ? (
          <View style={styles.success}>
            <View style={styles.successIcon}>
              <Mail size={28} color={Colors.success} />
            </View>
            <Text style={styles.successTitle}>Check your inbox</Text>
            <Text style={styles.successSub}>
              If an account exists for that email, a password reset link is on its way. The link expires in 30
              minutes.
            </Text>
            <AppButton label="Back to Login" onPress={() => router.replace('/(auth)/login')} style={{ alignSelf: 'stretch', marginTop: 24 }} />
          </View>
        ) : (
          <>
            <Text style={styles.heading}>Forgot your password?</Text>
            <Text style={styles.sub}>
              Enter the email linked to your account and we’ll send you a secure reset link.
            </Text>

            {serverError ? (
              <View style={styles.serverError} accessibilityRole="alert">
                <Text style={styles.serverErrorText}>{serverError}</Text>
              </View>
            ) : null}

            <Controller
              control={control}
              name="email"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextField
                  label="Email"
                  placeholder="you@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  leftIcon={<Mail size={18} color={Colors.textSecondary} />}
                  value={value}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  error={errors.email?.message}
                  returnKeyType="done"
                  onSubmitEditing={handleSubmit(onSubmit)}
                />
              )}
            />

            <AppButton label="Send Reset Link" onPress={handleSubmit(onSubmit)} loading={isSubmitting} />
            <Pressable onPress={() => router.back()} style={styles.back} accessibilityRole="link">
              <Text style={styles.backText}>Back to Login</Text>
            </Pressable>
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.white },
  scroll: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 40 },
  heading: { ...Typography.h1, fontSize: 22 },
  sub: { ...Typography.secondary, marginTop: 6, marginBottom: 22, lineHeight: 20 },
  serverError: {
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#F6C6CB',
  },
  serverErrorText: { color: Colors.danger, fontSize: 13, textAlign: 'center' },
  back: { alignItems: 'center', marginTop: 18, padding: 6 },
  backText: { color: Colors.primary, fontWeight: '700' },
  success: { alignItems: 'center', paddingTop: 30 },
  successIcon: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: Colors.successSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  successTitle: { ...Typography.h2 },
  successSub: { ...Typography.secondary, textAlign: 'center', marginTop: 8, lineHeight: 20 },
});
