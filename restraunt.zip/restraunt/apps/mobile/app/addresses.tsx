import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Home, MapPin, Pencil, Plus, Trash2, Briefcase } from 'lucide-react-native';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState } from '@/components/Bits';
import { AppButton } from '@/components/AppButton';
import { ScreenHeader } from '@/components/ScreenHeader';
import { TextField } from '@/components/TextField';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { addressSchema, type AddressInput } from '@grove/shared';
import type { Address } from '@grove/shared';
import { useAddresses } from '@/hooks/useQueries';
import { qk } from '@/hooks/useQueries';
import { groveApi } from '@/services/client';
import { useQueryClient } from '@tanstack/react-query';
import { useToastStore } from '@/store/ui';

export default function AddressesScreen() {
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const qc = useQueryClient();
  const { data, isLoading, isError, refetch } = useAddresses();
  const [editing, setEditing] = useState<Address | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<AddressInput>({
    resolver: zodResolver(addressSchema),
    defaultValues: { label: 'Home', line1: '', line2: '', landmark: '', city: 'New Delhi', pincode: '', isDefault: false },
  });

  const openNew = () => {
    setEditing(null);
    reset({ label: 'Home', line1: '', line2: '', landmark: '', city: 'New Delhi', pincode: '', isDefault: false });
    setShowForm(true);
  };

  const openEdit = (a: Address) => {
    setEditing(a);
    reset({
      label: (a.label as AddressInput['label']) ?? 'Home',
      line1: a.line1,
      line2: a.line2 ?? '',
      landmark: a.landmark ?? '',
      city: a.city,
      pincode: a.pincode,
      isDefault: a.isDefault,
    });
    setShowForm(true);
  };

  const onSubmit = async (values: AddressInput) => {
    try {
      await groveApi.saveAddress({ ...values, id: editing?.id });
      await qc.invalidateQueries({ queryKey: qk.addresses });
      refetch();
      toast(editing ? 'Address updated' : 'Address saved', 'success');
      setShowForm(false);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Could not save the address.', 'error');
    }
  };

  const remove = (a: Address) => {
    Alert.alert('Delete this address?', `${a.label} — ${a.line1}, ${a.city}`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setDeletingId(a.id);
          try {
            await groveApi.deleteAddress(a.id);
            await qc.invalidateQueries({ queryKey: qk.addresses });
            refetch();
            toast('Address deleted', 'info');
          } catch (e) {
            toast(e instanceof Error ? e.message : 'Could not delete this address.', 'error');
          } finally {
            setDeletingId(null);
          }
        },
      },
    ]);
  };

  const labelIcon = (label: string) =>
    label === 'Work' ? <Briefcase size={16} color={Colors.primary} /> : <Home size={16} color={Colors.primary} />;

  return (
    <View style={styles.flex}>
      <ScreenHeader
        title={showForm ? (editing ? 'Edit Address' : 'Add Address') : 'Saved Addresses'}
        onBack={() => (showForm ? setShowForm(false) : router.back())}
        right={
          !showForm ? (
            <Pressable onPress={openNew} hitSlop={10} accessibilityRole="button" accessibilityLabel="Add address">
              <Plus size={22} color={Colors.primary} />
            </Pressable>
          ) : null
        }
      />

      {showForm ? (
        <ScrollView
          contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.labelRow}>
            <Controller
              control={control}
              name="label"
              render={({ field: { onChange, value } }) => (
                <>
                  {(['Home', 'Work', 'Other'] as const).map((l) => (
                    <Pressable
                      key={l}
                      onPress={() => onChange(l)}
                      style={[styles.labelChip, value === l && styles.labelChipOn]}
                      accessibilityRole="radio"
                      accessibilityState={{ selected: value === l }}
                    >
                      <Text style={[styles.labelChipText, value === l && { color: Colors.primary }]}>{l}</Text>
                    </Pressable>
                  ))}
                </>
              )}
            />
          </View>

          <Controller
            control={control}
            name="line1"
            render={({ field: { onChange, onBlur, value } }) => (
              <TextField
                label="Flat / House no., Street"
                value={value}
                onChangeText={onChange}
                onBlur={onBlur}
                placeholder="123, Green Park"
                error={errors.line1?.message}
              />
            )}
          />
          <Controller
            control={control}
            name="line2"
            render={({ field: { onChange, onBlur, value } }) => (
              <TextField
                label="Area / Locality (optional)"
                value={value ?? ''}
                onChangeText={onChange}
                onBlur={onBlur}
                placeholder="Near Metro Station"
                error={errors.line2?.message}
              />
            )}
          />
          <Controller
            control={control}
            name="landmark"
            render={({ field: { onChange, value } }) => (
              <TextField
                label="Landmark (optional)"
                value={value ?? ''}
                onChangeText={onChange}
                placeholder="Opposite the park"
              />
            )}
          />
          <Controller
            control={control}
            name="city"
            render={({ field: { onChange, onBlur, value } }) => (
              <TextField label="City" value={value} onChangeText={onChange} onBlur={onBlur} error={errors.city?.message} />
            )}
          />
          <Controller
            control={control}
            name="pincode"
            render={({ field: { onChange, onBlur, value } }) => (
              <TextField
                label="Pincode"
                value={value}
                onChangeText={(v) => onChange(v.replace(/[^0-9]/g, '').slice(0, 6))}
                onBlur={onBlur}
                keyboardType="number-pad"
                placeholder="110016"
                error={errors.pincode?.message}
              />
            )}
          />

          <Controller
            control={control}
            name="isDefault"
            render={({ field: { onChange, value } }) => (
              <View style={styles.defaultRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.defaultLabel}>Set as default address</Text>
                  <Text style={styles.defaultSub}>Used automatically at checkout</Text>
                </View>
                <Switch
                  value={Boolean(value)}
                  onValueChange={onChange}
                  trackColor={{ true: Colors.primary, false: Colors.border }}
                  thumbColor={Colors.white}
                  accessibilityLabel="Set as default address"
                />
              </View>
            )}
          />

          <AppButton
            label={editing ? 'Save changes' : 'Save address'}
            onPress={handleSubmit(onSubmit)}
            loading={isSubmitting}
            style={{ marginTop: 8 }}
          />
        </ScrollView>
      ) : isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.primary} />
        </View>
      ) : isError ? (
        <EmptyState
          tone="error"
          title="Couldn’t load addresses"
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      ) : (data?.length ?? 0) === 0 ? (
        <EmptyState
          title="No saved addresses"
          subtitle="Add your home or work address for faster checkout."
          actionLabel="Add Address"
          onAction={openNew}
        />
      ) : (
        <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]}>
          {data!.map((a) => (
            <View key={a.id} style={styles.card}>
              <View style={styles.cardHead}>
                <View style={styles.iconBox}>{labelIcon(a.label)}</View>
                <View style={{ flex: 1 }}>
                  <View style={styles.labelLine}>
                    <Text style={styles.cardLabel}>{a.label}</Text>
                    {a.isDefault ? (
                      <View style={styles.defaultBadge}>
                        <Text style={styles.defaultBadgeText}>Default</Text>
                      </View>
                    ) : null}
                  </View>
                  <Text style={styles.cardText}>
                    {a.line1}
                    {a.line2 ? `, ${a.line2}` : ''}
                  </Text>
                  <Text style={styles.cardSub}>
                    {a.city} — {a.pincode}
                    {a.landmark ? ` • ${a.landmark}` : ''}
                  </Text>
                </View>
              </View>
              <View style={styles.cardActions}>
                <Pressable onPress={() => openEdit(a)} style={styles.smallBtn} accessibilityRole="button" accessibilityLabel={`Edit ${a.label} address`}>
                  <Pencil size={14} color={Colors.primary} />
                  <Text style={styles.smallBtnText}>Edit</Text>
                </Pressable>
                <Pressable
                  onPress={() => remove(a)}
                  disabled={deletingId === a.id}
                  style={[styles.smallBtn, styles.deleteBtn]}
                  accessibilityRole="button"
                  accessibilityLabel={`Delete ${a.label} address`}
                >
                  {deletingId === a.id ? (
                    <ActivityIndicator size="small" color={Colors.danger} />
                  ) : (
                    <>
                      <Trash2 size={14} color={Colors.danger} />
                      <Text style={[styles.smallBtnText, { color: Colors.danger }]}>Delete</Text>
                    </>
                  )}
                </Pressable>
              </View>
            </View>
          ))}

          <Pressable onPress={openNew} style={styles.addNew} accessibilityRole="button">
            <MapPin size={18} color={Colors.primary} />
            <Text style={styles.addNewText}>Add another address</Text>
          </Pressable>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 16 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  labelRow: { flexDirection: 'row', gap: 10, marginBottom: 18 },
  labelChip: {
    flex: 1,
    minHeight: 44,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  labelChipOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  labelChipText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  defaultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    padding: 14,
    marginBottom: 16,
  },
  defaultLabel: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  defaultSub: { ...Typography.caption, marginTop: 2 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 14,
    marginBottom: 12,
    ...Shadow.soft,
  },
  cardHead: { flexDirection: 'row', gap: 12 },
  iconBox: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  labelLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardLabel: { ...Typography.bodyBold, fontSize: 14 },
  defaultBadge: { backgroundColor: Colors.successSoft, paddingHorizontal: 7, paddingVertical: 2, borderRadius: Radius.pill },
  defaultBadgeText: { fontSize: 10, fontWeight: '700', color: Colors.success },
  cardText: { ...Typography.secondary, marginTop: 3, lineHeight: 19 },
  cardSub: { ...Typography.caption, marginTop: 2 },
  cardActions: { flexDirection: 'row', gap: 10, marginTop: 12, borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 10 },
  smallBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.pill,
    backgroundColor: Colors.primarySoft,
  },
  deleteBtn: { backgroundColor: Colors.dangerSoft },
  smallBtnText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  addNew: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: Colors.primary,
    borderRadius: Radius.lg,
    paddingVertical: 18,
    backgroundColor: Colors.primarySoft,
  },
  addNewText: { color: Colors.primary, fontWeight: '700' },
});
