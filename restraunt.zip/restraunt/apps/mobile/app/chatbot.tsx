import { router } from 'expo-router';
import { ChefHat, Phone, Send, ShieldCheck } from 'lucide-react-native';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import type { ChatMessage } from '@grove/shared';
import { groveApi } from '@/services/client';
import { useAuthStore } from '@/store/auth';
import { RESTAURANT_PHONE } from '@/data/seed';
import { relativeTime } from '@/utils/format';

const SUGGESTIONS = [
  "Show me today's specials",
  'Recommend a dish for me',
  'Track my order',
  'Book a table',
  'Show vegetarian dishes',
  'Any nut-free options?',
  'Contact restaurant support',
];

const WELCOME: ChatMessage = {
  id: 'welcome',
  role: 'assistant',
  text:
    "Hi! I'm the Grove assistant 🌿\n\nI can help with the menu, opening hours, allergens, bookings and your order status. I only answer from our restaurant data — if I'm unsure, I'll connect you to the team.",
  createdAt: new Date().toISOString(),
};

export default function ChatbotScreen() {
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollView>(null);
  const profile = useAuthStore((s) => s.profile);

  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const id = setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
    return () => clearTimeout(id);
  }, [messages, typing]);

  const send = async (text: string) => {
    const clean = text.trim();
    if (!clean || typing) return;
    setInput('');
    setError(null);
    const userMsg: ChatMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: clean,
      createdAt: new Date().toISOString(),
    };
    setMessages((m) => [...m, userMsg]);
    setTyping(true);
    try {
      const reply = await groveApi.sendChat(clean);
      setMessages((m) => [...m, reply]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The assistant is unavailable right now.');
    } finally {
      setTyping(false);
    }
  };

  return (
    <View style={styles.flex}>
      <ScreenHeader
        title="AI Assistant"
        onBack={() => router.back()}
        right={
          <Pressable
            onPress={() => router.push('/help')}
            style={styles.headBtn}
            accessibilityRole="button"
            accessibilityLabel="Contact human support"
          >
            <Phone size={18} color={Colors.primary} />
          </Pressable>
        }
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 8 : 0}
      >
        {/* assistant header */}
        <View style={styles.assistantBar}>
          <View style={styles.avatar}>
            <ChefHat size={20} color={Colors.primary} />
            <View style={styles.online} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.assistantName}>The Grove Assistant</Text>
            <View style={styles.statusRow}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>Online • replies in seconds</Text>
            </View>
          </View>
          <View style={styles.trust}>
            <ShieldCheck size={13} color={Colors.success} />
            <Text style={styles.trustText}>Menu-verified</Text>
          </View>
        </View>

        <ScrollView
          ref={scrollRef}
          style={{ flex: 1 }}
          contentContainerStyle={styles.chat}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {messages.map((m) => (
            <Animated.View
              key={m.id}
              entering={FadeInUp.duration(220)}
              style={[styles.bubbleRow, m.role === 'user' ? styles.rowRight : styles.rowLeft]}
            >
              {m.role === 'assistant' ? (
                <View style={styles.miniAvatar}>
                  <ChefHat size={14} color={Colors.primary} />
                </View>
              ) : null}
              <View style={[styles.bubble, m.role === 'user' ? styles.userBubble : styles.assistantBubble]}>
                <Text style={[styles.bubbleText, m.role === 'user' && styles.userText]}>{m.text}</Text>
                <Text style={[styles.time, m.role === 'user' && styles.userTime]}>{relativeTime(m.createdAt)}</Text>
              </View>
            </Animated.View>
          ))}

          {typing ? (
            <View style={[styles.bubbleRow, styles.rowLeft]}>
              <View style={styles.miniAvatar}>
                <ChefHat size={14} color={Colors.primary} />
              </View>
              <View style={[styles.bubble, styles.assistantBubble, styles.typing]}>
                <ActivityIndicator size="small" color={Colors.primary} />
                <Text style={styles.typingText}>Typing…</Text>
              </View>
            </View>
          ) : null}

          {error ? (
            <View style={styles.errorBox} accessibilityRole="alert">
              <Text style={styles.errorText}>{error}</Text>
              <Pressable
                onPress={() => {
                  const lastUser = [...messages].reverse().find((m) => m.role === 'user');
                  send(lastUser?.text ?? 'Hello');
                }}
              >
                <Text style={styles.retry}>Retry</Text>
              </Pressable>
            </View>
          ) : null}

          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.suggestions}>
            {SUGGESTIONS.map((s) => (
              <Pressable
                key={s}
                onPress={() => send(s)}
                style={styles.suggestion}
                accessibilityRole="button"
                accessibilityLabel={`Ask: ${s}`}
              >
                <Text style={styles.suggestionText}>{s}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <View style={{ height: 12 }} />
        </ScrollView>

        {/* composer */}
        <View style={[styles.composer, { paddingBottom: Math.max(insets.bottom, 10) }]}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder={`Type a message${profile?.locale === 'hi' ? '… हिंदी में भी लिख सकते हैं' : '…'}`}
            placeholderTextColor={Colors.textMuted}
            style={styles.input}
            multiline
            maxLength={500}
            onSubmitEditing={() => send(input)}
            accessibilityLabel="Message the assistant"
          />
          <Pressable
            onPress={() => send(input)}
            disabled={!input.trim() || typing}
            style={[styles.sendBtn, (!input.trim() || typing) && { backgroundColor: Colors.disabled }]}
            accessibilityRole="button"
            accessibilityLabel="Send message"
          >
            <Send size={18} color={!input.trim() || typing ? Colors.textMuted : Colors.white} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  headBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  assistantBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: Colors.backgroundAlt,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  online: {
    position: 'absolute',
    right: 1,
    bottom: 1,
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: Colors.success,
    borderWidth: 2,
    borderColor: Colors.backgroundAlt,
  },
  assistantName: { ...Typography.bodyBold, fontSize: 14 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.success },
  statusText: { ...Typography.caption, fontSize: 11 },
  trust: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.successSoft,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.pill,
  },
  trustText: { fontSize: 10, fontWeight: '700', color: Colors.success },
  chat: { padding: 16, gap: 10 },
  bubbleRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 6 },
  rowLeft: { justifyContent: 'flex-start' },
  rowRight: { justifyContent: 'flex-end' },
  miniAvatar: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bubble: { maxWidth: '78%', borderRadius: Radius.lg, paddingHorizontal: 13, paddingVertical: 10 },
  assistantBubble: {
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
    borderBottomLeftRadius: 4,
  },
  userBubble: { backgroundColor: Colors.primary, borderBottomRightRadius: 4, ...Shadow.soft },
  bubbleText: { ...Typography.body, fontSize: 14, lineHeight: 20 },
  userText: { color: Colors.white },
  time: { ...Typography.caption, fontSize: 10, color: Colors.textMuted, marginTop: 4 },
  userTime: { color: 'rgba(255,255,255,0.75)' },
  typing: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  typingText: { ...Typography.caption, fontSize: 12 },
  errorBox: {
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginTop: 6,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  errorText: { ...Typography.caption, color: Colors.danger, flex: 1 },
  retry: { color: Colors.danger, fontWeight: '800', fontSize: 12 },
  suggestions: { gap: 8, paddingTop: 12, paddingBottom: 4, paddingRight: 12 },
  suggestion: {
    borderWidth: 1,
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  suggestionText: { fontSize: 12, fontWeight: '600', color: Colors.primary },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    backgroundColor: Colors.white,
    paddingHorizontal: 14,
    paddingTop: 10,
  },
  input: {
    flex: 1,
    minHeight: 46,
    maxHeight: 120,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.backgroundAlt,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  sendBtn: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.floating,
  },
});
