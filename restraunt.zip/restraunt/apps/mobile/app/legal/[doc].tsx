import { router, useLocalSearchParams } from 'expo-router';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Typography } from '@/constants/theme';
import { RESTAURANT_ADDRESS_LINE } from '@/data/seed';

const PRIVACY = [
  {
    h: 'What we collect',
    p: 'Your name, email, phone number, delivery addresses, order history, reservations and favourites. Payment details are processed by Razorpay — we never receive or store your card number, CVV or UPI PIN.',
  },
  {
    h: 'How we use it',
    p: 'To prepare and deliver your orders, send status updates, honour reservations, process refunds, and improve the menu based on aggregate demand. We do not sell personal data.',
  },
  {
    h: 'Who can see your data',
    p: 'Restaurant staff see only the details needed to fulfil your order (name, phone, address, items, notes). Delivery partners see the delivery address and contact number for active orders only.',
  },
  {
    h: 'Retention',
    p: 'Order records are kept for 8 years as required by Indian tax law. Profile data, addresses and favourites are deleted within 7 days of an approved deletion request. Analytics events are anonymised after 90 days.',
  },
  {
    h: 'Your controls',
    p: 'You can edit your profile, delete addresses, clear favourites, turn off marketing notifications, and request full account deletion in Settings → Privacy.',
  },
  {
    h: 'Cookies and analytics',
    p: 'The mobile app uses no advertising cookies. Optional product analytics are off by default and can be enabled in Settings.',
  },
  {
    h: 'Contact',
    p: `Data protection queries: privacy@thegrove.in. Postal address: ${RESTAURANT_ADDRESS_LINE}.`,
  },
];

const TERMS = [
  {
    h: 'Orders and pricing',
    p: 'All prices are in Indian Rupees and include applicable GST unless stated otherwise. The payable total is calculated server-side at checkout; menu prices may change without notice but the price shown when you confirm is the price you pay.',
  },
  {
    h: 'Payments',
    p: 'Online payments are handled by Razorpay and verified on our server. An order is only confirmed once payment verification succeeds. Cash on Delivery is available at the restaurant’s discretion.',
  },
  {
    h: 'Cancellations and refunds',
    p: 'You may cancel free of charge while an order is pending or confirmed. Once preparation begins, cancellation is at the restaurant’s discretion. Approved refunds are processed to the original payment method within 5–7 business days.',
  },
  {
    h: 'Delivery',
    p: 'Delivery times are estimates, not guarantees. Someone aged 18 or above must receive the order. If we cannot reach you after 10 minutes at the address, the order may be cancelled without refund.',
  },
  {
    h: 'Reservations',
    p: 'Tables are held for 15 minutes past the booked time. Bookings are subject to capacity and may be declined for operational reasons; you will be notified and no charge applies.',
  },
  {
    h: 'Allergies',
    p: 'Dishes are prepared in a kitchen that handles dairy, nuts, gluten, egg and soy. We cannot guarantee an allergen-free environment. Always review the allergen list and call us for severe allergies.',
  },
  {
    h: 'Acceptable use',
    p: 'Do not misuse the platform, submit false orders, or attempt to access other customers’ data. We may suspend accounts that abuse the service or the support team.',
  },
  {
    h: 'Liability',
    p: 'Our liability for any order is limited to the amount paid for that order, except where Indian law provides otherwise. Nothing in these terms limits your statutory consumer rights.',
  },
  {
    h: 'Governing law',
    p: 'These terms are governed by the laws of India. Disputes are subject to the exclusive jurisdiction of the courts of New Delhi.',
  },
];

export default function LegalScreen() {
  const { doc } = useLocalSearchParams<{ doc: string }>();
  const insets = useSafeAreaInsets();
  const isPrivacy = doc !== 'terms';
  const sections = isPrivacy ? PRIVACY : TERMS;

  return (
    <View style={styles.flex}>
      <ScreenHeader title={isPrivacy ? 'Privacy Policy' : 'Terms & Conditions'} onBack={() => router.back()} />
      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>{isPrivacy ? 'Privacy Policy' : 'Terms & Conditions'}</Text>
        <Text style={styles.updated}>Last updated 1 October 2026</Text>
        <Text style={styles.intro}>
          {isPrivacy
            ? 'The Grove Restaurant & Cafe respects your privacy. This policy explains what we collect, why, and the control you have over your data.'
            : 'These terms govern your use of The Grove app and website, including orders, payments and table reservations.'}
        </Text>

        {sections.map((s, i) => (
          <View key={s.h} style={styles.block}>
            <Text style={styles.h}>
              {i + 1}. {s.h}
            </Text>
            <Text style={styles.p}>{s.p}</Text>
          </View>
        ))}

        <Text style={styles.footer}>
          Questions? Write to {isPrivacy ? 'privacy@thegrove.in' : 'support@thegrove.in'} and we will respond within 7
          business days.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 20 },
  title: { ...Typography.h1 },
  updated: { ...Typography.caption, marginTop: 4 },
  intro: { ...Typography.secondary, marginTop: 14, lineHeight: 21 },
  block: { marginTop: 20 },
  h: { ...Typography.h3, fontSize: 15, marginBottom: 6 },
  p: { ...Typography.secondary, lineHeight: 21 },
  footer: { ...Typography.caption, marginTop: 28, color: Colors.textMuted, lineHeight: 18 },
});
