import { Tabs, router } from 'expo-router';
import { ClipboardList, House, UserRound, UtensilsCrossed } from 'lucide-react-native';
import { StyleSheet } from 'react-native';
import { DrawerMenu } from '@/components/DrawerMenu';
import { Colors, Shadow } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { useDrawerStore, useToastStore } from '@/store/ui';

const ICONS = {
  home: House,
  menu: UtensilsCrossed,
  orders: ClipboardList,
  profile: UserRound,
} as const;

export default function TabsLayout() {
  const status = useAuthStore((s) => s.status);
  const toast = useToastStore((s) => s.show);

  // unauthenticated users can browse the menu, but Profile requires a session
  const requireSession = () => {
    if (status !== 'signedIn') {
      toast('Please sign in to view your profile.', 'info');
      router.push('/(auth)/login');
      return false;
    }
    return true;
  };

  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: Colors.primary,
          tabBarInactiveTintColor: Colors.textSecondary,
          tabBarStyle: styles.bar,
          tabBarLabelStyle: styles.label,
          tabBarItemStyle: { paddingTop: 6 },
          sceneStyle: { backgroundColor: Colors.background },
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: 'Home',
            tabBarIcon: ({ color, focused }) => {
              const Icon = ICONS.home;
              return <Icon size={22} color={color} strokeWidth={focused ? 2.4 : 1.8} />;
            },
          }}
        />
        <Tabs.Screen
          name="menu"
          options={{
            title: 'Menu',
            tabBarIcon: ({ color, focused }) => {
              const Icon = ICONS.menu;
              return <Icon size={22} color={color} strokeWidth={focused ? 2.4 : 1.8} />;
            },
          }}
        />
        <Tabs.Screen
          name="orders"
          options={{
            title: 'Orders',
            tabBarIcon: ({ color, focused }) => {
              const Icon = ICONS.orders;
              return <Icon size={22} color={color} strokeWidth={focused ? 2.4 : 1.8} />;
            },
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: 'Profile',
            tabBarIcon: ({ color, focused }) => {
              const Icon = ICONS.profile;
              return <Icon size={22} color={color} strokeWidth={focused ? 2.4 : 1.8} />;
            },
            listeners: {
              tabPress: (e) => {
                if (status !== 'signedIn') {
                  e.preventDefault();
                  requireSession();
                }
              },
            },
          }}
        />
      </Tabs>
      <DrawerMenu />
    </>
  );
}

const styles = StyleSheet.create({
  bar: {
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    height: 62,
    paddingBottom: 8,
    paddingTop: 4,
    ...Shadow.soft,
  },
  label: { fontSize: 11, fontWeight: '600', marginTop: -2 },
});
