import { router } from 'expo-router';
import { Bike, Bell, CalendarDays, Menu as MenuIcon, Search, ShoppingBag, Store, Utensils } from 'lucide-react-native';
import { useMemo, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CardSkeleton, EmptyState } from '@/components/Bits';
import { FoodCard } from '@/components/FoodCard';
import { SafeImage } from '@/components/SafeImage';
import { ViewCartBar } from '@/components/ViewCartBar';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { DEFAULT_RESTAURANT_CONFIG } from '@grove/shared';
import { useMenu } from '@/hooks/useQueries';
import { useAuthStore, useStrings } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useDrawerStore, useToastStore } from '@/store/ui';

const SERVICES = [
  { key: 'dine_in', label: 'Dine In', icon: Utensils },
  { key: 'takeaway', label: 'Takeaway', icon: ShoppingBag },
  { key: 'delivery', label: 'Delivery', icon: Bike },
  { key: 'book', label: 'Table Book', icon: CalendarDays },
] as const;

export default function Home() {
  const insets = useSafeAreaInsets();
  const openDrawer = useDrawerStore((s) => s.setOpen);
  const toast = useToastStore((s) => s.show);
  const t = useStrings();
  const isSignedIn = useAuthStore((s) => s.status === 'signedIn');

  const { data: menu, isLoading, isError, refetch, isRefetching } = useMenu();
  const addItem = useCartStore((s) => s.addItem);
  const setOrderType = useCartStore((s) => s.setOrderType);
  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);
  const [query, setQuery] = useState('');

  const popular = useMemo(() => {
    const list = [...(menu ?? [])].filter((m) => m.isAvailable);
    return list.sort((a, b) => b.rating * b.reviewCount - a.rating * a.reviewCount).slice(0, 6);
  }, [menu]);

  const specials = useMemo(() => (menu ?? []).filter((m) => m.isSpecial && m.isAvailable).slice(0, 4), [menu]);

  const quickAdd = (item: (typeof popular)[number]) => {
    addItem({
      menuItemId: item.id,
      name: item.name,
      imageUrl: item.imageUrl,
      basePriceMinor: item.discountedPriceMinor ?? item.priceMinor,
      addOns: [],
      quantity: 1,
    });
    toast(`${item.name} added to cart`, 'success');
  };

  const onService = (key: (typeof SERVICES)[number]['key']) => {
    if (key === 'book') {
      if (!isSignedIn) {
        toast('Please sign in to book a table.', 'info');
        router.push('/(auth)/login');
        return;
      }
      router.push('/booking');
      return;
    }
    setOrderType(key);
    toast(`Order type: ${key === 'dine_in' ? 'Dine In' : key === 'takeaway' ? 'Takeaway' : 'Delivery'}`, 'info');
    router.push('/(tabs)/menu');
  };

  return (
    <View style={styles.flex}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 12 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <Pressable
            onPress={() => openDrawer(true)}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel="Open side menu"
          >
            <MenuIcon size={22} color={Colors.textPrimary} />
          </Pressable>
          <View style={styles.headerBrand}>
            <View style={styles.headerLogo}>
              <Store size={16} color={Colors.primary} />
            </View>
            <View>
              <Text style={styles.brandName}>The Grove</Text>
              <Text style={styles.brandSub}>RESTAURANT & CAFE</Text>
            </View>
          </View>
          <Pressable
            onPress={() => toast('You’re all caught up — no new notifications.', 'info')}
            style={styles.iconBtn}
            accessibilityRole="button"
            accessibilityLabel="Notifications"
          >
            <Bell size={21} color={Colors.textPrimary} />
          </Pressable>
        </View>

        {/* Search */}
        <View style={styles.searchWrap}>
          <Search size={18} color={Colors.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder={t.search}
            placeholderTextColor={Colors.textMuted}
            style={styles.searchInput}
            returnKeyType="search"
            onSubmitEditing={() => router.push({ pathname: '/(tabs)/menu', params: { q: query } })}
            accessibilityLabel="Search dishes"
          />
        </View>

        {/* Promo banner */}
        <Pressable
          onPress={() => router.push('/(tabs)/menu')}
          style={styles.banner}
          accessibilityRole="button"
          accessibilityLabel="Delicious food freshly made — order now"
        >
          <SafeImage
            uri="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1000&q=70"
            style={StyleSheet.absoluteFill}
            rounded={Radius.xl}
            label="Chef special thali"
          />
          <View style={styles.bannerTint} />
          <View style={styles.bannerBody}>
            <Text style={styles.bannerTitle}>Delicious Food{'\n'}Freshly Made</Text>
            <Text style={styles.bannerSub}>Good Food • fresh ingredients • fast delivery</Text>
            <View style={styles.bannerBtn}>
              <Text style={styles.bannerBtnText}>{t.orderNow}</Text>
            </View>
          </View>
        </Pressable>

        {/* Service shortcuts */}
        <View style={styles.services}>
          {SERVICES.map((s) => (
            <Pressable
              key={s.key}
              onPress={() => onService(s.key)}
              style={styles.service}
              accessibilityRole="button"
              accessibilityLabel={s.label}
            >
              <View style={styles.serviceIcon}>
                <s.icon size={20} color={Colors.primary} strokeWidth={1.9} />
              </View>
              <Text style={styles.serviceLabel}>{s.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Popular dishes */}
        <View style={styles.sectionHead}>
          <Text style={styles.sectionTitle}>{t.popular}</Text>
          <Pressable onPress={() => router.push('/(tabs)/menu')} accessibilityRole="link">
            <Text style={styles.viewAll}>View All</Text>
          </Pressable>
        </View>

        {isLoading ? (
          <View style={styles.cardsRow}>
            {[0, 1].map((i) => (
              <CardSkeleton key={i} />
            ))}
          </View>
        ) : isError ? (
          <EmptyState
            tone="error"
            title="Couldn’t load the menu"
            subtitle="Check your connection and try again."
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        ) : popular.length === 0 ? (
          <EmptyState title="No dishes available right now" subtitle="Please check back soon." />
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
            {popular.map((item) => (
              <FoodCard
                key={item.id}
                item={item}
                variant="grid"
                inCart={lines.some((l) => l.menuItemId === item.id)}
                onPress={() => router.push({ pathname: '/item/[id]', params: { id: item.id } })}
                onAdd={() => quickAdd(item)}
              />
            ))}
          </ScrollView>
        )}

        {/* Special offers strip */}
        <View style={[styles.sectionHead, { marginTop: 26 }]}>
          <Text style={styles.sectionTitle}>Today’s Specials</Text>
          <Pressable onPress={() => router.push('/offers')} accessibilityRole="link">
            <Text style={styles.viewAll}>Offers</Text>
          </Pressable>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
          {specials.length === 0 ? (
            <View style={styles.noSpecial}>
              <Text style={Typography.secondary}>No specials today — check the full menu.</Text>
            </View>
          ) : (
            specials.map((item) => (
              <FoodCard
                key={item.id}
                item={item}
                variant="grid"
                inCart={lines.some((l) => l.menuItemId === item.id)}
                onPress={() => router.push({ pathname: '/item/[id]', params: { id: item.id } })}
                onAdd={() => quickAdd(item)}
              />
            ))
          )}
        </ScrollView>

        <View style={styles.footerNote}>
          <Text style={styles.footerText}>
            Open daily 9:00 AM – 11:00 PM • Free delivery above ₹499 • Min order ₹199
          </Text>
        </View>

        <View style={{ height: 110 }} />
      </ScrollView>

      <ViewCartBar
        lines={lines}
        orderType={orderType}
        config={DEFAULT_RESTAURANT_CONFIG}
        onPress={() => router.push('/cart')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 16, paddingBottom: 20 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  iconBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.soft,
  },
  headerBrand: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerLogo: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandName: { fontSize: 17, fontWeight: '800', color: Colors.textPrimary },
  brandSub: { fontSize: 9, letterSpacing: 2.4, color: Colors.textSecondary, fontWeight: '600' },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.backgroundAlt,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.pill,
    paddingHorizontal: 16,
    height: 48,
  },
  searchInput: { flex: 1, fontSize: 15, color: Colors.textPrimary },
  banner: {
    height: 170,
    borderRadius: Radius.xl,
    overflow: 'hidden',
    marginTop: 16,
    justifyContent: 'center',
    backgroundColor: Colors.primarySoft,
  },
  bannerTint: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(23,23,23,0.32)' },
  bannerBody: { paddingHorizontal: 20 },
  bannerTitle: { fontSize: 24, fontWeight: '800', color: Colors.white, lineHeight: 30 },
  bannerSub: { fontSize: 13, color: 'rgba(255,255,255,0.9)', marginTop: 6 },
  bannerBtn: {
    marginTop: 14,
    alignSelf: 'flex-start',
    backgroundColor: Colors.primary,
    paddingHorizontal: 22,
    paddingVertical: 11,
    borderRadius: Radius.pill,
    ...Shadow.floating,
  },
  bannerBtnText: { color: Colors.white, fontWeight: '800', fontSize: 14 },
  services: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
  service: { alignItems: 'center', flex: 1, gap: 8 },
  serviceIcon: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#FFE9D6',
  },
  serviceLabel: { fontSize: 12, fontWeight: '600', color: Colors.textPrimary },
  sectionHead: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 26,
    marginBottom: 14,
  },
  sectionTitle: { ...Typography.h2, fontSize: 18 },
  viewAll: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
  hScroll: { paddingRight: 8 },
  cardsRow: { flexDirection: 'row', gap: 12 },
  noSpecial: {
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.lg,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  footerNote: { marginTop: 26, alignItems: 'center' },
  footerText: { ...Typography.caption, textAlign: 'center', color: Colors.textMuted },
});
