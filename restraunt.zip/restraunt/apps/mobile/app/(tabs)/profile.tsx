import { router } from 'expo-router';
import {
  CalendarDays,
  ChevronRight,
  CircleHelp,
  CreditCard,
  Heart,
  LogOut,
  MapPin,
  Pencil,
  ShieldCheck,
  TicketPercent,
  User2,
} from 'lucide-react-native';
import { useState } from 'react';
import { Alert, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState, StatusBadge } from '@/components/Bits';
import { SafeImage } from '@/components/SafeImage';
import { TextField } from '@/components/TextField';
import { AppButton } from '@/components/AppButton';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { RESERVATION_STATUS_LABELS, ROLE_LABELS } from '@grove/shared';
import { useReservations } from '@/hooks/useQueries';
import { useAuthStore } from '@/store/auth';
import { useFavouritesStore, useToastStore } from '@/store/ui';
import { formatDate, formatSlot } from '@/utils/format';

const MENU_ITEMS = [
  { label: 'My Orders', icon: CalendarDays, href: '/(tabs)/orders' },
  { label: 'My Reservations', icon: CalendarDays, href: '/booking' },
  { label: 'Saved Addresses', icon: MapPin, href: '/addresses' },
  { label: 'Payment Preferences', icon: CreditCard, href: '/settings' },
  { label: 'Offers & Coupons', icon: TicketPercent, href: '/offers' },
  { label: 'Favourites', icon: Heart, href: '/favourites' },
  { label: 'Help & Support', icon: CircleHelp, href: '/help' },
  { label: 'Privacy & Terms', icon: ShieldCheck, href: '/legal/privacy' },
];

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const profile = useAuthStore((s) => s.profile);
  const status = useAuthStore((s) => s.status);
  const signOut = useAuthStore((s) => s.signOut);
  const updateProfile = useAuthStore((s) => s.updateProfile);
  const toast = useToastStore((s) => s.show);
  const resetFavourites = useFavouritesStore((s) => s.reset);
  const { data: reservations, refetch, isRefetching } = useReservations(Boolean(profile));

  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.fullName ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [saving, setSaving] = useState(false);

  if (status !== 'signedIn' || !profile) {
    return (
      <View style={[styles.flex, { paddingTop: insets.top + 40 }]}>
        <EmptyState
          title="Your profile"
          subtitle="Sign in to manage orders, addresses and reservations."
          actionLabel="Sign In"
          onAction={() => router.push('/(auth)/login')}
        />
      </View>
    );
  }

  const save = async () => {
    if (name.trim().length < 2) {
      toast('Enter your full name.', 'error');
      return;
    }
    if (phone.replace(/\D/g, '').length !== 10) {
      toast('Enter a valid 10-digit mobile number.', 'error');
      return;
    }
    setSaving(true);
    try {
      await updateProfile({ fullName: name.trim(), phone: phone.replace(/\D/g, '') });
      setEditing(false);
      toast('Profile updated', 'success');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Could not save your profile.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const onLogout = () => {
    Alert.alert('Log out?', 'You can sign back in any time — your cart stays saved.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: async () => {
          await signOut();
          resetFavourites();
          toast('Logged out', 'info');
          router.replace('/');
        },
      },
    ]);
  };

  const upcoming = (reservations ?? []).filter((r) => ['pending', 'confirmed'].includes(r.status)).slice(0, 2);

  return (
    <ScrollView
      style={styles.flex}
      contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 16, paddingBottom: 40 }]}
      refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.headerRow}>
        <Text style={styles.heading}>Profile</Text>
        <Pressable
          onPress={() => setEditing((e) => !e)}
          style={styles.editBtn}
          accessibilityRole="button"
          accessibilityLabel={editing ? 'Cancel editing' : 'Edit profile'}
        >
          <Pencil size={16} color={Colors.primary} />
          <Text style={styles.editText}>{editing ? 'Cancel' : 'Edit'}</Text>
        </Pressable>
      </View>

      {/* identity card */}
      <View style={styles.card}>
        <View style={styles.identityRow}>
          <SafeImage uri={profile.avatarUrl} label={profile.fullName} style={styles.avatar} rounded={36} />
          <View style={{ flex: 1 }}>
            <Text style={styles.name} numberOfLines={1}>
              {profile.fullName}
            </Text>
            <Text style={styles.email} numberOfLines={1}>
              {profile.email}
            </Text>
            <View style={styles.rolePill}>
              <User2 size={11} color={Colors.primary} />
              <Text style={styles.roleText}>{ROLE_LABELS[profile.role]}</Text>
            </View>
          </View>
        </View>

        {editing ? (
          <View style={styles.editForm}>
            <TextField label="Full name" value={name} onChangeText={setName} placeholder="Your name" />
            <TextField
              label="Mobile number"
              value={phone}
              onChangeText={(v) => setPhone(v.replace(/[^0-9]/g, '').slice(0, 10))}
              keyboardType="phone-pad"
              placeholder="10-digit number"
            />
            <AppButton label="Save changes" onPress={save} loading={saving} />
          </View>
        ) : (
          <View style={styles.contactRows}>
            <View style={styles.contactRow}>
              <Text style={styles.contactLabel}>Phone</Text>
              <Text style={styles.contactValue}>{profile.phone ?? 'Not added'}</Text>
            </View>
            <View style={styles.contactRow}>
              <Text style={styles.contactLabel}>Language</Text>
              <Text style={styles.contactValue}>{profile.locale === 'hi' ? 'हिन्दी' : 'English'}</Text>
            </View>
          </View>
        )}
      </View>

      {/* reservations preview */}
      {upcoming.length > 0 ? (
        <View style={styles.card}>
          <View style={styles.sectionHead}>
            <Text style={styles.sectionTitle}>Upcoming Reservations</Text>
            <Pressable onPress={() => router.push('/booking')} accessibilityRole="link">
              <Text style={styles.link}>Manage</Text>
            </Pressable>
          </View>
          {upcoming.map((r) => (
            <Pressable
              key={r.id}
              onPress={() => router.push('/booking')}
              style={styles.reservation}
              accessibilityRole="button"
              accessibilityLabel={`Reservation ${r.code}, ${r.date} at ${r.time}`}
            >
              <View style={styles.resIcon}>
                <CalendarDays size={18} color={Colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.resTitle}>
                  {formatDate(`${r.date}T12:00:00`)} • {formatSlot(r.time)}
                </Text>
                <Text style={styles.resSub}>
                  {r.guests} guest{r.guests > 1 ? 's' : ''}
                  {r.tableNumber ? ` • Table ${r.tableNumber}` : ''} • {r.code}
                </Text>
              </View>
              <StatusBadge status={r.status} />
            </Pressable>
          ))}
        </View>
      ) : null}

      {/* menu */}
      <View style={styles.card}>
        {MENU_ITEMS.map((item, i) => (
          <Pressable
            key={item.label}
            onPress={() => router.push(item.href as never)}
            style={[styles.row, i < MENU_ITEMS.length - 1 && styles.rowBorder]}
            accessibilityRole="button"
            accessibilityLabel={item.label}
          >
            <item.icon size={20} color={Colors.primary} strokeWidth={1.9} />
            <Text style={styles.rowLabel}>{item.label}</Text>
            <ChevronRight size={18} color={Colors.textMuted} />
          </Pressable>
        ))}
      </View>

      <AppButton label="Log out" variant="danger" icon={<LogOut size={18} color={Colors.danger} />} onPress={onLogout} />

      <Text style={styles.version}>The Grove • v1.0.0 • Made with care in India</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 16, gap: 14 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  heading: { ...Typography.h1 },
  editBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: Radius.pill,
    backgroundColor: Colors.primarySoft,
  },
  editText: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    ...Shadow.soft,
  },
  identityRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  avatar: { width: 72, height: 72 },
  name: { ...Typography.h2, fontSize: 19 },
  email: { ...Typography.caption, marginTop: 3 },
  rolePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radius.pill,
    marginTop: 6,
  },
  roleText: { fontSize: 10, fontWeight: '700', color: Colors.primary },
  editForm: { marginTop: 16 },
  contactRows: { marginTop: 16, gap: 8 },
  contactRow: { flexDirection: 'row', justifyContent: 'space-between' },
  contactLabel: { ...Typography.caption },
  contactValue: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { ...Typography.h3, fontSize: 15 },
  link: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
  reservation: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8 },
  resIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resTitle: { ...Typography.bodyBold, fontSize: 14 },
  resSub: { ...Typography.caption, marginTop: 2 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 52 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  rowLabel: { ...Typography.body, flex: 1, fontSize: 14, fontWeight: '500' },
  version: { ...Typography.caption, textAlign: 'center', color: Colors.textMuted, marginTop: 8 },
});
