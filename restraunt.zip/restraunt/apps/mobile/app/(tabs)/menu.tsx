import { router, useLocalSearchParams } from 'expo-router';
import { Search, X } from 'lucide-react-native';
import { useEffect, useMemo, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CardSkeleton, Chip, EmptyState } from '@/components/Bits';
import { FoodCard } from '@/components/FoodCard';
import { ViewCartBar } from '@/components/ViewCartBar';
import { Colors, Radius, Typography } from '@/constants/theme';
import { DEFAULT_RESTAURANT_CONFIG } from '@grove/shared';
import { useDebounced, useMenu } from '@/hooks/useQueries';
import { useCartStore } from '@/store/cart';
import { useToastStore } from '@/store/ui';

const CATEGORIES = [
  { key: 'all', label: 'All' },
  { key: 'starters', label: 'Starters' },
  { key: 'main-course', label: 'Main Course' },
  { key: 'desserts', label: 'Desserts' },
  { key: 'beverages', label: 'Beverages' },
];

export default function MenuScreen() {
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const params = useLocalSearchParams<{ q?: string }>();
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState(params.q ?? '');
  const debouncedQuery = useDebounced(query, 300);

  const { data, isLoading, isError, refetch, isRefetching } = useMenu(category, debouncedQuery);
  const addItem = useCartStore((s) => s.addItem);
  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);

  useEffect(() => {
    if (params.q) setQuery(params.q);
  }, [params.q]);

  const menu = useMemo(() => data ?? [], [data]);

  const quickAdd = (item: (typeof menu)[number]) => {
    if (!item.isAvailable) {
      toast('This dish is currently sold out.', 'error');
      return;
    }
    addItem({
      menuItemId: item.id,
      name: item.name,
      imageUrl: item.imageUrl,
      basePriceMinor: item.discountedPriceMinor ?? item.priceMinor,
      addOns: [],
      quantity: 1,
    });
    toast(`${item.name} added to cart`, 'success');
  };

  const showSkeletons = isLoading && menu.length === 0;

  return (
    <View style={styles.flex}>
      <View style={[styles.head, { paddingTop: insets.top + 12 }]}>
        <Text style={styles.title}>Menu</Text>
        <View style={styles.searchWrap}>
          <Search size={18} color={Colors.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search for food, drinks..."
            placeholderTextColor={Colors.textMuted}
            style={styles.searchInput}
            returnKeyType="search"
            accessibilityLabel="Search the menu"
          />
          {query.length > 0 ? (
            <X size={18} color={Colors.textSecondary} onPress={() => setQuery('')} accessibilityRole="button" />
          ) : null}
        </View>

        <FlatList
          horizontal
          data={CATEGORIES}
          keyExtractor={(c) => c.key}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.chips}
          renderItem={({ item }) => (
            <Chip
              label={item.label}
              active={category === item.key}
              onPress={() => setCategory(item.key)}
            />
          )}
        />
      </View>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: 130 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />
        }
        ListEmptyComponent={
          showSkeletons ? (
            <View>
              {[0, 1, 2, 3].map((i) => (
                <CardSkeleton key={i} />
              ))}
            </View>
          ) : isError ? (
            <EmptyState
              tone="error"
              title="Couldn’t load dishes"
              subtitle="We couldn’t reach the kitchen’s menu right now."
              actionLabel="Retry"
              onAction={() => refetch()}
            />
          ) : (
            <EmptyState
              title="No dishes found"
              subtitle={
                query
                  ? `Nothing matches “${query}”. Try a different search or category.`
                  : 'This category has no available dishes right now.'
              }
              actionLabel={query ? 'Clear search' : undefined}
              onAction={query ? () => setQuery('') : undefined}
            />
          )
        }
        renderItem={({ item }) => (
          <FoodCard
            item={item}
            variant="row"
            inCart={lines.some((l) => l.menuItemId === item.id)}
            onPress={() => router.push({ pathname: '/item/[id]', params: { id: item.id } })}
            onAdd={() => quickAdd(item)}
          />
        )}
      />

      <ViewCartBar
        lines={lines}
        orderType={orderType}
        config={DEFAULT_RESTAURANT_CONFIG}
        onPress={() => router.push('/cart')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  head: {
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: { ...Typography.h1, marginBottom: 12 },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.backgroundAlt,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.pill,
    paddingHorizontal: 16,
    height: 48,
  },
  searchInput: { flex: 1, fontSize: 15, color: Colors.textPrimary },
  chips: { paddingTop: 14 },
  list: { paddingHorizontal: 16, paddingTop: 16 },
});
