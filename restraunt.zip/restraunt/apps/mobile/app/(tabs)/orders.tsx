import { router } from 'expo-router';
import { CalendarDays, ChevronRight, RefreshCw, RotateCcw, ShoppingBag } from 'lucide-react-native';
import { useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState, StatusBadge, Chip } from '@/components/Bits';
import { SafeImage } from '@/components/SafeImage';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { ORDER_STATUS_LABELS } from '@grove/shared';
import { useOrders } from '@/hooks/useQueries';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useDrawerStore, useToastStore } from '@/store/ui';
import { formatDateTime } from '@/utils/format';
import { money } from '@/utils/format';
import type { Order } from '@grove/shared';
import Animated, { FadeInUp } from 'react-native-reanimated';

type Filter = 'all' | 'delivered' | 'cancelled';

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'delivered', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

export default function OrdersScreen() {
  const insets = useSafeAreaInsets();
  const signedIn = useAuthStore((s) => s.status === 'signedIn');
  const openDrawer = useDrawerStore((s) => s.setOpen);
  const toast = useToastStore((s) => s.show);
  const addItem = useCartStore((s) => s.addItem);
  const [filter, setFilter] = useState<Filter>('all');
  const { data, isLoading, isError, refetch, isRefetching } = useOrders(filter);

  const orders = useMemo(() => data?.data ?? [], [data]);
  const active = useMemo(() => orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)), [orders]);

  const reorder = (order: Order) => {
    order.items.forEach((item) => {
      addItem({
        menuItemId: item.menuItemId ?? `custom_${item.id}`,
        name: item.name,
        imageUrl: item.imageUrl,
        basePriceMinor: item.unitPriceMinor - item.addOns.reduce((s, a) => s + a.priceMinor, 0),
        addOns: item.addOns.map((a) => ({ id: a.id, name: a.name, priceMinor: a.priceMinor })),
        quantity: item.quantity,
        specialInstructions: item.specialInstructions ?? undefined,
      });
    });
    toast('Items added to cart — prices are rechecked at checkout.', 'success');
    router.push('/cart');
  };

  if (!signedIn) {
    return (
      <View style={[styles.flex, { paddingTop: insets.top + 12 }]}>
        <Text style={styles.heading}>My Orders</Text>
        <EmptyState
          title="Sign in to see your orders"
          subtitle="Your order history, receipts and live tracking live here."
          actionLabel="Sign In"
          onAction={() => router.push('/(auth)/login')}
        />
      </View>
    );
  }

  return (
    <View style={[styles.flex, { paddingTop: insets.top + 12 }]}>
      <View style={styles.head}>
        <Text style={styles.heading}>My Orders</Text>
        <Pressable
          onPress={() => openDrawer(true)}
          style={styles.iconBtn}
          accessibilityRole="button"
          accessibilityLabel="Open side menu"
        >
          <CalendarDays size={20} color={Colors.textPrimary} />
        </Pressable>
      </View>

      <View style={styles.filters}>
        {FILTERS.map((f) => (
          <Chip key={f.key} label={f.label} active={filter === f.key} onPress={() => setFilter(f.key)} />
        ))}
      </View>

      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.primary} />
          <Text style={styles.loadingText}>Loading your orders…</Text>
        </View>
      ) : isError ? (
        <EmptyState
          tone="error"
          title="Couldn’t load orders"
          subtitle="Check your connection and try again."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      ) : orders.length === 0 ? (
        <EmptyState
          title={filter === 'all' ? 'No orders yet' : `No ${filter} orders`}
          subtitle="Hungry? Your favourites are a tap away."
          actionLabel="Browse Menu"
          onAction={() => router.push('/(tabs)/menu')}
        />
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(o) => o.id}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
          ListHeaderComponent={
            active.length > 0 && filter === 'all' ? (
              <View style={styles.activeBanner}>
                <ShoppingBag size={18} color={Colors.primary} />
                <Text style={styles.activeText}>
                  {active.length} active order{active.length > 1 ? 's' : ''} — tap to track live status
                </Text>
              </View>
            ) : null
          }
          renderItem={({ item, index }) => (
            <Animated.View entering={FadeInUp.delay(index * 40).duration(260)}>
              <Pressable
                onPress={() => router.push({ pathname: '/order/[id]', params: { id: item.id } })}
                style={({ pressed }) => [styles.card, pressed && { transform: [{ scale: 0.995 }] }]}
                accessibilityRole="button"
                accessibilityLabel={`Order ${item.orderNumber}, ${ORDER_STATUS_LABELS[item.status]}, ${money(item.totals.grandTotalMinor)}`}
              >
                <View style={styles.cardHead}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.orderNo}>#{item.orderNumber}</Text>
                    <Text style={styles.date}>{formatDateTime(item.createdAt)}</Text>
                  </View>
                  <StatusBadge status={item.status} />
                </View>

                <View style={styles.thumbs}>
                  {item.items.slice(0, 3).map((it) => (
                    <SafeImage
                      key={it.id}
                      uri={it.imageUrl}
                      label={it.name}
                      style={styles.thumb}
                      rounded={Radius.md}
                    />
                  ))}
                  {item.items.length > 3 ? (
                    <View style={[styles.thumb, styles.more]}>
                      <Text style={styles.moreText}>+{item.items.length - 3}</Text>
                    </View>
                  ) : null}
                  <View style={{ flex: 1 }} />
                  <Text style={styles.total}>{money(item.totals.grandTotalMinor)}</Text>
                </View>

                <View style={styles.cardFoot}>
                  <Text style={styles.itemCount} numberOfLines={1}>
                    {item.items.reduce((s, l) => s + l.quantity, 0)} items •{' '}
                    {item.type === 'delivery' ? 'Delivery' : item.type === 'takeaway' ? 'Takeaway' : 'Dine in'}
                  </Text>
                  <View style={styles.footActions}>
                    {item.status === 'cancelled' || item.status === 'delivered' ? (
                      <Pressable
                        onPress={() => reorder(item)}
                        style={styles.reorder}
                        accessibilityRole="button"
                        accessibilityLabel="Reorder these items"
                      >
                        <RotateCcw size={13} color={Colors.primary} />
                        <Text style={styles.reorderText}>Reorder</Text>
                      </Pressable>
                    ) : (
                      <Text style={styles.trackText}>Track order</Text>
                    )}
                    <ChevronRight size={18} color={Colors.textMuted} />
                  </View>
                </View>
              </Pressable>
            </Animated.View>
          )}
        />
      )}
      {isRefetching ? (
        <View style={styles.refreshPill}>
          <RefreshCw size={12} color={Colors.white} />
          <Text style={styles.refreshText}>Updating</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  head: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  heading: { ...Typography.h1 },
  iconBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
    ...Shadow.soft,
  },
  filters: { flexDirection: 'row', paddingHorizontal: 16, marginBottom: 12 },
  center: { alignItems: 'center', paddingTop: 50, gap: 10 },
  loadingText: { ...Typography.secondary },
  activeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 12,
  },
  activeText: { ...Typography.caption, color: Colors.textPrimary, fontWeight: '600', flex: 1 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 14,
    marginBottom: 12,
    ...Shadow.soft,
  },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  orderNo: { ...Typography.bodyBold, fontSize: 15 },
  date: { ...Typography.caption, marginTop: 2 },
  thumbs: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12 },
  thumb: { width: 46, height: 46 },
  more: { backgroundColor: Colors.backgroundAlt, alignItems: 'center', justifyContent: 'center' },
  moreText: { ...Typography.caption, fontWeight: '700' },
  total: { ...Typography.h3, fontSize: 16 },
  cardFoot: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: 10,
  },
  itemCount: { ...Typography.caption, flex: 1 },
  footActions: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  reorder: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: Radius.pill,
    backgroundColor: Colors.primarySoft,
  },
  reorderText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  trackText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  refreshPill: {
    position: 'absolute',
    top: 8,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: Colors.textPrimary,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: Radius.pill,
  },
  refreshText: { color: Colors.white, fontSize: 11, fontWeight: '600' },
});
