import { router } from 'expo-router';
import {
  Bell,
  ChevronRight,
  CreditCard,
  Globe,
  Lock,
  ShieldCheck,
  Trash2,
  UserRound,
} from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import type { Locale } from '@grove/shared';
import { useAuthStore } from '@/store/auth';
import { useToastStore } from '@/store/ui';
import { groveApi } from '@/services/client';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const locale = useAuthStore((s) => s.locale);
  const setLocale = useAuthStore((s) => s.setLocale);
  const profile = useAuthStore((s) => s.profile);
  const updateProfile = useAuthStore((s) => s.updateProfile);
  const signOut = useAuthStore((s) => s.signOut);

  const [orderUpdates, setOrderUpdates] = useState(profile?.notifyOrderUpdates ?? true);
  const [offers, setOffers] = useState(profile?.notifyOffers ?? true);
  const [reservationReminders, setReservationReminders] = useState(profile?.notifyReservations ?? true);
  const [analytics, setAnalytics] = useState(profile?.shareAnalytics ?? false);

  useEffect(() => {
    if (!profile) return;
    setOrderUpdates(profile.notifyOrderUpdates ?? true);
    setOffers(profile.notifyOffers ?? true);
    setReservationReminders(profile.notifyReservations ?? true);
    setAnalytics(profile.shareAnalytics ?? false);
  }, [profile]);

  /** Persist a preference; revert the switch if the server rejects it. */
  const persistPref = async (
    patch: Parameters<typeof updateProfile>[0],
    revert: () => void,
  ) => {
    try {
      await updateProfile(patch);
    } catch (err) {
      revert();
      toast(err instanceof Error ? err.message : 'Could not save that preference.', 'error');
    }
  };

  const chooseLocale = (next: Locale) => {
    setLocale(next);
    toast(next === 'hi' ? 'भाषा हिन्दी में सेट की गई' : 'Language set to English', 'success');
  };

  const requestDeletion = () => {
    Alert.alert(
      'Request account deletion?',
      'This permanently removes your profile, addresses, favourites and reservation history after a 7-day grace period. Orders are retained for tax compliance.',
      [
        { text: 'Keep account', style: 'cancel' },
        {
          text: 'Request deletion',
          style: 'destructive',
          onPress: async () => {
            try {
              await groveApi.requestAccountDeletion();
              toast('Deletion request sent. Our team will confirm by email within 7 days.', 'success');
            } catch (err) {
              toast(err instanceof Error ? err.message : 'Could not submit the deletion request.', 'error');
            }
          },
        },
      ],
    );
  };

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Settings" onBack={() => router.back()} />
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.section}>Account</Text>
        <View style={styles.card}>
          <Row
            icon={<UserRound size={18} color={Colors.primary} />}
            label="Profile details"
            sub={profile ? `${profile.fullName} • ${profile.email}` : 'Not signed in'}
            onPress={() => router.push('/(tabs)/profile')}
          />
          <Row
            icon={<CreditCard size={18} color={Colors.primary} />}
            label="Payment preferences"
            sub="Default method, saved UPI handles"
            onPress={() => toast('Razorpay stores payment methods securely — nothing is saved on this device.', 'info')}
            last
          />
        </View>

        <Text style={styles.section}>Appearance & Language</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <Globe size={18} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.rowLabel}>Language</Text>
              <Text style={styles.rowSub}>Chatbot and app copy</Text>
            </View>
          </View>
          <View style={styles.langRow}>
            {(['en', 'hi'] as Locale[]).map((l) => (
              <Pressable
                key={l}
                onPress={() => chooseLocale(l)}
                style={[styles.langChip, locale === l && styles.langChipOn]}
                accessibilityRole="radio"
                accessibilityState={{ selected: locale === l }}
              >
                <Text style={[styles.langText, locale === l && { color: Colors.primary }]}>
                  {l === 'en' ? 'English' : 'हिन्दी'}
                </Text>
              </Pressable>
            ))}
          </View>
          <Text style={styles.themeNote}>Light theme is the default and only theme for this release.</Text>
        </View>

        <Text style={styles.section}>Notifications</Text>
        <View style={styles.card}>
          <Toggle
            icon={<Bell size={18} color={Colors.primary} />}
            label="Order updates"
            sub="Cooking, dispatch and delivery status"
            value={orderUpdates}
            onChange={(v) => {
              setOrderUpdates(v);
              void persistPref({ notifyOrderUpdates: v }, () => setOrderUpdates(!v));
            }}
          />
          <Toggle
            label="Offers & coupons"
            sub="Weekly deals, no more than twice a week"
            value={offers}
            onChange={(v) => {
              setOffers(v);
              void persistPref({ notifyOffers: v }, () => setOffers(!v));
            }}
          />
          <Toggle
            label="Reservation reminders"
            sub="Two hours before your table"
            value={reservationReminders}
            onChange={(v) => {
              setReservationReminders(v);
              void persistPref({ notifyReservations: v }, () => setReservationReminders(!v));
            }}
            last
          />
        </View>

        <Text style={styles.section}>Privacy</Text>
        <View style={styles.card}>
          <Toggle
            label="Share usage analytics"
            sub="Helps us improve the app. Off by default."
            value={analytics}
            onChange={(v) => {
              setAnalytics(v);
              void persistPref({ shareAnalytics: v }, () => setAnalytics(!v));
            }}
          />
          <Row
            icon={<Lock size={18} color={Colors.primary} />}
            label="Privacy policy"
            onPress={() => router.push('/legal/privacy')}
          />
          <Row
            icon={<ShieldCheck size={18} color={Colors.primary} />}
            label="Terms & conditions"
            onPress={() => router.push('/legal/terms')}
            last
          />
        </View>

        <Pressable
          onPress={requestDeletion}
          style={styles.deleteCard}
          accessibilityRole="button"
          accessibilityLabel="Request account deletion"
        >
          <Trash2 size={18} color={Colors.danger} />
          <View style={{ flex: 1 }}>
            <Text style={styles.deleteTitle}>Request account deletion</Text>
            <Text style={styles.deleteSub}>Permanently remove your data after a 7-day grace period</Text>
          </View>
          <ChevronRight size={18} color={Colors.danger} />
        </Pressable>

        <Pressable
          onPress={async () => {
            await signOut();
            toast('Logged out', 'info');
            router.replace('/');
          }}
          style={styles.logout}
          accessibilityRole="button"
        >
          <Text style={styles.logoutText}>Log out</Text>
        </Pressable>

        <Text style={styles.version}>The Grove v1.0.0 • Build 1</Text>
      </ScrollView>
    </View>
  );
}

function Row({
  icon,
  label,
  sub,
  onPress,
  last,
}: {
  icon?: React.ReactNode;
  label: string;
  sub?: string;
  onPress: () => void;
  last?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.row, !last && styles.rowBorder]}
      accessibilityRole="button"
      accessibilityLabel={label}
    >
      {icon}
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLabel}>{label}</Text>
        {sub ? <Text style={styles.rowSub}>{sub}</Text> : null}
      </View>
      <ChevronRight size={18} color={Colors.textMuted} />
    </Pressable>
  );
}

function Toggle({
  icon,
  label,
  sub,
  value,
  onChange,
  last,
}: {
  icon?: React.ReactNode;
  label: string;
  sub?: string;
  value: boolean;
  onChange: (v: boolean) => void;
  last?: boolean;
}) {
  return (
    <View style={[styles.row, !last && styles.rowBorder]}>
      {icon}
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLabel}>{label}</Text>
        {sub ? <Text style={styles.rowSub}>{sub}</Text> : null}
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ true: Colors.primary, false: Colors.border }}
        thumbColor={Colors.white}
        accessibilityLabel={label}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 16 },
  section: { ...Typography.caption, fontWeight: '700', color: Colors.textSecondary, marginTop: 18, marginBottom: 8, letterSpacing: 0.6 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 14,
    ...Shadow.soft,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 58, paddingVertical: 10 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: Colors.border },
  rowLabel: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  rowSub: { ...Typography.caption, marginTop: 2 },
  langRow: { flexDirection: 'row', gap: 10, paddingBottom: 12 },
  langChip: {
    flex: 1,
    minHeight: 44,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  langChipOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  langText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  themeNote: { ...Typography.caption, color: Colors.textMuted, paddingBottom: 14 },
  deleteCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 18,
    borderWidth: 1,
    borderColor: Colors.dangerSoft,
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.lg,
    padding: 14,
  },
  deleteTitle: { ...Typography.body, fontSize: 14, fontWeight: '700', color: Colors.danger },
  deleteSub: { ...Typography.caption, marginTop: 2 },
  logout: {
    marginTop: 14,
    minHeight: 50,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutText: { ...Typography.bodyBold, color: Colors.danger },
  version: { ...Typography.caption, textAlign: 'center', color: Colors.textMuted, marginTop: 16 },
});
