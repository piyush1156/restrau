import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Banknote, Bike, CheckCircle2, CreditCard, MapPin, MessageSquareText, Phone, ShoppingBag } from 'lucide-react-native';
import { useEffect, useMemo, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { AppButton } from '@/components/AppButton';
import { EmptyState } from '@/components/Bits';
import { SafeImage } from '@/components/SafeImage';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import {
  cartSubtotal,
  computeTotals,
  DEFAULT_RESTAURANT_CONFIG,
  checkoutSchema,
  type CheckoutInput,
  type Coupon,
} from '@grove/shared';
import { PaymentCancelled, openRazorpayCheckout } from '@/services/payments';
import { groveApi } from '@/services/client';
import { useAddresses } from '@/hooks/useQueries';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useToastStore } from '@/store/ui';
import { money } from '@/utils/format';

const CONFIG = DEFAULT_RESTAURANT_CONFIG;

export default function CheckoutScreen() {
  const toast = useToastStore((s) => s.show);
  const profile = useAuthStore((s) => s.profile);
  const status = useAuthStore((s) => s.status);

  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);
  const setOrderType = useCartStore((s) => s.setOrderType);
  const couponCode = useCartStore((s) => s.couponCode);
  const attemptId = useCartStore((s) => s.checkoutAttemptId);
  const clearCart = useCartStore((s) => s.clear);
  const syncLines = useCartStore((s) => s.syncLines);

  const { data: addresses, isLoading: loadingAddresses } = useAddresses(status === 'signedIn');
  const [stage, setStage] = useState<'idle' | 'validating' | 'placing' | 'paying'>('idle');
  const [serverError, setServerError] = useState<string | null>(null);
  const [pendingOrderId, setPendingOrderId] = useState<string | null>(null);
  const [coupon, setCoupon] = useState<Coupon | null>(null);

  // Revalidate a cart coupon against live rules so the bill shown here matches the server total.
  useEffect(() => {
    let alive = true;
    if (!couponCode) {
      setCoupon(null);
      return;
    }
    groveApi
      .validateCoupon(couponCode, cartSubtotal(lines))
      .then((c) => alive && setCoupon(c))
      .catch(() => alive && setCoupon(null));
    return () => {
      alive = false;
    };
  }, [couponCode, lines]);

  const defaultAddress = useMemo(() => addresses?.find((a) => a.isDefault) ?? addresses?.[0] ?? null, [addresses]);

  const {
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<CheckoutInput>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      addressId: defaultAddress?.id ?? null,
      type: orderType === 'dine_in' ? 'delivery' : orderType,
      paymentMethod: 'razorpay',
      deliveryInstructions: '',
      contactPhone: profile?.phone ?? '',
      couponCode: couponCode ?? '',
    },
    mode: 'onTouched',
  });

  const type = watch('type');
  const paymentMethod = watch('paymentMethod');

  const totals = computeTotals({ lines, coupon, config: CONFIG, orderType: type });

  const startPayment = async (orderId: string, contact: string) => {
    setStage('paying');
    try {
      const paymentOrder = await groveApi.createPaymentOrder(orderId);
      const res = await openRazorpayCheckout(paymentOrder, {
        name: profile?.fullName ?? 'Customer',
        email: profile?.email,
        contact,
      });
      await groveApi.verifyPayment({
        orderId,
        razorpayOrderId: res.razorpayOrderId,
        razorpayPaymentId: res.razorpayPaymentId,
        razorpaySignature: res.razorpaySignature,
      });
      finishSuccess(orderId);
    } catch (err) {
      if (err instanceof PaymentCancelled) {
        setPendingOrderId(orderId);
        setStage('idle');
        Alert.alert(
          'Payment not completed',
          'Your order is saved with payment pending. You can retry now, or cancel the order.',
          [
            { text: 'Retry payment', onPress: () => startPayment(orderId, contact) },
            {
              text: 'Cancel order',
              style: 'destructive',
              onPress: async () => {
                try {
                  await groveApi.cancelOrder(orderId, 'Payment cancelled by customer');
                  clearCart();
                  toast('Order cancelled. No payment was taken.', 'info');
                  router.replace('/(tabs)/orders');
                } catch (e) {
                  toast(e instanceof Error ? e.message : 'Could not cancel the order.', 'error');
                }
              },
            },
            { text: 'Later', style: 'cancel' },
          ],
        );
        return;
      }
      setStage('idle');
      const msg = err instanceof Error ? err.message : 'Payment failed.';
      setServerError(msg);
      toast(msg, 'error');
    }
  };

  const finishSuccess = (orderId: string) => {
    clearCart();
    setPendingOrderId(null);
    setServerError(null);
    toast('Order confirmed!', 'success');
    router.replace({ pathname: '/order/[id]', params: { id: orderId, created: '1' } });
  };

  const onSubmit = async (values: CheckoutInput) => {
    setServerError(null);
    if (status !== 'signedIn') {
      toast('Please sign in to place your order.', 'info');
      router.push('/(auth)/login');
      return;
    }
    if (lines.length === 0) {
      toast('Your cart is empty.', 'error');
      router.replace('/cart');
      return;
    }

    try {
      // 1) revalidate prices + availability server-side (never trust stale carts)
      setStage('validating');
      const validation = await groveApi.validateCart(lines);
      const bad = validation.removed.filter((r) => r.reason !== 'price_changed');
      const priceChanges = validation.removed.filter((r) => r.reason === 'price_changed');
      if (bad.length > 0) {
        syncLines(validation.lines.filter((l) => !bad.some((b) => b.key === l.key)));
        toast(`${bad.map((b) => b.name).join(', ')} is no longer available.`, 'error');
        router.replace('/cart');
        return;
      }
      if (priceChanges.length) {
        syncLines(validation.lines);
        toast('Prices were updated to today’s menu — please review the total.', 'info');
        router.replace('/cart');
        return;
      }

      // 2) create order idempotently (same attemptId never creates two orders)
      setStage('placing');
      const liveTotals = computeTotals({
        lines: validation.lines,
        coupon,
        config: CONFIG,
        orderType: values.type,
      });
      const order = await groveApi.placeOrder({
        checkout: values,
        lines: validation.lines,
        totals: { ...liveTotals, itemsTotalMinor: liveTotals.itemsTotalMinor },
        idempotencyKey: attemptId,
        couponCode: couponCode ?? null,
      });

      if (values.paymentMethod === 'cod') {
        finishSuccess(order.id);
        return;
      }

      // 3) server-created Razorpay order → checkout → server-side signature verification
      await startPayment(order.id, values.contactPhone);
    } catch (err) {
      setStage('idle');
      const msg = err instanceof Error ? err.message : 'Could not place the order.';
      setServerError(msg);
      toast(msg, 'error');
    }
  };

  if (lines.length === 0 && stage === 'idle' && !pendingOrderId) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Checkout" onBack={() => router.back()} />
        <EmptyState
          title="Nothing to check out"
          subtitle="Your cart is empty."
          actionLabel="Browse Menu"
          onAction={() => router.replace('/(tabs)/menu')}
        />
      </View>
    );
  }

  const busy = stage !== 'idle';
  const busyLabel =
    stage === 'validating' ? 'Checking availability...' : stage === 'placing' ? 'Placing order...' : 'Opening payment...';

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Checkout" onBack={() => router.back()} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {pendingOrderId ? (
          <View style={styles.pendingBar} accessibilityRole="alert">
            <Text style={styles.pendingText}>
              Payment pending for this order. Retry to complete it, or it may auto-cancel.
            </Text>
          </View>
        ) : null}

        {serverError ? (
          <View style={styles.serverError} accessibilityRole="alert">
            <Text style={styles.serverErrorText}>{serverError}</Text>
          </View>
        ) : null}

        {/* fulfilment type */}
        <Text style={styles.sectionTitle}>Order Type</Text>
        <View style={styles.typeRow}>
          {([
            { key: 'delivery', label: 'Delivery', icon: Bike },
            { key: 'takeaway', label: 'Takeaway', icon: ShoppingBag },
          ] as const).map((opt) => (
            <Pressable
              key={opt.key}
              onPress={() => {
                setOrderType(opt.key);
                setValue('type', opt.key, { shouldValidate: true });
              }}
              style={[styles.typeCard, type === opt.key && styles.typeCardOn]}
              accessibilityRole="radio"
              accessibilityState={{ selected: type === opt.key }}
            >
              <opt.icon size={20} color={type === opt.key ? Colors.primary : Colors.textSecondary} />
              <Text style={[styles.typeCardText, type === opt.key && { color: Colors.primary }]}>{opt.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* address */}
        <View style={styles.sectionHead}>
          <Text style={styles.sectionTitle}>Delivery Address</Text>
          <Pressable onPress={() => router.push('/addresses')} accessibilityRole="link">
            <Text style={styles.change}>Change</Text>
          </Pressable>
        </View>

        {loadingAddresses ? (
          <ActivityIndicator color={Colors.primary} style={{ marginVertical: 18 }} />
        ) : !addresses || addresses.length === 0 ? (
          <Pressable onPress={() => router.push('/addresses')} style={styles.addAddress} accessibilityRole="button">
            <MapPin size={18} color={Colors.primary} />
            <Text style={styles.addAddressText}>Add a delivery address</Text>
          </Pressable>
        ) : (
          <Controller
            control={control}
            name="addressId"
            render={({ field: { onChange, value } }) => (
              <View>
                {addresses.map((addr) => {
                  const selected = value === addr.id;
                  return (
                    <Pressable
                      key={addr.id}
                      onPress={() => onChange(addr.id)}
                      style={[styles.address, selected && styles.addressOn]}
                      accessibilityRole="radio"
                      accessibilityState={{ selected }}
                    >
                      <View style={[styles.radio, selected && styles.radioOn]} />
                      <View style={{ flex: 1 }}>
                        <Text style={styles.addressLabel}>
                          {addr.label} {addr.isDefault ? '• Default' : ''}
                        </Text>
                        <Text style={styles.addressText} numberOfLines={2}>
                          {addr.line1}
                          {addr.line2 ? `, ${addr.line2}` : ''}, {addr.city} - {addr.pincode}
                        </Text>
                      </View>
                    </Pressable>
                  );
                })}
                {errors.addressId ? <Text style={styles.err}>{errors.addressId.message}</Text> : null}
              </View>
            )}
          />
        )}

        {/* instructions + contact */}
        <Text style={styles.sectionTitle}>Delivery Instructions</Text>
        <Controller
          control={control}
          name="deliveryInstructions"
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.instrWrap}>
              <MessageSquareText size={18} color={Colors.textMuted} />
              <TextInput
                value={value ?? ''}
                onChangeText={onChange}
                onBlur={onBlur}
                placeholder="e.g. call when you reach the gate"
                placeholderTextColor={Colors.textMuted}
                style={styles.instrInput}
                accessibilityLabel="Delivery instructions"
              />
            </View>
          )}
        />

        <Text style={styles.sectionTitle}>Contact Number</Text>
        <Controller
          control={control}
          name="contactPhone"
          render={({ field: { onChange, onBlur, value } }) => (
            <View>
              <View style={styles.instrWrap}>
                <Phone size={18} color={Colors.textMuted} />
                <TextInput
                  value={value}
                  onChangeText={(v) => onChange(v.replace(/[^0-9]/g, '').slice(0, 10))}
                  onBlur={onBlur}
                  keyboardType="phone-pad"
                  placeholder="10-digit mobile number"
                  placeholderTextColor={Colors.textMuted}
                  style={styles.instrInput}
                  accessibilityLabel="Contact phone number"
                />
              </View>
              {errors.contactPhone ? <Text style={styles.err}>{errors.contactPhone.message}</Text> : null}
            </View>
          )}
        />

        {/* payment */}
        <Text style={styles.sectionTitle}>Payment Method</Text>
        <Controller
          control={control}
          name="paymentMethod"
          render={({ field: { onChange, value } }) => (
            <View>
              <Pressable
                onPress={() => onChange('razorpay')}
                style={[styles.pay, value === 'razorpay' && styles.payOn]}
                accessibilityRole="radio"
                accessibilityState={{ selected: value === 'razorpay' }}
              >
                <View style={[styles.radio, value === 'razorpay' && styles.radioOn]} />
                <CreditCard size={20} color={value === 'razorpay' ? Colors.primary : Colors.textSecondary} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.payTitle}>UPI / Card / NetBanking</Text>
                  <Text style={styles.paySub}>Secured by Razorpay — verified on our server</Text>
                </View>
              </Pressable>

              {CONFIG.codEnabled ? (
                <Pressable
                  onPress={() => onChange('cod')}
                  style={[styles.pay, value === 'cod' && styles.payOn]}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: value === 'cod' }}
                >
                  <View style={[styles.radio, value === 'cod' && styles.radioOn]} />
                  <Banknote size={20} color={value === 'cod' ? Colors.primary : Colors.textSecondary} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.payTitle}>Cash on Delivery</Text>
                    <Text style={styles.paySub}>Pay when your order arrives</Text>
                  </View>
                </Pressable>
              ) : null}
            </View>
          )}
        />

        {/* bill */}
        <View style={styles.bill}>
          <Text style={styles.billTitle}>Bill Summary</Text>
          <Row label="Item Total" value={money(totals.subtotalMinor)} />
          <Row label="GST (5%)" value={money(totals.taxesMinor)} />
          <Row
            label="Delivery"
            value={type === 'delivery' ? (totals.deliveryFeeMinor === 0 ? 'FREE' : money(totals.deliveryFeeMinor)) : '—'}
            tone={totals.deliveryFeeMinor === 0 && type === 'delivery' ? 'success' : undefined}
          />
          <Row label="Platform Fee" value={money(totals.platformFeeMinor)} />
          {totals.discountMinor > 0 ? (
            <Row label={`Coupon (${totals.couponCode})`} value={`− ${money(totals.discountMinor)}`} tone="success" />
          ) : null}
          <View style={styles.billDivider} />
          <Row label="Total Payable" value={money(totals.grandTotalMinor)} bold />
        </View>

        <View style={{ height: 130 }} />
      </ScrollView>

      <View style={styles.footer}>
        <View>
          <Text style={styles.footerLabel}>Total Amount</Text>
          <Text style={styles.footerValue}>{money(totals.grandTotalMinor)}</Text>
        </View>
        <Pressable
          onPress={handleSubmit(onSubmit)}
          disabled={busy}
          accessibilityRole="button"
          accessibilityLabel={paymentMethod === 'cod' ? 'Place order' : 'Pay now'}
          style={({ pressed }) => [
            styles.payBtn,
            busy && { backgroundColor: Colors.disabled },
            pressed && { transform: [{ scale: 0.99 }] },
          ]}
        >
          {busy ? (
            <ActivityIndicator color={Colors.primary} />
          ) : (
            <Text style={styles.payBtnText}>{paymentMethod === 'cod' ? 'Place Order' : 'Pay Now'}</Text>
          )}
        </Pressable>
      </View>
      {busy ? <Text style={styles.busyLabel}>{busyLabel}</Text> : null}
    </View>
  );
}

function Row({ label, value, bold, tone }: { label: string; value: string; bold?: boolean; tone?: 'success' }) {
  return (
    <View style={styles.row}>
      <Text style={[styles.rowLabel, bold && styles.rowBold]}>{label}</Text>
      <Text style={[styles.rowValue, bold && styles.rowBold, tone === 'success' && { color: Colors.success }]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 16, paddingTop: 16 },
  sectionTitle: { ...Typography.h3, fontSize: 15, marginTop: 20, marginBottom: 10 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  change: { color: Colors.primary, fontWeight: '700', fontSize: 13, marginTop: 10 },
  err: { ...Typography.caption, color: Colors.danger, marginTop: 6 },
  serverError: {
    backgroundColor: Colors.dangerSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: '#F6C6CB',
  },
  serverErrorText: { color: Colors.danger, fontSize: 13, textAlign: 'center' },
  pendingBar: {
    backgroundColor: Colors.warningSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginBottom: 8,
  },
  pendingText: { color: Colors.warning, fontSize: 13, fontWeight: '600', textAlign: 'center' },
  typeRow: { flexDirection: 'row', gap: 12 },
  typeCard: {
    flex: 1,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 52,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
  },
  typeCardOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  typeCardText: { ...Typography.body, fontWeight: '600', color: Colors.textSecondary },
  addAddress: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: Colors.primary,
    borderRadius: Radius.lg,
    paddingVertical: 18,
    backgroundColor: Colors.primarySoft,
  },
  addAddressText: { color: Colors.primary, fontWeight: '700' },
  address: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    padding: 14,
    marginBottom: 10,
    backgroundColor: Colors.white,
  },
  addressOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: Colors.border,
    marginTop: 2,
    backgroundColor: Colors.white,
  },
  radioOn: { borderColor: Colors.primary, backgroundColor: Colors.primary },
  addressLabel: { ...Typography.bodyBold, fontSize: 14 },
  addressText: { ...Typography.caption, marginTop: 3, lineHeight: 17 },
  instrWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    paddingHorizontal: 14,
    minHeight: 50,
  },
  instrInput: { flex: 1, fontSize: 14, color: Colors.textPrimary, paddingVertical: 12 },
  pay: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    padding: 14,
    marginBottom: 10,
    backgroundColor: Colors.white,
  },
  payOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  payTitle: { ...Typography.bodyBold, fontSize: 14 },
  paySub: { ...Typography.caption, marginTop: 2 },
  bill: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    marginTop: 22,
  },
  billTitle: { ...Typography.h3, marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 9 },
  rowLabel: { ...Typography.secondary },
  rowValue: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  rowBold: { ...Typography.h3, fontSize: 16 },
  billDivider: { height: 1, backgroundColor: Colors.border, marginVertical: 6 },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 14,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 26,
  },
  footerLabel: { ...Typography.caption },
  footerValue: { ...Typography.h3, fontSize: 18, color: Colors.primary },
  payBtn: {
    backgroundColor: Colors.primary,
    borderRadius: Radius.pill,
    minHeight: 52,
    minWidth: 170,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.floating,
  },
  payBtnText: { ...Typography.button },
  busyLabel: { ...Typography.caption, textAlign: 'center', paddingBottom: 8, backgroundColor: Colors.white },
});
