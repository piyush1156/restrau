import { router } from 'expo-router';
import { TicketPercent, Info, ArrowRight } from 'lucide-react-native';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState } from '@/components/Bits';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { useQuery } from '@tanstack/react-query';
import { groveApi } from '@/services/client';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useToastStore } from '@/store/ui';
import { formatDate, money } from '@/utils/format';

export default function OffersScreen() {
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const setCoupon = useCartStore((s) => s.setCoupon);
  const signedIn = useAuthStore((s) => s.status === 'signedIn');

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['public-coupons'],
    queryFn: () => groveApi.getPublicCoupons(),
    staleTime: 60_000,
  });

  const usable = (data ?? []).filter((c) => c.isActive && new Date(c.expiresAt) > new Date());

  const apply = (code: string) => {
    setCoupon(code);
    toast(`${code} applied — review it in your cart`, 'success');
    router.push('/cart');
  };

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Offers & Coupons" onBack={() => router.back()} />
      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.primary} />
        </View>
      ) : isError ? (
        <EmptyState tone="error" title="Couldn’t load offers" actionLabel="Retry" onAction={() => refetch()} />
      ) : usable.length === 0 ? (
        <EmptyState title="No offers right now" subtitle="Check back soon — we run new offers every week." />
      ) : (
        <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]} showsVerticalScrollIndicator={false}>
          <View style={styles.hero}>
            <TicketPercent size={26} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.heroTitle}>Save on your next order</Text>
              <Text style={styles.heroSub}>Tap a coupon to copy the code and apply it to your cart.</Text>
            </View>
          </View>

          {usable.map((c) => (
            <View key={c.code} style={styles.card}>
              <View style={styles.cardTop}>
                <View style={styles.iconBox}>
                  <TicketPercent size={20} color={Colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.code}>{c.code}</Text>
                  <Text style={styles.desc}>{c.description}</Text>
                </View>
              </View>

              <View style={styles.rules}>
                <Text style={styles.rule}>
                  • {c.discountPercent ? `${c.discountPercent}% off` : `${money(c.discountFlatMinor ?? 0)} off`}
                  {c.maxDiscountMinor ? ` (max ${money(c.maxDiscountMinor)})` : ''}
                </Text>
                <Text style={styles.rule}>
                  • Minimum order {c.minOrderMinor ? money(c.minOrderMinor) : 'none'}
                </Text>
                <Text style={styles.rule}>• Valid till {formatDate(c.expiresAt)}</Text>
              </View>

              <Pressable
                onPress={() => apply(c.code)}
                style={styles.applyBtn}
                accessibilityRole="button"
                accessibilityLabel={`Apply coupon ${c.code} to my cart`}
              >
                <Text style={styles.applyText}>Apply to Cart</Text>
                <ArrowRight size={15} color={Colors.white} />
              </Pressable>
            </View>
          ))}

          <View style={styles.note}>
            <Info size={16} color={Colors.textSecondary} />
            <Text style={styles.noteText}>
              One coupon per order. Coupons cannot be combined with other offers. Discounts apply to the item
              subtotal before taxes.
            </Text>
          </View>

          {!signedIn ? (
            <Text style={styles.signInNote}>Sign in at checkout to use a coupon on your order.</Text>
          ) : null}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scroll: { padding: 16, gap: 12 },
  hero: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.lg,
    padding: 14,
  },
  heroTitle: { ...Typography.bodyBold, fontSize: 15 },
  heroSub: { ...Typography.caption, marginTop: 2, lineHeight: 17 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    ...Shadow.soft,
  },
  cardTop: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  iconBox: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  code: { ...Typography.h3, fontSize: 16, letterSpacing: 1 },
  desc: { ...Typography.secondary, marginTop: 3, lineHeight: 18 },
  rules: {
    marginTop: 12,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    padding: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: 4,
  },
  rule: { ...Typography.caption, color: Colors.textPrimary },
  applyBtn: {
    marginTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    backgroundColor: Colors.primary,
    borderRadius: Radius.pill,
    minHeight: 44,
  },
  applyText: { color: Colors.white, fontWeight: '700', fontSize: 14 },
  note: {
    flexDirection: 'row',
    gap: 8,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    padding: 12,
    marginTop: 4,
  },
  noteText: { ...Typography.caption, flex: 1, lineHeight: 18 },
  signInNote: { ...Typography.caption, textAlign: 'center', color: Colors.textMuted },
});
