import { router, useLocalSearchParams } from 'expo-router';
import {
  Bike,
  CheckCircle2,
  Clock3,
  MapPin,
  MessageCircle,
  Phone,
  ReceiptText,
  ShoppingBag,
  Star,
  Store,
  User2,
} from 'lucide-react-native';
import { Alert, Linking, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { EmptyState, Price, Skeleton, StatusBadge } from '@/components/Bits';
import { OrderTimeline } from '@/components/OrderTimeline';
import { SafeImage } from '@/components/SafeImage';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { canCustomerCancel, ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS } from '@grove/shared';
import { useCancelOrder, useOrderPolling } from '@/hooks/useQueries';
import { useToastStore } from '@/store/ui';
import { formatDateTime } from '@/utils/format';
import { money } from '@/utils/format';

const DELIVERY_PARTNER_FALLBACK = null;

export default function OrderTrackingScreen() {
  const { id, created } = useLocalSearchParams<{ id: string; created?: string }>();
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const { data: order, isLoading, isError, refetch, isRefetching } = useOrderPolling(id);
  const cancel = useCancelOrder();

  const onCancel = () => {
    if (!order) return;
    Alert.alert('Cancel this order?', 'If you already paid, the refund is processed to the original payment method.', [
      { text: 'Keep order', style: 'cancel' },
      {
        text: 'Cancel order',
        style: 'destructive',
        onPress: async () => {
          try {
            await cancel.mutateAsync({ id: order.id, reason: 'Cancelled by customer' });
            toast('Order cancelled', 'success');
            refetch();
          } catch (e) {
            toast(e instanceof Error ? e.message : 'Could not cancel this order.', 'error');
          }
        },
      },
    ]);
  };

  if (isLoading) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Track Order" onBack={() => router.back()} />
        <View style={{ padding: 16, gap: 12 }}>
          <Skeleton height={90} />
          <Skeleton height={120} />
          <Skeleton height={160} />
        </View>
      </View>
    );
  }

  if (isError || !order) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Track Order" onBack={() => router.back()} />
        <EmptyState
          tone="error"
          title="Order not found"
          subtitle="We couldn’t load this order. It may belong to a different account."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      </View>
    );
  }

  const partner = order.deliveryPartner ?? DELIVERY_PARTNER_FALLBACK;
  const isActive = !['delivered', 'cancelled'].includes(order.status);
  const showMapFallback = order.type === 'delivery' && isActive && !partner?.phone;

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Track Order" onBack={() => router.back()} bordered />
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 28 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
      >
        {created === '1' ? (
          <View style={styles.success}>
            <CheckCircle2 size={22} color={Colors.success} />
            <View style={{ flex: 1 }}>
              <Text style={styles.successTitle}>Order confirmed</Text>
              <Text style={styles.successSub}>We’ve sent it to the kitchen. Track every step here.</Text>
            </View>
          </View>
        ) : null}

        {/* order meta */}
        <View style={styles.metaRow}>
          <View>
            <Text style={styles.orderNo}>#{order.orderNumber}</Text>
            <Text style={styles.orderDate}>{formatDateTime(order.createdAt)}</Text>
          </View>
          <StatusBadge status={order.status} />
        </View>

        <OrderTimeline order={order} />

        {/* live status summary */}
        <View style={styles.statusCard}>
          <View style={styles.statusIcon}>
            {order.type === 'delivery' ? (
              <Bike size={22} color={Colors.primary} />
            ) : (
              <Store size={22} color={Colors.primary} />
            )}
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.statusTitle}>
              {order.status === 'cancelled'
                ? 'Order cancelled'
                : order.status === 'delivered'
                  ? 'Delivered — enjoy your meal!'
                  : `${ORDER_STATUS_LABELS[order.status]}${order.type === 'delivery' ? ' — on its way' : ''}`}
            </Text>
            <Text style={styles.statusSub}>
              {order.status === 'delivered'
                ? `Completed ${formatDateTime(order.updatedAt)}`
                : order.estimatedAt
                  ? `Estimated arrival: ${formatDateTime(order.estimatedAt)}`
                  : 'A live ETA appears here once the kitchen confirms your order.'}
            </Text>
          </View>
        </View>

        {/* delivery partner */}
        {order.type === 'delivery' && partner ? (
          <View style={styles.partner}>
            <View style={styles.partnerAvatar}>
              <User2 size={20} color={Colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.partnerName}>{partner.name}</Text>
              <Text style={styles.partnerSub}>
                {partner.vehicle ? `${partner.vehicle} • Delivery partner` : 'Delivery partner'}
              </Text>
            </View>
            <Pressable
              onPress={() => Linking.openURL(`tel:${partner.phone}`)}
              style={styles.callBtn}
              accessibilityRole="button"
              accessibilityLabel={`Call ${partner.name}`}
            >
              <Phone size={18} color={Colors.white} />
            </Pressable>
          </View>
        ) : null}

        {/* honest tracking fallback */}
        {showMapFallback ? (
          <View style={styles.mapPlaceholder}>
            <View style={styles.mapGrid}>
              <MapPin size={26} color={Colors.primary} />
            </View>
            <Text style={styles.mapTitle}>Live map tracking not available</Text>
            <Text style={styles.mapSub}>
              We don’t share a driver location until a partner is assigned. Pull down to refresh for the latest status.
            </Text>
          </View>
        ) : null}

        {/* address */}
        {order.address ? (
          <View style={styles.card}>
            <View style={styles.cardHead}>
              <MapPin size={18} color={Colors.primary} />
              <Text style={styles.cardTitle}>Delivery Address</Text>
            </View>
            <Text style={styles.address}>
              {order.address.line1}
              {order.address.line2 ? `, ${order.address.line2}` : ''}
              {'\n'}
              {order.address.city} — {order.address.pincode}
            </Text>
            {order.deliveryInstructions ? (
              <Text style={styles.instruction}>“{order.deliveryInstructions}”</Text>
            ) : null}
          </View>
        ) : null}

        {/* items */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <ShoppingBag size={18} color={Colors.primary} />
            <Text style={styles.cardTitle}>Order Items</Text>
          </View>
          {order.items.map((item) => (
            <View key={item.id} style={styles.itemRow}>
              <SafeImage uri={item.imageUrl} label={item.name} style={styles.itemImg} rounded={Radius.md} />
              <View style={{ flex: 1 }}>
                <Text style={styles.itemName} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.itemMeta}>x{item.quantity}</Text>
                {item.addOns.length ? (
                  <Text style={styles.itemAddons} numberOfLines={1}>
                    {item.addOns.map((a) => a.name).join(', ')}
                  </Text>
                ) : null}
              </View>
              <Text style={styles.itemPrice}>{money(item.unitPriceMinor * item.quantity)}</Text>
            </View>
          ))}
        </View>

        {/* bill */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <ReceiptText size={18} color={Colors.primary} />
            <Text style={styles.cardTitle}>Bill Details</Text>
          </View>
          <Row label="Item Total" value={money(order.totals.subtotalMinor)} />
          {order.totals.discountMinor > 0 ? (
            <Row label={`Discount ${order.couponCode ? `(${order.couponCode})` : ''}`} value={`− ${money(order.totals.discountMinor)}`} success />
          ) : null}
          <Row label="GST (5%)" value={money(order.totals.taxesMinor)} />
          <Row label="Delivery Fee" value={order.totals.deliveryFeeMinor ? money(order.totals.deliveryFeeMinor) : 'FREE'} />
          <Row label="Platform Fee" value={money(order.totals.platformFeeMinor)} />
          <View style={styles.hr} />
          <View style={styles.row}>
            <Text style={styles.totalLabel}>Total Paid</Text>
            <Price value={money(order.totals.grandTotalMinor)} size="lg" />
          </View>
          <View style={styles.payLine}>
            <Text style={styles.payText}>
              {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Paid online (Razorpay)'}
            </Text>
            <View style={[styles.payBadge, order.paymentStatus === 'paid' ? styles.payBadgePaid : null]}>
              <Text
                style={[
                  styles.payBadgeText,
                  order.paymentStatus === 'paid' ? { color: Colors.success } : { color: Colors.warning },
                ]}
              >
                {PAYMENT_STATUS_LABELS[order.paymentStatus]}
              </Text>
            </View>
          </View>
        </View>

        {/* actions */}
        <View style={styles.actions}>
          <Pressable onPress={() => router.push('/chatbot')} style={styles.secondaryBtn} accessibilityRole="button">
            <MessageCircle size={18} color={Colors.primary} />
            <Text style={styles.secondaryText}>Need help?</Text>
          </Pressable>
          {order.status === 'delivered' ? (
            <Pressable
              onPress={() => router.push({ pathname: '/item/[id]', params: { id: order.items[0]?.menuItemId ?? '' } })}
              style={styles.primaryBtn}
              accessibilityRole="button"
            >
              <Star size={18} color={Colors.white} />
              <Text style={styles.primaryText}>Rate your meal</Text>
            </Pressable>
          ) : canCustomerCancel(order.status) ? (
            <Pressable
              onPress={onCancel}
              disabled={cancel.isPending}
              style={styles.dangerBtn}
              accessibilityRole="button"
            >
              <Text style={styles.dangerText}>{cancel.isPending ? 'Cancelling…' : 'Cancel Order'}</Text>
            </Pressable>
          ) : (
            <Pressable onPress={() => router.push('/(tabs)/orders')} style={styles.primaryBtn} accessibilityRole="button">
              <Clock3 size={18} color={Colors.white} />
              <Text style={styles.primaryText}>All Orders</Text>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const Row = ({ label, value, success }: { label: string; value: string; success?: boolean }) => (
  <View style={styles.row}>
    <Text style={styles.rowLabel}>{label}</Text>
    <Text style={[styles.rowValue, success && { color: Colors.success }]}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 16, gap: 14 },
  success: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.successSoft,
    borderRadius: Radius.lg,
    padding: 14,
  },
  successTitle: { ...Typography.bodyBold, color: Colors.success },
  successSub: { ...Typography.caption, marginTop: 2 },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  orderNo: { ...Typography.h2, fontSize: 19 },
  orderDate: { ...Typography.caption, marginTop: 3 },
  statusCard: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.lg,
    padding: 14,
  },
  statusIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusTitle: { ...Typography.bodyBold, fontSize: 15 },
  statusSub: { ...Typography.caption, marginTop: 3, lineHeight: 17 },
  partner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
  },
  partnerAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  partnerName: { ...Typography.bodyBold, fontSize: 15 },
  partnerSub: { ...Typography.caption, marginTop: 2 },
  callBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.floating,
  },
  mapPlaceholder: {
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
    backgroundColor: Colors.backgroundAlt,
  },
  mapGrid: {
    height: 92,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F2F5F9',
  },
  mapTitle: { ...Typography.bodyBold, paddingHorizontal: 14, paddingTop: 12, fontSize: 14 },
  mapSub: { ...Typography.caption, paddingHorizontal: 14, paddingBottom: 14, marginTop: 4, lineHeight: 17 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
  },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  cardTitle: { ...Typography.h3, fontSize: 15 },
  address: { ...Typography.secondary, lineHeight: 20 },
  instruction: { ...Typography.caption, marginTop: 8, fontStyle: 'italic' },
  itemRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  itemImg: { width: 48, height: 48 },
  itemName: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  itemMeta: { ...Typography.caption, marginTop: 2 },
  itemAddons: { ...Typography.caption, color: Colors.textMuted, marginTop: 1, fontSize: 11 },
  itemPrice: { ...Typography.bodyBold, fontSize: 14 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, alignItems: 'center' },
  rowLabel: { ...Typography.secondary },
  rowValue: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  hr: { height: 1, backgroundColor: Colors.border, marginVertical: 6 },
  totalLabel: { ...Typography.h3, fontSize: 15 },
  payLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 },
  payText: { ...Typography.caption },
  payBadge: { backgroundColor: Colors.warningSoft, paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.pill },
  payBadgePaid: { backgroundColor: Colors.successSoft },
  payBadgeText: { fontSize: 12, fontWeight: '700' },
  actions: { flexDirection: 'row', gap: 12, marginTop: 4 },
  secondaryBtn: {
    flex: 1,
    minHeight: 50,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.primary,
    backgroundColor: Colors.primarySoft,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  secondaryText: { color: Colors.primary, fontWeight: '700' },
  primaryBtn: {
    flex: 1,
    minHeight: 50,
    borderRadius: Radius.pill,
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    ...Shadow.floating,
  },
  primaryText: { color: Colors.white, fontWeight: '700' },
  dangerBtn: {
    flex: 1,
    minHeight: 50,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  dangerText: { color: Colors.danger, fontWeight: '700' },
});
