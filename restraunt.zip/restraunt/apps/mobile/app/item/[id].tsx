import { router, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, Clock3, Heart, Info } from 'lucide-react-native';
import { useMemo, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppButton } from '@/components/AppButton';
import { EmptyState, Price, RatingPill, Skeleton, VegBadge } from '@/components/Bits';
import { QuantityStepper } from '@/components/QuantityStepper';
import { SafeImage } from '@/components/SafeImage';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { useMenuItem } from '@/hooks/useQueries';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useFavouritesStore, useToastStore } from '@/store/ui';
import { money } from '@/utils/format';
import type { AddOn } from '@grove/shared';

export default function ItemDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const status = useAuthStore((s) => s.status);

  const { data: item, isLoading, isError, refetch } = useMenuItem(id ?? '');
  const addItem = useCartStore((s) => s.addItem);
  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);

  const favIds = useFavouritesStore((s) => s.ids);
  const toggleFav = useFavouritesStore((s) => s.toggle);

  const [qty, setQty] = useState(1);
  const [selectedAddOns, setSelectedAddOns] = useState<AddOn[]>([]);
  const [instructions, setInstructions] = useState('');

  const inCart = Boolean(item && lines.some((l) => l.menuItemId === item.id));
  const isFav = Boolean(item && favIds.includes(item.id));

  const basePrice = item ? (item.discountedPriceMinor ?? item.priceMinor) : 0;
  const total = useMemo(
    () => (basePrice + selectedAddOns.reduce((s, a) => s + a.priceMinor, 0)) * qty,
    [basePrice, selectedAddOns, qty],
  );

  const toggleAddOn = (addon: AddOn) => {
    setSelectedAddOns((prev) =>
      prev.some((a) => a.id === addon.id) ? prev.filter((a) => a.id !== addon.id) : [...prev, addon],
    );
  };

  const onFavourite = async () => {
    if (status !== 'signedIn') {
      toast('Sign in to save favourites.', 'info');
      router.push('/(auth)/login');
      return;
    }
    try {
      await toggleFav(id);
      toast(isFav ? 'Removed from favourites' : 'Saved to favourites', 'success');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Could not update favourites.', 'error');
    }
  };

  const onAdd = () => {
    if (!item) return;
    if (!item.isAvailable) {
      toast('This dish is currently sold out.', 'error');
      return;
    }
    addItem({
      menuItemId: item.id,
      name: item.name,
      imageUrl: item.imageUrl,
      basePriceMinor: item.discountedPriceMinor ?? item.priceMinor,
      addOns: selectedAddOns,
      quantity: qty,
      specialInstructions: instructions,
    });
    toast(`${item.name} added to cart`, 'success');
    router.back();
  };

  if (isLoading) {
    return (
      <View style={styles.flex}>
        <Skeleton height={300} width="100%" />
        <View style={{ padding: 16, gap: 12 }}>
          <Skeleton height={24} width="60%" />
          <Skeleton height={16} width="90%" />
          <Skeleton height={16} width="70%" />
          <Skeleton height={52} width="100%" style={{ marginTop: 20 }} />
        </View>
      </View>
    );
  }

  if (isError || !item) {
    return (
      <View style={styles.flex}>
        <EmptyState
          tone="error"
          title="Couldn’t load this dish"
          subtitle="It may have been removed, or you’re offline."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
        <Pressable onPress={() => router.back()} style={styles.inlineBack}>
          <Text style={styles.inlineBackText}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ paddingBottom: 140 }} showsVerticalScrollIndicator={false}>
        <View style={styles.imageWrap}>
          <SafeImage uri={item.imageUrl} label={item.name} style={styles.image} rounded={0} />
          <View style={[styles.floatRow, { top: insets.top + 10 }]}>
            <Pressable
              onPress={() => router.back()}
              style={styles.floatBtn}
              accessibilityRole="button"
              accessibilityLabel="Go back"
            >
              <ChevronLeft size={22} color={Colors.textPrimary} />
            </Pressable>
            <Pressable
              onPress={onFavourite}
              style={styles.floatBtn}
              accessibilityRole="button"
              accessibilityLabel={isFav ? 'Remove from favourites' : 'Add to favourites'}
            >
              <Heart
                size={20}
                color={isFav ? Colors.primary : Colors.textPrimary}
                fill={isFav ? Colors.primary : 'transparent'}
              />
            </Pressable>
          </View>
        </View>

        <View style={styles.body}>
          <View style={styles.titleRow}>
            <VegBadge isVeg={item.isVeg} />
            <Text style={styles.name}>{item.name}</Text>
          </View>

          <View style={styles.metaRow}>
            <RatingPill rating={item.rating} size="md" />
            <Text style={styles.reviews}>
              {item.reviewCount >= 1000 ? `${(item.reviewCount / 1000).toFixed(1)}k` : item.reviewCount} reviews
            </Text>
            {item.prepTimeMins ? (
              <View style={styles.timePill}>
                <Clock3 size={13} color={Colors.textSecondary} />
                <Text style={styles.timeText}>{item.prepTimeMins} min</Text>
              </View>
            ) : null}
          </View>

          <View style={styles.priceRow}>
            <Price value={money(basePrice)} size="lg" />
            {item.discountedPriceMinor ? <Price value={money(item.priceMinor)} strike /> : null}
            {!item.isAvailable ? (
              <View style={styles.soldOut}>
                <Text style={styles.soldOutText}>Sold out</Text>
              </View>
            ) : null}
          </View>

          <Text style={styles.desc}>{item.description}</Text>

          {item.ingredients.length ? (
            <View style={styles.infoCard}>
              <Text style={styles.infoTitle}>Ingredients</Text>
              <Text style={styles.infoText}>{item.ingredients.join(' • ')}</Text>
              {item.allergens.length ? (
                <View style={styles.allergenRow}>
                  <Info size={14} color={Colors.warning} />
                  <Text style={styles.allergenText}>Allergens: {item.allergens.join(', ')}</Text>
                </View>
              ) : (
                <View style={styles.allergenRow}>
                  <Info size={14} color={Colors.success} />
                  <Text style={[styles.allergenText, { color: Colors.success }]}>
                    No allergens listed for this dish
                  </Text>
                </View>
              )}
            </View>
          ) : null}

          <Text style={styles.sectionTitle}>Choose Quantity</Text>
          <View style={styles.qtyRow}>
            <QuantityStepper value={qty} onChange={setQty} label={`${item.name} quantity`} />
            <Text style={styles.lineTotal}>{money(total)}</Text>
          </View>

          {item.addOns.length ? (
            <>
              <Text style={styles.sectionTitle}>Add-ons</Text>
              {item.addOns.map((addon) => {
                const selected = selectedAddOns.some((a) => a.id === addon.id);
                return (
                  <Pressable
                    key={addon.id}
                    onPress={() => toggleAddOn(addon)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: selected }}
                    style={[styles.addon, selected && styles.addonOn]}
                  >
                    <View style={[styles.checkbox, selected && styles.checkboxOn]}>
                      {selected ? <Text style={styles.checkmark}>✓</Text> : null}
                    </View>
                    <Text style={styles.addonName}>{addon.name}</Text>
                    <Text style={styles.addonPrice}>+ {money(addon.priceMinor)}</Text>
                  </Pressable>
                );
              })}
            </>
          ) : null}

          <Text style={styles.sectionTitle}>Special Instructions</Text>
          <TextInput
            value={instructions}
            onChangeText={(v) => setInstructions(v.slice(0, 200))}
            placeholder="e.g. less spicy, no onion..."
            placeholderTextColor={Colors.textMuted}
            style={styles.instructions}
            multiline
            accessibilityLabel="Special instructions"
          />
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 14) }]}>
        <View style={styles.footerQty}>
          <QuantityStepper value={qty} onChange={setQty} compact label={`${item.name} quantity`} />
        </View>
        <AppButton
          label={item.isAvailable ? `Add to Cart • ${money(total)}` : 'Currently Unavailable'}
          onPress={onAdd}
          disabled={!item.isAvailable}
          style={{ flex: 1 }}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  imageWrap: { height: 320, backgroundColor: Colors.primarySoft },
  image: { width: '100%', height: '100%' },
  floatRow: {
    position: 'absolute',
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  floatBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadow.card,
  },
  body: {
    marginTop: -26,
    backgroundColor: Colors.white,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    paddingHorizontal: 20,
    paddingTop: 22,
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  name: { ...Typography.h1, flexShrink: 1 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 10 },
  reviews: { ...Typography.secondary, fontSize: 13 },
  timePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.backgroundAlt,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: Radius.sm,
  },
  timeText: { ...Typography.caption },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 14 },
  soldOut: { backgroundColor: Colors.dangerSoft, paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radius.sm },
  soldOutText: { color: Colors.danger, fontSize: 12, fontWeight: '700' },
  desc: { ...Typography.body, color: Colors.textSecondary, lineHeight: 22, marginTop: 12 },
  infoCard: {
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 14,
    marginTop: 16,
  },
  infoTitle: { ...Typography.bodyBold, fontSize: 14 },
  infoText: { ...Typography.secondary, marginTop: 6, lineHeight: 20 },
  allergenRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  allergenText: { ...Typography.caption, color: Colors.warning, flexShrink: 1 },
  sectionTitle: { ...Typography.h3, marginTop: 24, marginBottom: 12 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  lineTotal: { ...Typography.price, fontSize: 18 },
  addon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    padding: 14,
    marginBottom: 10,
    backgroundColor: Colors.white,
  },
  addonOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.6,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  checkboxOn: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  checkmark: { color: Colors.white, fontSize: 13, fontWeight: '900' },
  addonName: { ...Typography.body, flex: 1 },
  addonPrice: { ...Typography.bodyBold, color: Colors.primary, fontSize: 14 },
  instructions: {
    minHeight: 84,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    padding: 14,
    fontSize: 15,
    color: Colors.textPrimary,
    textAlignVertical: 'top',
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: 16,
    paddingTop: 12,
    ...Shadow.card,
  },
  footerQty: {},
  inlineBack: { alignItems: 'center', padding: 16 },
  inlineBackText: { color: Colors.primary, fontWeight: '700' },
});
