import { router } from 'expo-router';
import { Heart, Plus } from 'lucide-react-native';
import { useEffect } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { EmptyState, Price, RatingPill, VegBadge } from '@/components/Bits';
import { SafeImage } from '@/components/SafeImage';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { useFavourites } from '@/hooks/useQueries';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useFavouritesStore, useToastStore } from '@/store/ui';
import { money } from '@/utils/format';

export default function FavouritesScreen() {
  const insets = useSafeAreaInsets();
  const signedIn = useAuthStore((s) => s.status === 'signedIn');
  const toast = useToastStore((s) => s.show);
  const addItem = useCartStore((s) => s.addItem);
  const hydrate = useFavouritesStore((s) => s.hydrateFromServer);
  const toggle = useFavouritesStore((s) => s.toggle);
  const { data, isLoading, isError, refetch } = useFavourites(signedIn);

  useEffect(() => {
    if (data) hydrate(data.map((m) => m.id));
  }, [data, hydrate]);

  const add = (item: NonNullable<typeof data>[number]) => {
    if (!item.isAvailable) {
      toast(`${item.name} is sold out right now.`, 'info');
      return;
    }
    addItem({
      menuItemId: item.id,
      name: item.name,
      imageUrl: item.imageUrl,
      basePriceMinor: item.discountedPriceMinor ?? item.priceMinor,
      addOns: [],
      quantity: 1,
    });
    toast(`${item.name} added to cart`, 'success');
  };

  if (!signedIn) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Favourites" onBack={() => router.back()} />
        <EmptyState
          title="Sign in to save favourites"
          subtitle="Tap the heart on any dish and it will be waiting here."
          actionLabel="Sign In"
          onAction={() => router.push('/(auth)/login')}
        />
      </View>
    );
  }

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Favourites" onBack={() => router.back()} />
      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.primary} />
        </View>
      ) : isError ? (
        <EmptyState
          tone="error"
          title="Couldn’t load favourites"
          subtitle="Please check your connection."
          actionLabel="Retry"
          onAction={() => refetch()}
        />
      ) : (data?.length ?? 0) === 0 ? (
        <EmptyState
          title="No favourites yet"
          subtitle="Save dishes you love and order them in one tap."
          actionLabel="Browse Menu"
          onAction={() => router.push('/(tabs)/menu')}
        />
      ) : (
        <FlatList
          data={data}
          keyExtractor={(m) => m.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 24 }]}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <Animated.View entering={FadeInUp.delay(index * 35).duration(240)}>
              <Pressable
                onPress={() => router.push({ pathname: '/item/[id]', params: { id: item.id } })}
                style={styles.card}
                accessibilityRole="button"
                accessibilityLabel={`${item.name}, ${money(item.discountedPriceMinor ?? item.priceMinor)}`}
              >
                <SafeImage uri={item.imageUrl} label={item.name} style={styles.image} rounded={Radius.lg} />
                <View style={styles.body}>
                  <View style={styles.titleRow}>
                    <VegBadge isVeg={item.isVeg} />
                    <Text style={styles.name} numberOfLines={1}>
                      {item.name}
                    </Text>
                  </View>
                  <RatingPill rating={item.rating} />
                  <View style={styles.footer}>
                    <Price value={money(item.discountedPriceMinor ?? item.priceMinor)} size="sm" />
                    <Pressable
                      onPress={() => add(item)}
                      disabled={!item.isAvailable}
                      style={[styles.add, !item.isAvailable && { backgroundColor: Colors.disabled, borderColor: Colors.border }]}
                      accessibilityRole="button"
                      accessibilityLabel={`Add ${item.name} to cart`}
                    >
                      <Plus size={16} color={item.isAvailable ? Colors.white : Colors.textMuted} />
                    </Pressable>
                  </View>
                </View>
                <Pressable
                  onPress={async () => {
                    try {
                      await toggle(item.id);
                      refetch();
                    } catch {
                      toast('Could not update favourites.', 'error');
                    }
                  }}
                  hitSlop={10}
                  style={styles.heart}
                  accessibilityRole="button"
                  accessibilityLabel={`Remove ${item.name} from favourites`}
                >
                  <Heart size={18} color={Colors.primary} fill={Colors.primary} />
                </Pressable>
              </Pressable>
            </Animated.View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  list: { padding: 16 },
  card: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
    marginBottom: 12,
    ...Shadow.soft,
  },
  image: { width: 86, height: 86 },
  body: { flex: 1, justifyContent: 'space-between', paddingVertical: 2 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingRight: 26 },
  name: { ...Typography.bodyBold, flexShrink: 1 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  add: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heart: { position: 'absolute', top: 12, right: 12 },
});
