import { router } from 'expo-router';
import { ChevronDown, CircleHelp, Clock3, Mail, MapPin, MessageCircle, Phone } from 'lucide-react-native';
import { useState } from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn } from 'react-native-reanimated';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { DEFAULT_OPENING_HOURS } from '@grove/shared';
import { RESTAURANT_ADDRESS_LINE, RESTAURANT_PHONE } from '@/data/seed';

const FAQS = [
  {
    q: 'How do I track my order?',
    a: 'Open Orders → tap any active order. The status updates from the kitchen in real time. We only show an ETA once the restaurant confirms it.',
  },
  {
    q: 'What is the cancellation policy?',
    a: 'Orders can be cancelled free of charge until the kitchen starts cooking (pending or confirmed). After that, please call us and we will do our best.',
  },
  {
    q: 'How are refunds processed?',
    a: 'Paid orders that are cancelled are refunded to the original payment method through Razorpay. Refunds usually settle in 5–7 business days; the order timeline shows the refund status.',
  },
  {
    q: 'Can I change my delivery address after ordering?',
    a: 'Once an order is confirmed the address is locked for food-safety reasons. Cancel and re-order, or call us within 2 minutes if the rider has not left.',
  },
  {
    q: 'Do you accommodate allergies?',
    a: 'Every dish lists its allergens on the item page. Our kitchen handles dairy, nuts, gluten and eggs, so we cannot guarantee zero cross-contact. For severe allergies, please call before ordering.',
  },
  {
    q: 'How do table bookings work?',
    a: 'Pick a date, party size and slot, then confirm. Tables are held 15 minutes past your booking time. You can cancel free of charge up to 2 hours before.',
  },
];

export default function HelpScreen() {
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState<number | null>(0);

  const call = () => Linking.openURL(`tel:${RESTAURANT_PHONE.replace(/\s/g, '')}`);
  const mail = () => Linking.openURL('mailto:support@thegrove.in?subject=Support%20request');

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Help & Support" onBack={() => router.back()} />
      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <CircleHelp size={26} color={Colors.primary} />
          <View style={{ flex: 1 }}>
            <Text style={styles.heroTitle}>We’re here to help</Text>
            <Text style={styles.heroSub}>Average reply under 5 minutes during opening hours.</Text>
          </View>
        </View>

        <View style={styles.actions}>
          <Pressable onPress={call} style={styles.action} accessibilityRole="button" accessibilityLabel="Call the restaurant">
            <View style={styles.actionIcon}>
              <Phone size={20} color={Colors.primary} />
            </View>
            <Text style={styles.actionLabel}>Call us</Text>
          </Pressable>
          <Pressable onPress={() => router.push('/chatbot')} style={styles.action} accessibilityRole="button" accessibilityLabel="Chat with the assistant">
            <View style={styles.actionIcon}>
              <MessageCircle size={20} color={Colors.primary} />
            </View>
            <Text style={styles.actionLabel}>Live chat</Text>
          </Pressable>
          <Pressable onPress={mail} style={styles.action} accessibilityRole="button" accessibilityLabel="Email support">
            <View style={styles.actionIcon}>
              <Mail size={20} color={Colors.primary} />
            </View>
            <Text style={styles.actionLabel}>Email</Text>
          </Pressable>
        </View>

        <Text style={styles.section}>Frequently asked</Text>
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <Pressable
              key={f.q}
              onPress={() => setOpen(isOpen ? null : i)}
              style={[styles.faq, isOpen && styles.faqOpen]}
              accessibilityRole="button"
              accessibilityState={{ expanded: isOpen }}
              accessibilityLabel={f.q}
            >
              <View style={styles.faqHead}>
                <Text style={styles.faqQ}>{f.q}</Text>
                <ChevronDown
                  size={18}
                  color={Colors.textSecondary}
                  style={{ transform: [{ rotate: isOpen ? '180deg' : '0deg' }] }}
                />
              </View>
              {isOpen ? (
                <Animated.View entering={FadeIn.duration(180)}>
                  <Text style={styles.faqA}>{f.a}</Text>
                </Animated.View>
              ) : null}
            </Pressable>
          );
        })}

        <Text style={styles.section}>Visit us</Text>
        <View style={styles.card}>
          <View style={styles.infoRow}>
            <MapPin size={17} color={Colors.primary} />
            <Text style={styles.infoText}>{RESTAURANT_ADDRESS_LINE}</Text>
          </View>
          <View style={styles.infoRow}>
            <Phone size={17} color={Colors.primary} />
            <Text style={styles.infoText}>{RESTAURANT_PHONE}</Text>
          </View>
          <View style={styles.infoRow}>
            <Mail size={17} color={Colors.primary} />
            <Text style={styles.infoText}>support@thegrove.in</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Clock3 size={17} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.hoursTitle}>Opening hours</Text>
              {DEFAULT_OPENING_HOURS.map((h) => (
                <Text key={h.day} style={styles.hoursText}>
                  {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][h.day]} ·{' '}
                  {h.opensAt} – {h.closesAt}
                </Text>
              ))}
            </View>
          </View>
        </View>

        <Text style={styles.footnote}>
          For order-specific disputes, please share your order number. We never ask for card numbers, CVV or OTPs over
          chat or phone.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 16 },
  hero: { flexDirection: 'row', gap: 12, alignItems: 'center', backgroundColor: Colors.primarySoft, borderRadius: Radius.lg, padding: 14 },
  heroTitle: { ...Typography.bodyBold, fontSize: 15 },
  heroSub: { ...Typography.caption, marginTop: 2 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 16 },
  action: {
    flex: 1,
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingVertical: 16,
    ...Shadow.soft,
  },
  actionIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: { ...Typography.caption, fontWeight: '700', color: Colors.textPrimary },
  section: { ...Typography.h3, fontSize: 15, marginTop: 24, marginBottom: 10 },
  faq: {
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 14,
    marginBottom: 10,
  },
  faqOpen: { borderColor: '#FFE0C2' },
  faqHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  faqQ: { ...Typography.body, fontSize: 14, fontWeight: '600', flex: 1 },
  faqA: { ...Typography.secondary, marginTop: 8, lineHeight: 20 },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    gap: 12,
  },
  infoRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  infoText: { ...Typography.secondary, flex: 1, lineHeight: 19 },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 2 },
  hoursTitle: { ...Typography.caption, fontWeight: '700', color: Colors.textPrimary, marginBottom: 4 },
  hoursText: { ...Typography.caption, lineHeight: 18 },
  footnote: { ...Typography.caption, color: Colors.textMuted, marginTop: 18, lineHeight: 17, textAlign: 'center' },
});
