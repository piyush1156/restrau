import { ChefHat } from 'lucide-react-native';
import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { Colors, Radius, Typography } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';

/**
 * Splash: brand reveal + authentication routing.
 * Waits only for real initialization (session restore); no artificial delays.
 */
export default function Splash() {
  const status = useAuthStore((s) => s.status);
  const onboarded = useAuthStore((s) => s.onboarded);
  const [minSplashDone, setMinSplashDone] = useState(false);

  useEffect(() => {
    // Only a short brand fade — redirect proceeds as soon as bootstrap finishes.
    const t = setTimeout(() => setMinSplashDone(true), 650);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (status === 'loading' || !minSplashDone) return;
    if (!onboarded) router.replace('/onboarding');
    else if (status === 'signedIn') router.replace('/(tabs)');
    else router.replace('/(auth)/login');
  }, [status, minSplashDone, onboarded]);

  return (
    <View style={styles.container}>
      <Animated.View entering={FadeIn.duration(600)} style={styles.brand}>
        <View style={styles.logoCircle}>
          <ChefHat size={44} color={Colors.primary} strokeWidth={1.7} />
        </View>
        <Text style={styles.title}>The Grove</Text>
        <Text style={styles.subtitle}>RESTAURANT & CAFE</Text>
        <Animated.Text entering={FadeInDown.delay(300).duration(500)} style={styles.tagline}>
          Good Food • Good Mood
        </Animated.Text>
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(450).duration(600)} style={styles.foodWrap}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=70' }}
          style={styles.food}
          resizeMode="cover"
          accessibilityLabel="Freshly prepared salad bowl"
        />
      </Animated.View>

      <View style={styles.loading}>
        <Animated.Text entering={FadeIn.delay(700)} style={styles.loadingText}>
          Loading...
        </Animated.Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, alignItems: 'center', justifyContent: 'center' },
  brand: { alignItems: 'center', marginTop: -60 },
  logoCircle: {
    width: 92,
    height: 92,
    borderRadius: 46,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#FFE3C7',
  },
  title: { fontSize: 34, fontWeight: '800', color: Colors.textPrimary, marginTop: 16, letterSpacing: 0.5 },
  subtitle: {
    fontSize: 12,
    letterSpacing: 5,
    color: Colors.textSecondary,
    marginTop: 4,
    fontWeight: '600',
  },
  tagline: { fontSize: 15, color: Colors.primary, fontWeight: '700', marginTop: 14 },
  foodWrap: {
    position: 'absolute',
    bottom: 110,
    width: 240,
    height: 240,
    borderRadius: 120,
    overflow: 'hidden',
    borderWidth: 6,
    borderColor: Colors.primarySoft,
  },
  food: { width: '100%', height: '100%' },
  loading: {
    position: 'absolute',
    bottom: 48,
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 26,
    paddingVertical: 11,
    borderRadius: Radius.pill,
  },
  loadingText: { ...Typography.secondary, color: Colors.primary, fontWeight: '700' },
});
