import { zodResolver } from '@hookform/resolvers/zod';
import { router } from 'expo-router';
import { Tag, TicketPercent, Trash2, X } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { AppButton } from '@/components/AppButton';
import { EmptyState, Price } from '@/components/Bits';
import { QuantityStepper } from '@/components/QuantityStepper';
import { SafeImage } from '@/components/SafeImage';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Typography } from '@/constants/theme';
import { computeTotals, couponCodeSchema, DEFAULT_RESTAURANT_CONFIG, type Coupon } from '@grove/shared';
import { groveApi } from '@/services/client';
import { useAuthStore } from '@/store/auth';
import { useCartStore } from '@/store/cart';
import { useToastStore } from '@/store/ui';
import { money } from '@/utils/format';

const CONFIG = DEFAULT_RESTAURANT_CONFIG;
type CouponForm = { code: string };

export default function CartScreen() {
  const toast = useToastStore((s) => s.show);
  const status = useAuthStore((s) => s.status);

  const lines = useCartStore((s) => s.lines);
  const orderType = useCartStore((s) => s.orderType);
  const setOrderType = useCartStore((s) => s.setOrderType);
  const setQuantity = useCartStore((s) => s.setQuantity);
  const removeLine = useCartStore((s) => s.removeLine);
  const clear = useCartStore((s) => s.clear);
  const couponCode = useCartStore((s) => s.couponCode);
  const setCoupon = useCartStore((s) => s.setCoupon);

  const [coupon, setCouponObj] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<CouponForm>({
    resolver: zodResolver(couponCodeSchema),
    defaultValues: { code: couponCode ?? '' },
  });

  const subtotal = lines.reduce((s, l) => s + l.unitPriceMinor * l.quantity, 0);
  const totals = computeTotals({ lines, coupon, config: CONFIG, orderType });

  // restore a previously applied coupon (validating it against live rules)
  useEffect(() => {
    let alive = true;
    if (couponCode && lines.length > 0) {
      groveApi
        .validateCoupon(couponCode, subtotal)
        .then((c) => {
          if (alive) setCouponObj(c);
        })
        .catch(() => {
          if (alive) {
            setCouponObj(null);
            setCoupon(null);
          }
        });
    } else {
      setCouponObj(null);
    }
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [couponCode, lines.length === 0]);

  const applyCoupon = async (values: CouponForm) => {
    setCouponError(null);
    setApplying(true);
    try {
      const valid = await groveApi.validateCoupon(values.code, subtotal);
      setCouponObj(valid);
      setCoupon(valid.code);
      toast(`Coupon ${valid.code} applied`, 'success');
    } catch (e) {
      setCouponError(e instanceof Error ? e.message : 'Could not apply this coupon.');
    } finally {
      setApplying(false);
    }
  };

  const removeCoupon = () => {
    setCouponObj(null);
    setCoupon(null);
    reset({ code: '' });
  };

  const confirmClear = () => {
    Alert.alert('Clear cart?', 'All items will be removed from your cart.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear',
        style: 'destructive',
        onPress: () => {
          clear();
          toast('Cart cleared', 'info');
        },
      },
    ]);
  };

  const goCheckout = () => {
    if (lines.length === 0) return;
    if (totals.issues.length) {
      toast(totals.issues[0], 'error');
      return;
    }
    if (status !== 'signedIn') {
      toast('Sign in to place your order.', 'info');
      router.push('/(auth)/login');
      return;
    }
    router.push('/checkout');
  };

  if (lines.length === 0) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="My Cart" onBack={() => router.back()} />
        <EmptyState
          title="Your cart is empty"
          subtitle="Add something delicious from the menu — fresh, hot and made to order."
          actionLabel="Browse Menu"
          onAction={() => router.replace('/(tabs)/menu')}
        />
      </View>
    );
  }

  return (
    <View style={styles.flex}>
      <ScreenHeader
        title="My Cart"
        onBack={() => router.back()}
        right={
          <Pressable onPress={confirmClear} hitSlop={10} accessibilityRole="button" accessibilityLabel="Clear cart">
            <Trash2 size={20} color={Colors.danger} />
          </Pressable>
        }
      />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* order type */}
        <View style={styles.typeRow}>
          {(['delivery', 'takeaway'] as const).map((type) => (
            <Pressable
              key={type}
              onPress={() => setOrderType(type)}
              style={[styles.typeChip, orderType === type && styles.typeChipOn]}
              accessibilityRole="radio"
              accessibilityState={{ selected: orderType === type }}
            >
              <Text style={[styles.typeText, orderType === type && styles.typeTextOn]}>
                {type === 'delivery' ? 'Delivery' : 'Takeaway'}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* items */}
        {lines.map((line) => (
          <View key={line.key} style={styles.card}>
            <SafeImage uri={line.imageUrl} label={line.name} style={styles.thumb} rounded={Radius.md} />
            <View style={styles.cardBody}>
              <Text style={styles.itemName} numberOfLines={1}>
                {line.name}
              </Text>
              {line.addOns.length ? (
                <Text style={styles.addons} numberOfLines={1}>
                  + {line.addOns.map((a) => a.name).join(', ')}
                </Text>
              ) : null}
              {line.specialInstructions ? (
                <Text style={styles.instructions} numberOfLines={1}>
                  “{line.specialInstructions}”
                </Text>
              ) : null}
              <View style={styles.cardFooter}>
                <Price value={money(line.unitPriceMinor * line.quantity)} />
                <QuantityStepper
                  compact
                  value={line.quantity}
                  onChange={(q) => setQuantity(line.key, q)}
                  onRemove={() => removeLine(line.key)}
                  label={line.name}
                />
              </View>
            </View>
          </View>
        ))}

        {/* coupon */}
        <View style={styles.couponCard}>
          <View style={styles.couponRow}>
            <View style={styles.couponIcon}>
              <TicketPercent size={18} color={Colors.primary} />
            </View>
            <Controller
              control={control}
              name="code"
              render={({ field: { onChange, onBlur, value } }) => (
                <TextInput
                  value={value}
                  onChangeText={(v) => onChange(v.toUpperCase())}
                  onBlur={onBlur}
                  placeholder="Coupon code (try GROVE10)"
                  placeholderTextColor={Colors.textMuted}
                  autoCapitalize="characters"
                  style={styles.couponInput}
                  accessibilityLabel="Coupon code"
                />
              )}
            />
            <Pressable
              onPress={handleSubmit(applyCoupon)}
              disabled={applying}
              style={[styles.applyBtn, applying && { opacity: 0.6 }]}
              accessibilityRole="button"
              accessibilityLabel="Apply coupon"
            >
              <Text style={styles.applyText}>{applying ? '...' : 'APPLY'}</Text>
            </Pressable>
          </View>
          {errors.code ? <Text style={styles.couponErr}>{errors.code.message}</Text> : null}
          {couponError ? <Text style={styles.couponErr}>{couponError}</Text> : null}
          {coupon && totals.discountMinor > 0 ? (
            <View style={styles.appliedRow}>
              <Tag size={14} color={Colors.success} />
              <Text style={styles.appliedText}>
                {coupon.code} — you save {money(totals.discountMinor)}
              </Text>
              <Pressable onPress={removeCoupon} hitSlop={8} accessibilityLabel="Remove coupon">
                <X size={16} color={Colors.textSecondary} />
              </Pressable>
            </View>
          ) : coupon && totals.discountMinor === 0 ? (
            <Text style={styles.couponErr}>
              {coupon.code} no longer applies to this cart (minimum order not met).
            </Text>
          ) : null}
        </View>

        {/* bill */}
        <View style={styles.bill}>
          <Text style={styles.billTitle}>Bill Summary</Text>
          <Row label={`Items Total (${lines.reduce((s, l) => s + l.quantity, 0)} items)`} value={money(totals.subtotalMinor)} />
          {totals.discountMinor > 0 ? (
            <Row label="Coupon Discount" value={`− ${money(totals.discountMinor)}`} tone="success" />
          ) : null}
          <Row label="GST (5%)" value={money(totals.taxesMinor)} />
          <Row
            label={orderType === 'delivery' ? 'Delivery Charges' : 'Takeaway (no delivery fee)'}
            value={orderType === 'delivery' ? (totals.deliveryFeeMinor === 0 ? 'FREE' : money(totals.deliveryFeeMinor)) : '—'}
            tone={totals.deliveryFeeMinor === 0 && orderType === 'delivery' ? 'success' : undefined}
          />
          <Row label="Platform Fee" value={money(totals.platformFeeMinor)} />
          <View style={styles.billDivider} />
          <Row label="Total" value={money(totals.grandTotalMinor)} bold />
        </View>

        {orderType === 'delivery' ? (
          <Text style={styles.note}>
            Free delivery above ₹{CONFIG.freeDeliveryAboveMinor / 100}. Minimum order ₹
            {CONFIG.minOrderMinor / 100} for delivery.
          </Text>
        ) : null}
        {totals.issues.map((issue) => (
          <View key={issue} style={styles.issue}>
            <Text style={styles.issueText}>{issue}</Text>
          </View>
        ))}

        <View style={{ height: 110 }} />
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.footerTotal}>
          <Text style={styles.footerLabel}>Total</Text>
          <Text style={styles.footerValue}>{money(totals.grandTotalMinor)}</Text>
        </View>
        <AppButton
          label="Proceed to Checkout"
          onPress={goCheckout}
          disabled={totals.issues.length > 0}
          style={{ flex: 1 }}
        />
      </View>
    </View>
  );
}

function Row({
  label,
  value,
  bold,
  tone,
}: {
  label: string;
  value: string;
  bold?: boolean;
  tone?: 'success';
}) {
  return (
    <View style={styles.row}>
      <Text style={[styles.rowLabel, bold && styles.rowBold]}>{label}</Text>
      <Text
        style={[
          styles.rowValue,
          bold && styles.rowBold,
          tone === 'success' && { color: Colors.success },
        ]}
      >
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: 16, paddingTop: 16 },
  typeRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  typeChip: {
    flex: 1,
    minHeight: 44,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  typeChipOn: { backgroundColor: Colors.primarySoft, borderColor: Colors.primary },
  typeText: { ...Typography.secondary, fontWeight: '700' },
  typeTextOn: { color: Colors.primary },
  card: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
    marginBottom: 12,
  },
  thumb: { width: 72, height: 72 },
  cardBody: { flex: 1 },
  itemName: { ...Typography.bodyBold },
  addons: { ...Typography.caption, marginTop: 2 },
  instructions: { ...Typography.caption, fontStyle: 'italic', marginTop: 2, color: Colors.textMuted },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  couponCard: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 14,
    marginTop: 6,
  },
  couponRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  couponIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  couponInput: {
    flex: 1,
    fontSize: 14,
    color: Colors.textPrimary,
    paddingVertical: 10,
    letterSpacing: 0.6,
  },
  applyBtn: {
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.pill,
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderWidth: 1,
    borderColor: '#FFD9B8',
  },
  applyText: { color: Colors.primary, fontWeight: '800', fontSize: 13 },
  couponErr: { ...Typography.caption, color: Colors.danger, marginTop: 8 },
  appliedRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  appliedText: { ...Typography.caption, color: Colors.success, fontWeight: '700', flex: 1 },
  bill: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    marginTop: 16,
  },
  billTitle: { ...Typography.h3, marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 9 },
  rowLabel: { ...Typography.secondary, flexShrink: 1, marginRight: 8 },
  rowValue: { ...Typography.body, fontSize: 14, fontWeight: '600' },
  rowBold: { ...Typography.h3, fontSize: 16 },
  billDivider: { height: 1, backgroundColor: Colors.border, marginVertical: 6 },
  note: { ...Typography.caption, textAlign: 'center', marginTop: 12, lineHeight: 17 },
  issue: {
    backgroundColor: Colors.warningSoft,
    borderRadius: Radius.md,
    padding: 12,
    marginTop: 12,
  },
  issueText: { color: Colors.warning, fontSize: 13, fontWeight: '600', textAlign: 'center' },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 26,
  },
  footerTotal: {},
  footerLabel: { ...Typography.caption },
  footerValue: { ...Typography.h3, color: Colors.primary, fontSize: 18 },
});
