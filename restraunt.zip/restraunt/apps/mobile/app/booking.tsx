import { router } from 'expo-router';
import {
  Armchair,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Sofa,
  Trees,
  Users,
  UtensilsCrossed,
  X,
} from 'lucide-react-native';
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { Chip, EmptyState, StatusBadge } from '@/components/Bits';
import { AppButton } from '@/components/AppButton';
import { SafeImage } from '@/components/SafeImage';
import { ScreenHeader } from '@/components/ScreenHeader';
import { Colors, Radius, Shadow, Typography } from '@/constants/theme';
import { reservationSchema } from '@grove/shared';
import type { SeatPreference } from '@grove/shared';
import { useAvailability, useReservations } from '@/hooks/useQueries';
import { groveApi } from '@/services/client';
import { useAuthStore } from '@/store/auth';
import { useToastStore } from '@/store/ui';
import { addDays, dateForInput, formatDate, formatSlot } from '@/utils/format';
import { useQueryClient } from '@tanstack/react-query';
import { qk } from '@/hooks/useQueries';

const SEATING: { key: SeatPreference; label: string; icon: typeof Sofa }[] = [
  { key: 'indoor', label: 'Indoor', icon: Sofa },
  { key: 'outdoor', label: 'Outdoor', icon: Trees },
  { key: 'any', label: 'No preference', icon: UtensilsCrossed },
];

export default function BookingScreen() {
  const insets = useSafeAreaInsets();
  const toast = useToastStore((s) => s.show);
  const profile = useAuthStore((s) => s.profile);
  const status = useAuthStore((s) => s.status);
  const qc = useQueryClient();

  const [selectedDate, setSelectedDate] = useState(dateForInput(new Date()));
  const [guests, setGuests] = useState(2);
  const [seating, setSeating] = useState<SeatPreference>('any');
  const [time, setTime] = useState<string | null>(null);
  const [requests, setRequests] = useState('');
  const [step, setStep] = useState<'select' | 'confirm' | 'done'>('select');
  const [confirmed, setConfirmed] = useState<{ code: string; table?: number | null; date: string; time: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [fieldError, setFieldError] = useState<string | null>(null);

  const dates = useMemo(
    () =>
      Array.from({ length: 10 }, (_, i) => {
        const d = addDays(new Date(), i);
        return {
          value: dateForInput(d),
          label: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString('en-IN', { weekday: 'short' }),
          day: d.getDate(),
          month: d.toLocaleDateString('en-IN', { month: 'short' }),
        };
      }),
    [],
  );

  const { data: availability, isLoading, isError, refetch, isFetching } = useAvailability(selectedDate, guests);
  const { data: reservations, refetch: refetchReservations } = useReservations(Boolean(profile));

  const myReservations = (reservations ?? []).filter((r) => ['pending', 'confirmed'].includes(r.status));

  const onFind = () => {
    setFieldError(null);
    if (!time) {
      setFieldError('Pick a time slot to see available tables.');
      return;
    }
    if (!availability?.tables.length) {
      setFieldError('No tables fit this party size. Try a different guest count.');
      return;
    }
    setStep('confirm');
  };

  const onConfirm = async () => {
    if (!time) return;
    const parsed = reservationSchema.safeParse({
      date: selectedDate,
      time,
      guests,
      seating,
      specialRequests: requests,
    });
    if (!parsed.success) {
      setFieldError(parsed.error.issues[0]?.message ?? 'Check your booking details.');
      return;
    }
    setSaving(true);
    setFieldError(null);
    try {
      const res = await groveApi.createReservation(parsed.data);
      setConfirmed({ code: res.code, table: res.tableNumber, date: res.date, time: res.time });
      setStep('done');
      qc.invalidateQueries({ queryKey: qk.reservations });
      qc.invalidateQueries({ queryKey: ['availability'] });
      refetchReservations();
    } catch (e) {
      setFieldError(e instanceof Error ? e.message : 'Could not confirm this booking.');
    } finally {
      setSaving(false);
    }
  };

  const cancelReservation = (id: string, code: string) => {
    Alert.alert('Cancel reservation?', `Booking ${code} will be released for other guests.`, [
      { text: 'Keep it', style: 'cancel' },
      {
        text: 'Cancel booking',
        style: 'destructive',
        onPress: async () => {
          try {
            await groveApi.cancelReservation(id);
            toast('Reservation cancelled', 'info');
            refetchReservations();
            qc.invalidateQueries({ queryKey: ['availability'] });
          } catch (e) {
            toast(e instanceof Error ? e.message : 'Could not cancel the reservation.', 'error');
          }
        },
      },
    ]);
  };

  if (status !== 'signedIn') {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Table Booking" onBack={() => router.back()} />
        <EmptyState
          title="Sign in to book a table"
          subtitle="We hold confirmed tables for you with a booking code you can cancel any time."
          actionLabel="Sign In"
          onAction={() => router.push('/(auth)/login')}
        />
      </View>
    );
  }

  if (step === 'done' && confirmed) {
    return (
      <View style={styles.flex}>
        <ScreenHeader title="Booking Confirmed" onBack={() => router.back()} />
        <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 30 }]}>
          <Animated.View entering={FadeInDown.duration(320)} style={styles.confirmCard}>
            <View style={styles.confirmIcon}>
              <CheckCircle2 size={34} color={Colors.success} />
            </View>
            <Text style={styles.confirmTitle}>Table booked!</Text>
            <Text style={styles.confirmSub}>Show this code at the entrance — we’ll keep the table ready.</Text>
            <View style={styles.codeBox}>
              <Text style={styles.codeLabel}>BOOKING CODE</Text>
              <Text style={styles.code}>{confirmed.code}</Text>
            </View>
            <View style={styles.detailRow}>
              <CalendarDays size={18} color={Colors.primary} />
              <Text style={styles.detailText}>{formatDate(`${confirmed.date}T12:00:00`)}</Text>
            </View>
            <View style={styles.detailRow}>
              <Clock3 size={18} color={Colors.primary} />
              <Text style={styles.detailText}>{formatSlot(confirmed.time)}</Text>
            </View>
            <View style={styles.detailRow}>
              <Users size={18} color={Colors.primary} />
              <Text style={styles.detailText}>{guests} guest{guests > 1 ? 's' : ''}</Text>
            </View>
            <View style={styles.detailRow}>
              <Armchair size={18} color={Colors.primary} />
              <Text style={styles.detailText}>
                {confirmed.table ? `Table ${confirmed.table}` : 'Table assigned on arrival'} • {seating === 'any' ? 'No preference' : seating}
              </Text>
            </View>
            {requests.trim() ? (
              <View style={styles.requestNote}>
                <Text style={styles.requestLabel}>Your note</Text>
                <Text style={styles.requestText}>{requests.trim()}</Text>
              </View>
            ) : null}
            <AppButton label="Done" onPress={() => router.back()} style={{ marginTop: 18 }} />
            <AppButton
              label="Book another table"
              variant="ghost"
              onPress={() => {
                setStep('select');
                setTime(null);
                setConfirmed(null);
                setRequests('');
              }}
              style={{ marginTop: 10 }}
            />
          </Animated.View>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.flex}>
      <ScreenHeader title="Table Booking" onBack={() => router.back()} />
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* interior hero */}
        <View style={styles.hero}>
          <SafeImage
            uri="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=70"
            label="Restaurant interior"
            style={StyleSheet.absoluteFill}
            rounded={Radius.xl}
          />
          <View style={styles.heroTint} />
          <View style={styles.heroBody}>
            <Text style={styles.heroTitle}>Book Your Table</Text>
            <Text style={styles.heroSub}>Enjoy a great dining experience at The Grove.</Text>
          </View>
        </View>

        {/* date */}
        <Text style={styles.sectionTitle}>Select Date</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingRight: 8 }}>
          {dates.map((d) => {
            const active = selectedDate === d.value;
            return (
              <Pressable
                key={d.value}
                onPress={() => {
                  setSelectedDate(d.value);
                  setTime(null);
                  setStep('select');
                }}
                style={[styles.dateChip, active && styles.dateChipOn]}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
                accessibilityLabel={`${d.label}, ${d.day} ${d.month}`}
              >
                <Text style={[styles.dateWeekday, active && styles.dateTextOn]}>{d.label}</Text>
                <Text style={[styles.dateDay, active && styles.dateTextOn]}>{d.day}</Text>
                <Text style={[styles.dateMonth, active && styles.dateTextOn]}>{d.month}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* guests */}
        <Text style={styles.sectionTitle}>Guests</Text>
        <View style={styles.guestRow}>
          <Users size={20} color={Colors.textSecondary} />
          <Text style={styles.guestLabel}>How many guests?</Text>
          <View style={styles.stepper}>
            <Pressable
              onPress={() => {
                setGuests((g) => Math.max(1, g - 1));
                setTime(null);
                setStep('select');
              }}
              style={styles.stepBtn}
              accessibilityRole="button"
              accessibilityLabel="Fewer guests"
            >
              <Text style={styles.stepText}>−</Text>
            </Pressable>
            <Text style={styles.guestCount}>{guests}</Text>
            <Pressable
              onPress={() => {
                setGuests((g) => Math.min(12, g + 1));
                setTime(null);
                setStep('select');
              }}
              style={styles.stepBtn}
              accessibilityRole="button"
              accessibilityLabel="More guests"
            >
              <Text style={styles.stepText}>+</Text>
            </Pressable>
          </View>
        </View>

        {/* seating */}
        <Text style={styles.sectionTitle}>Seating Preference</Text>
        <View style={styles.seatingRow}>
          {SEATING.map((s) => {
            const active = seating === s.key;
            return (
              <Pressable
                key={s.key}
                onPress={() => setSeating(s.key)}
                style={[styles.seatingCard, active && styles.seatingCardOn]}
                accessibilityRole="radio"
                accessibilityState={{ selected: active }}
              >
                <s.icon size={18} color={active ? Colors.primary : Colors.textSecondary} />
                <Text style={[styles.seatingText, active && { color: Colors.primary }]}>{s.label}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* slots */}
        <View style={styles.slotHead}>
          <Text style={styles.sectionTitle}>Available Time Slots</Text>
          {isFetching ? <ActivityIndicator size="small" color={Colors.primary} /> : null}
        </View>

        {isLoading ? (
          <View style={styles.slotGrid}>
            {Array.from({ length: 8 }).map((_, i) => (
              <View key={i} style={[styles.slot, { opacity: 0.5 }]} />
            ))}
          </View>
        ) : isError ? (
          <EmptyState
            tone="error"
            title="Couldn’t load slots"
            subtitle="Check your connection and retry."
            actionLabel="Retry"
            onAction={() => refetch()}
          />
        ) : (availability?.slots.length ?? 0) === 0 ? (
          <EmptyState
            title="No slots for this date"
            subtitle="We may be closed or fully booked. Try another day."
          />
        ) : (
          <View style={styles.slotGrid}>
            {availability!.slots.map((slot) => {
              const active = time === slot;
              const busy = availability!.bookedTimes.includes(slot);
              return (
                <Pressable
                  key={slot}
                  onPress={() => {
                    setTime(slot);
                    setStep('select');
                    setFieldError(null);
                  }}
                  style={[styles.slot, active && styles.slotOn]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  accessibilityLabel={`${formatSlot(slot)}${busy ? ', already has bookings' : ''}`}
                >
                  <Text style={[styles.slotText, active && styles.slotTextOn]}>{formatSlot(slot)}</Text>
                  {busy ? <View style={[styles.busyDot, active && { backgroundColor: Colors.white }]} /> : null}
                </Pressable>
              );
            })}
          </View>
        )}

        {/* special requests */}
        <Text style={styles.sectionTitle}>Special Requests</Text>
        <View style={styles.requestsWrap}>
          <TextInput
            value={requests}
            onChangeText={(v) => setRequests(v.slice(0, 200))}
            placeholder="Birthday celebration, high chair, window seat…"
            placeholderTextColor={Colors.textMuted}
            multiline
            style={styles.requests}
            accessibilityLabel="Special requests for your booking"
          />
          <Text style={styles.counter}>{requests.length}/200</Text>
        </View>

        {fieldError ? (
          <View style={styles.errorBox} accessibilityRole="alert">
            <Text style={styles.errorText}>{fieldError}</Text>
          </View>
        ) : null}

        {/* find / confirm */}
        {step === 'select' ? (
          <AppButton
            label="Find Table"
            onPress={onFind}
            disabled={!time}
            loading={isFetching}
            style={{ marginTop: 18 }}
          />
        ) : (
          <Animated.View entering={FadeInDown.duration(260)} style={styles.tablesCard}>
            <Text style={styles.tablesTitle}>Available Tables</Text>
            <Text style={styles.tablesSub}>
              {formatDate(`${selectedDate}T12:00:00`)} • {formatSlot(time!)}
            </Text>
            <View style={styles.tableChips}>
              {(availability?.tables ?? []).slice(0, 6).map((t) => (
                <View key={t.id} style={styles.tableChip}>
                  <UtensilsCrossed size={14} color={Colors.primary} />
                  <Text style={styles.tableChipText}>
                    Table {t.tableNumber} • {t.capacity} seats • {t.seating}
                  </Text>
                </View>
              ))}
            </View>
            <Text style={styles.tableNote}>
              A table is assigned when you confirm — capacity and seating are matched to your party.
            </Text>
            <View style={styles.confirmActions}>
              <AppButton label="Confirm Booking" onPress={onConfirm} loading={saving} style={{ flex: 1 }} />
              <Pressable
                onPress={() => {
                  setStep('select');
                  setFieldError(null);
                }}
                style={styles.backBtn}
                accessibilityRole="button"
                accessibilityLabel="Choose a different time"
              >
                <X size={18} color={Colors.textSecondary} />
              </Pressable>
            </View>
          </Animated.View>
        )}

        {/* my reservations */}
        {myReservations.length > 0 ? (
          <View style={styles.myBlock}>
            <Text style={styles.sectionTitle}>My Reservations</Text>
            {myReservations.map((r) => (
              <View key={r.id} style={styles.resCard}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.resTitle}>
                    {formatDate(`${r.date}T12:00:00`)} • {formatSlot(r.time)}
                  </Text>
                  <Text style={styles.resSub}>
                    {r.code} • {r.guests} guest{r.guests > 1 ? 's' : ''}
                    {r.tableNumber ? ` • Table ${r.tableNumber}` : ''}
                  </Text>
                </View>
                <StatusBadge status={r.status} />
                <Pressable
                  onPress={() => cancelReservation(r.id, r.code)}
                  hitSlop={8}
                  accessibilityRole="button"
                  accessibilityLabel={`Cancel reservation ${r.code}`}
                  style={styles.cancelRes}
                >
                  <X size={16} color={Colors.danger} />
                </Pressable>
              </View>
            ))}
          </View>
        ) : null}

        <View style={styles.policy}>
          <Text style={styles.policyTitle}>Booking policy</Text>
          <Text style={styles.policyText}>
            Tables are held for 15 minutes past the booked time. Groups above 20 guests should call the restaurant.
            Cancellations are free up to 2 hours before your slot.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: Colors.background },
  scroll: { padding: 16 },
  hero: { height: 168, borderRadius: Radius.xl, overflow: 'hidden', justifyContent: 'flex-end' },
  heroTint: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(23,23,23,0.38)' },
  heroBody: { padding: 18 },
  heroTitle: { fontSize: 24, fontWeight: '800', color: Colors.white },
  heroSub: { ...Typography.caption, color: 'rgba(255,255,255,0.92)', marginTop: 4 },
  sectionTitle: { ...Typography.h3, fontSize: 15, marginTop: 22, marginBottom: 12 },
  dateChip: {
    width: 62,
    paddingVertical: 10,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
    gap: 2,
  },
  dateChipOn: { backgroundColor: Colors.primary, borderColor: Colors.primary, ...Shadow.floating },
  dateWeekday: { fontSize: 11, color: Colors.textSecondary, fontWeight: '600' },
  dateDay: { fontSize: 18, fontWeight: '800', color: Colors.textPrimary },
  dateMonth: { fontSize: 10, color: Colors.textMuted },
  dateTextOn: { color: Colors.white },
  guestRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  guestLabel: { ...Typography.body, fontSize: 14, flex: 1 },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  stepBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepText: { color: Colors.primary, fontSize: 18, fontWeight: '800', lineHeight: 20 },
  guestCount: { ...Typography.bodyBold, minWidth: 18, textAlign: 'center' },
  seatingRow: { flexDirection: 'row', gap: 8 },
  seatingCard: {
    flex: 1,
    minHeight: 48,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: 8,
  },
  seatingCardOn: { borderColor: Colors.primary, backgroundColor: Colors.primarySoft },
  seatingText: { fontSize: 11, fontWeight: '600', color: Colors.textSecondary, textAlign: 'center' },
  slotHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  slotGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  slot: {
    width: '30.5%',
    minHeight: 44,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 5,
  },
  slotOn: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  slotText: { fontSize: 13, fontWeight: '600', color: Colors.textPrimary },
  slotTextOn: { color: Colors.white },
  busyDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: Colors.primary },
  requestsWrap: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.lg,
    backgroundColor: Colors.white,
    padding: 12,
  },
  requests: { minHeight: 64, fontSize: 14, color: Colors.textPrimary, textAlignVertical: 'top' },
  counter: { ...Typography.caption, color: Colors.textMuted, textAlign: 'right' },
  errorBox: { backgroundColor: Colors.dangerSoft, borderRadius: Radius.md, padding: 12, marginTop: 12 },
  errorText: { ...Typography.caption, color: Colors.danger, textAlign: 'center' },
  tablesCard: {
    marginTop: 18,
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 16,
    ...Shadow.card,
  },
  tablesTitle: { ...Typography.h3 },
  tablesSub: { ...Typography.caption, marginTop: 2 },
  tableChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  tableChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: Radius.pill,
  },
  tableChipText: { fontSize: 11, fontWeight: '600', color: Colors.primary },
  tableNote: { ...Typography.caption, marginTop: 12, lineHeight: 17 },
  confirmActions: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 16 },
  backBtn: {
    width: 52,
    height: 52,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  myBlock: { marginTop: 8 },
  resCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 12,
    marginBottom: 8,
  },
  resTitle: { ...Typography.bodyBold, fontSize: 14 },
  resSub: { ...Typography.caption, marginTop: 2 },
  cancelRes: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: Colors.dangerSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  policy: {
    marginTop: 24,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.lg,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  policyTitle: { ...Typography.bodyBold, fontSize: 13 },
  policyText: { ...Typography.caption, marginTop: 4, lineHeight: 18 },
  confirmCard: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xxl,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: 22,
    alignItems: 'center',
    ...Shadow.card,
  },
  confirmIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.successSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  confirmTitle: { ...Typography.h1, fontSize: 22 },
  confirmSub: { ...Typography.secondary, textAlign: 'center', marginTop: 6, lineHeight: 19 },
  codeBox: {
    marginTop: 18,
    backgroundColor: Colors.primarySoft,
    borderRadius: Radius.lg,
    paddingVertical: 12,
    paddingHorizontal: 28,
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  codeLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.6, color: Colors.primary },
  code: { fontSize: 24, fontWeight: '800', letterSpacing: 3, color: Colors.primary, marginTop: 2 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 10, alignSelf: 'stretch', marginTop: 12 },
  detailText: { ...Typography.body, fontSize: 14 },
  requestNote: {
    alignSelf: 'stretch',
    marginTop: 14,
    backgroundColor: Colors.backgroundAlt,
    borderRadius: Radius.md,
    padding: 12,
  },
  requestLabel: { ...Typography.caption, fontWeight: '700', color: Colors.textPrimary },
  requestText: { ...Typography.secondary, marginTop: 3, lineHeight: 18 },
});
