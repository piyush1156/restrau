'use client';

import { useCallback, useEffect, useRef, useState } from 'react';

export const API_BASE = (process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000').replace(/\/+$/, '');

export type StaffRole = 'owner' | 'manager' | 'kitchen' | 'delivery';

export interface AdminProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string | null;
  role: StaffRole;
  locale: string;
  avatarUrl: string | null;
  createdAt: string;
}

export interface Session {
  token: string;
  profile: AdminProfile;
}

const TOKEN_KEY = 'grove-admin-token';
const PROFILE_KEY = 'grove-admin-profile';

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export const getSession = (): Session | null => {
  if (typeof window === 'undefined') return null;
  const token = window.localStorage.getItem(TOKEN_KEY);
  const raw = window.localStorage.getItem(PROFILE_KEY);
  if (!token || !raw) return null;
  try {
    return { token, profile: JSON.parse(raw) as AdminProfile };
  } catch {
    return null;
  }
};

export const setSession = (session: Session): void => {
  window.localStorage.setItem(TOKEN_KEY, session.token);
  window.localStorage.setItem(PROFILE_KEY, JSON.stringify(session.profile));
};

export const clearSession = (): void => {
  window.localStorage.removeItem(TOKEN_KEY);
  window.localStorage.removeItem(PROFILE_KEY);
};

export const apiFetch = async <T>(
  path: string,
  init: RequestInit = {},
  token?: string | null,
): Promise<T> => {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
    cache: 'no-store',
  });

  const text = await res.text();
  const body = text ? JSON.parse(text) : {};

  if (!res.ok) {
    if (res.status === 401 && typeof window !== 'undefined') {
      clearSession();
    }
    throw new ApiError(
      body?.error?.message ?? `Request failed (${res.status})`,
      res.status,
      body?.error?.code ?? 'request_failed',
    );
  }
  return body as T;
};

/* ------------------------------------------------------------- data hooks */

export interface AsyncState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  reload: () => void;
}

export const useApi = <T>(path: string | null, deps: unknown[] = []): AsyncState<T> => {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(Boolean(path));
  const [error, setError] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  useEffect(() => {
    if (!path) {
      setLoading(false);
      return;
    }
    const session = getSession();
    if (!session) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    apiFetch<T>(path, {}, session.token)
      .then((res) => {
        if (mounted.current) setData(res);
      })
      .catch((err: unknown) => {
        if (mounted.current) setError(err instanceof Error ? err.message : 'Could not load data.');
      })
      .finally(() => {
        if (mounted.current) setLoading(false);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, nonce, ...deps]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { data, loading, error, reload };
};

export interface Toast {
  message: string;
  type: 'success' | 'error' | 'info';
}

export const useToast = () => {
  const [toast, setToast] = useState<Toast | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback((message: string, type: Toast['type'] = 'info') => {
    setToast({ message, type });
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  return { toast, show };
};

export const formatMoney = (minor: number): string =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: minor % 100 === 0 ? 0 : 2,
  }).format(minor / 100);

export const formatDate = (iso: string): string =>
  new Date(iso).toLocaleString('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
