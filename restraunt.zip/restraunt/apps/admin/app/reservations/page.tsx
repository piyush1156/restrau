'use client';

import { CalendarDays, Check, RefreshCw, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch, getSession, useApi, useToast, type Session } from '@/lib/api';
import { EmptyState, ErrorState, Spinner, StatusBadge, TableSkeleton, ToastAlert } from '@/components/ui';

interface ReservationRow {
  id: string;
  code: string;
  customerName: string;
  customerPhone: string;
  date: string;
  time: string;
  guests: number;
  seating: string;
  tableNumber: number | null;
  specialRequests: string | null;
  status: string;
}

interface Response {
  date: string;
  data: ReservationRow[];
  tables: { id: string; tableNumber: number; capacity: number; seating: string; is_active: boolean }[];
}

const today = () => new Date().toISOString().slice(0, 10);

export default function ReservationsPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [date, setDate] = useState(today());
  const { toast, show } = useToast();
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => setSession(getSession()), []);

  const { data, loading, error, reload } = useApi<Response>(
    session ? `/admin/reservations?date=${date}` : null,
    [date, session?.token],
  );

  const setStatus = async (row: ReservationRow, status: string) => {
    if (!session) return;
    setBusy(row.id);
    try {
      await apiFetch(
        `/admin/reservations/${row.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status }) },
        session.token,
      );
      show(`Booking ${row.code} → ${status}`, 'success');
      reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not update the reservation.', 'error');
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="page">
      <div className="card">
        <div className="toolbar">
          <div className="row" style={{ gap: 8 }}>
            <CalendarDays size={16} color="#FF7900" />
            <input
              className="input"
              type="date"
              value={date}
              min={today()}
              onChange={(e) => setDate(e.target.value)}
              style={{ minWidth: 170 }}
              aria-label="Reservation date"
            />
          </div>
          <div className="row wrap" style={{ gap: 6 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setDate(today())}>
              Today
            </button>
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => setDate(new Date(Date.now() + 86400000).toISOString().slice(0, 10))}
            >
              Tomorrow
            </button>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={reload} style={{ marginLeft: 'auto' }}>
            <RefreshCw size={14} /> Refresh
          </button>
        </div>
        <div className="hint" style={{ marginTop: 10 }}>
          {data?.tables.length ?? 0} active tables • {data?.data.length ?? 0} bookings for this date. Double bookings are
          blocked by a database constraint, not just the UI.
        </div>
      </div>

      <div className="card">
        {loading ? (
          <TableSkeleton rows={5} />
        ) : error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (data?.data.length ?? 0) === 0 ? (
          <EmptyState title="No reservations for this date" subtitle="Pick another date to see upcoming bookings." />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Guest</th>
                  <th>Time</th>
                  <th>Party</th>
                  <th>Table</th>
                  <th>Requests</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data!.data.map((row) => (
                  <tr key={row.id} className="row-hover">
                    <td>
                      <strong>{row.code}</strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{row.customerName || 'Guest'}</div>
                      <div style={{ fontSize: 11, color: '#737373' }}>{row.customerPhone || '—'}</div>
                    </td>
                    <td>{row.time}</td>
                    <td>
                      {row.guests} guest{row.guests > 1 ? 's' : ''}
                      <div style={{ fontSize: 10, color: '#737373', textTransform: 'capitalize' }}>{row.seating}</div>
                    </td>
                    <td>{row.tableNumber ? `Table ${row.tableNumber}` : '—'}</td>
                    <td style={{ maxWidth: 220, fontSize: 12 }}>{row.specialRequests ?? '—'}</td>
                    <td>
                      <StatusBadge status={row.status} />
                    </td>
                    <td>
                      <div className="row" style={{ justifyContent: 'flex-end', gap: 6 }}>
                        {row.status === 'pending' ? (
                          <>
                            <button
                              className="btn btn-soft btn-sm"
                              disabled={busy === row.id}
                              onClick={() => setStatus(row, 'confirmed')}
                            >
                              <Check size={13} /> Confirm
                            </button>
                            <button
                              className="btn btn-danger btn-sm"
                              disabled={busy === row.id}
                              onClick={() => setStatus(row, 'rejected')}
                            >
                              <X size={13} /> Reject
                            </button>
                          </>
                        ) : row.status === 'confirmed' ? (
                          <>
                            <button
                              className="btn btn-ghost btn-sm"
                              disabled={busy === row.id}
                              onClick={() => setStatus(row, 'completed')}
                            >
                              Complete
                            </button>
                            <button
                              className="btn btn-danger btn-sm"
                              disabled={busy === row.id}
                              onClick={() => setStatus(row, 'cancelled')}
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <span className="hint">No actions</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-title" style={{ marginBottom: 12 }}>
          Tables
        </div>
        <div className="row wrap" style={{ gap: 8 }}>
          {(data?.tables ?? []).map((t) => (
            <span key={t.id} className="badge badge-gray">
              Table {t.tableNumber} • {t.capacity} seats • {t.seating}
            </span>
          ))}
        </div>
      </div>

      {loading ? <Spinner label="Loading bookings…" /> : null}
      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
