'use client';

import { Plus, TicketPercent } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch, formatMoney, getSession, useApi, useToast, type Session } from '@/lib/api';
import { EmptyState, ErrorState, Field, Modal, TableSkeleton, ToastAlert } from '@/components/ui';

interface Coupon {
  code: string;
  description: string;
  discountPercent?: number;
  discountFlatMinor?: number;
  maxDiscountMinor?: number | null;
  minOrderMinor: number;
  expiresAt: string;
  isActive: boolean;
  usageLimit: number | null;
  usedCount: number;
}

interface CouponRow extends Coupon {
  id: string;
}

const empty = {
  code: '',
  description: '',
  mode: 'percent' as 'percent' | 'flat',
  value: '',
  maxDiscount: '',
  minOrder: '',
  expiresAt: '',
  usageLimit: '',
};

export default function CouponsPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const { toast, show } = useToast();

  useEffect(() => setSession(getSession()), []);

  const { data, loading, error, reload } = useApi<{ data: CouponRow[] }>(
    session ? '/admin/coupons' : null,
    [session?.token],
  );

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    const next: Record<string, string> = {};
    if (!/^[A-Z0-9]{3,24}$/.test(form.code.trim().toUpperCase())) next.code = 'Use 3–24 letters or numbers';
    if (form.description.trim().length < 3) next.description = 'Describe the offer';
    const value = Number(form.value);
    if (!Number.isFinite(value) || value <= 0) next.value = 'Enter a discount value';
    if (!form.expiresAt) next.expiresAt = 'Pick an expiry';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      await apiFetch(
        '/admin/coupons',
        {
          method: 'POST',
          body: JSON.stringify({
            code: form.code.trim().toUpperCase(),
            description: form.description.trim(),
            ...(form.mode === 'percent'
              ? { discountPercent: Math.round(value) }
              : { discountFlatMinor: Math.round(value * 100) }),
            maxDiscountMinor: form.mode === 'percent' && form.maxDiscount ? Math.round(Number(form.maxDiscount) * 100) : null,
            minOrderMinor: Math.round(Number(form.minOrder || 0) * 100),
            expiresAt: new Date(form.expiresAt).toISOString(),
            usageLimit: form.usageLimit ? Number(form.usageLimit) : null,
          }),
        },
        session.token,
      );
      show('Coupon created', 'success');
      setShowForm(false);
      setForm(empty);
      reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not create the coupon.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (coupon: CouponRow) => {
    if (!session) return;
    try {
      await apiFetch(
        `/admin/coupons/${coupon.id}`,
        { method: 'PATCH', body: JSON.stringify({ isActive: !coupon.isActive }) },
        session.token,
      );
      show(`${coupon.code} ${coupon.isActive ? 'paused' : 'activated'}`, 'success');
      reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not update the coupon.', 'error');
    }
  };

  if (!session) return null;

  return (
    <div className="page">
      <div className="card">
        <div className="row-between">
          <div className="row">
            <TicketPercent size={18} color="#FF7900" />
            <div>
              <div className="card-title">Active offers</div>
              <div className="hint">Discounts apply to the item subtotal before GST. One per order.</div>
            </div>
          </div>
          <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}>
            <Plus size={15} /> New coupon
          </button>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <TableSkeleton rows={4} />
        ) : error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (data?.data.length ?? 0) === 0 ? (
          <EmptyState title="No coupons yet" subtitle="Create a welcome offer or a weekend deal." />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Discount</th>
                  <th>Min order</th>
                  <th>Usage</th>
                  <th>Expires</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {data!.data.map((c) => {
                  const expired = new Date(c.expiresAt) < new Date();
                  return (
                    <tr key={c.id} className="row-hover">
                      <td>
                        <strong style={{ letterSpacing: 0.6 }}>{c.code}</strong>
                        <div style={{ fontSize: 11, color: '#737373', maxWidth: 240 }}>{c.description}</div>
                      </td>
                      <td style={{ fontWeight: 600 }}>
                        {c.discountPercent ? `${c.discountPercent}%` : formatMoney(c.discountFlatMinor ?? 0)}
                        {c.maxDiscountMinor ? (
                          <div style={{ fontSize: 10, color: '#737373' }}>max {formatMoney(c.maxDiscountMinor)}</div>
                        ) : null}
                      </td>
                      <td style={{ fontSize: 12 }}>{c.minOrderMinor ? formatMoney(c.minOrderMinor) : 'None'}</td>
                      <td style={{ fontSize: 12 }}>
                        {c.usedCount}
                        {c.usageLimit ? ` / ${c.usageLimit}` : ''}
                      </td>
                      <td style={{ fontSize: 12 }}>{new Date(c.expiresAt).toLocaleDateString('en-IN')}</td>
                      <td>
                        <span className={`badge ${expired ? 'badge-gray' : c.isActive ? 'badge-green' : 'badge-amber'}`}>
                          {expired ? 'Expired' : c.isActive ? 'Active' : 'Paused'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => toggle(c)} disabled={expired}>
                          {c.isActive ? 'Pause' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showForm ? (
        <Modal
          title="Create a coupon"
          subtitle="Codes are case-insensitive and validated server-side at checkout."
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" form="coupon-form" type="submit" disabled={saving}>
                {saving ? 'Creating…' : 'Create coupon'}
              </button>
            </>
          }
        >
          <form id="coupon-form" className="form-grid" onSubmit={create} noValidate>
            <Field label="Code" error={errors.code}>
              <input
                className={`input ${errors.code ? 'error' : ''}`}
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="GROVE10"
                maxLength={24}
              />
            </Field>
            <Field label="Discount type">
              <select
                className="select"
                value={form.mode}
                onChange={(e) => setForm({ ...form, mode: e.target.value as 'percent' | 'flat' })}
              >
                <option value="percent">Percentage</option>
                <option value="flat">Flat amount (₹)</option>
              </select>
            </Field>
            <Field label={form.mode === 'percent' ? 'Percent off' : 'Flat off (₹)'} error={errors.value}>
              <input
                className={`input ${errors.value ? 'error' : ''}`}
                inputMode="decimal"
                value={form.value}
                onChange={(e) => setForm({ ...form, value: e.target.value })}
                placeholder={form.mode === 'percent' ? '10' : '50'}
              />
            </Field>
            <Field label="Max discount (₹)" hint="Percentage coupons only">
              <input
                className="input"
                inputMode="decimal"
                value={form.maxDiscount}
                onChange={(e) => setForm({ ...form, maxDiscount: e.target.value })}
                placeholder="50"
              />
            </Field>
            <Field label="Minimum order (₹)">
              <input
                className="input"
                inputMode="decimal"
                value={form.minOrder}
                onChange={(e) => setForm({ ...form, minOrder: e.target.value })}
                placeholder="199"
              />
            </Field>
            <Field label="Usage limit" hint="Leave blank for unlimited">
              <input
                className="input"
                inputMode="numeric"
                value={form.usageLimit}
                onChange={(e) => setForm({ ...form, usageLimit: e.target.value })}
                placeholder="500"
              />
            </Field>
            <Field label="Expires at" error={errors.expiresAt} full>
              <input
                className={`input ${errors.expiresAt ? 'error' : ''}`}
                type="datetime-local"
                value={form.expiresAt}
                onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
              />
            </Field>
            <Field label="Description (shown in the app)" error={errors.description} full>
              <input
                className={`input ${errors.description ? 'error' : ''}`}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="10% off on orders above ₹199"
                maxLength={140}
              />
            </Field>
          </form>
        </Modal>
      ) : null}

      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
