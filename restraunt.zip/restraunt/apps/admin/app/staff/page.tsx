'use client';

import { ShieldCheck, UserPlus } from 'lucide-react';
import { useEffect, useState } from 'react';
import { apiFetch, formatDate, getSession, useApi, useToast, type Session } from '@/lib/api';
import { ErrorState, Field, StatusBadge, TableSkeleton, ToastAlert } from '@/components/ui';

interface StaffRow {
  user_id: string;
  role: string;
  created_at: string;
  profiles: { full_name: string; email: string } | null;
}

interface AuditRow {
  id: string;
  action: string;
  entity: string;
  entity_id: string | null;
  created_at: string;
  profiles: { full_name: string } | null;
}

const ROLE_LABELS: Record<string, string> = {
  owner: 'Owner / Super Admin',
  manager: 'Restaurant Manager',
  kitchen: 'Kitchen Staff',
  delivery: 'Delivery Staff',
};

export default function StaffPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('manager');
  const [saving, setSaving] = useState(false);
  const { toast, show } = useToast();

  useEffect(() => setSession(getSession()), []);

  const staff = useApi<{ data: StaffRow[] }>(session ? '/admin/staff' : null, [session?.token]);
  const audit = useApi<{ data: AuditRow[] }>(session ? '/admin/audit' : null, [session?.token]);

  const grant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session) return;
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) {
      show('Enter a valid staff email address.', 'error');
      return;
    }
    setSaving(true);
    try {
      await apiFetch('/admin/staff', { method: 'POST', body: JSON.stringify({ email: email.trim(), role }) }, session.token);
      show('Role granted. They must sign in again to see new permissions.', 'success');
      setEmail('');
      staff.reload();
      audit.reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not grant that role.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (!session) return null;
  if (session.profile.role !== 'owner') {
    return (
      <div className="page">
        <div className="card">
          <div className="empty">
            <ShieldCheck size={24} color="#DC3545" />
            <div style={{ fontWeight: 700, marginTop: 10 }}>Owner access required</div>
            <div style={{ fontSize: 13, marginTop: 4 }}>
              Only the owner can change staff roles. Permissions are enforced by the API, not just this screen.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="grid grid-2">
        <div className="card">
          <div className="card-head">
            <h2 className="card-title">Grant a staff role</h2>
            <UserPlus size={16} color="#FF7900" />
          </div>
          <form onSubmit={grant} className="form-grid">
            <Field label="Staff email" full hint="They must already have an account from the app">
              <input
                className="input"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="manager@thegrove.in"
              />
            </Field>
            <Field label="Role" full>
              <select className="select" value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="manager">Restaurant Manager</option>
                <option value="kitchen">Kitchen Staff</option>
                <option value="delivery">Delivery Staff</option>
                <option value="owner">Owner / Super Admin</option>
              </select>
            </Field>
            <button className="btn btn-primary full" type="submit" disabled={saving}>
              {saving ? 'Granting…' : 'Grant role'}
            </button>
          </form>
          <div className="hint" style={{ marginTop: 12 }}>
            Roles are enforced on every API route and in database policies. Hiding a button is never treated as
            security.
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <h2 className="card-title">Current staff</h2>
          </div>
          {staff.loading ? (
            <TableSkeleton rows={4} />
          ) : staff.error ? (
            <ErrorState message={staff.error} onRetry={staff.reload} />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Since</th>
                  </tr>
                </thead>
                <tbody>
                  {(staff.data?.data ?? []).map((s) => (
                    <tr key={s.user_id}>
                      <td>
                        <strong>{s.profiles?.full_name ?? '—'}</strong>
                        <div style={{ fontSize: 11, color: '#737373' }}>{s.profiles?.email}</div>
                      </td>
                      <td>{ROLE_LABELS[s.role] ?? s.role}</td>
                      <td style={{ fontSize: 12 }}>{new Date(s.created_at).toLocaleDateString('en-IN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h2 className="card-title">Audit log</h2>
          <span className="badge badge-gray">Last 100 changes</span>
        </div>
        {audit.loading ? (
          <TableSkeleton rows={5} />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Action</th>
                  <th>Entity</th>
                  <th>By</th>
                  <th>When</th>
                </tr>
              </thead>
              <tbody>
                {(audit.data?.data ?? []).map((row) => (
                  <tr key={row.id}>
                    <td>
                      <StatusBadge status={row.action.includes('cancel') ? 'cancelled' : 'confirmed'} />
                      <span style={{ marginLeft: 8, fontSize: 12 }}>{row.action}</span>
                    </td>
                    <td style={{ fontSize: 12 }}>
                      {row.entity}
                      {row.entity_id ? ` • ${row.entity_id.slice(0, 8)}…` : ''}
                    </td>
                    <td style={{ fontSize: 12 }}>{row.profiles?.full_name ?? 'system'}</td>
                    <td style={{ fontSize: 12 }}>{formatDate(row.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
