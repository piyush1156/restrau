'use client';

import { Download } from 'lucide-react';
import { useEffect, useState } from 'react';
import { API_BASE, formatMoney, getSession, useApi, useToast, type Session } from '@/lib/api';
import { EmptyState, ErrorState, Spinner, StatCard, ToastAlert } from '@/components/ui';

interface Report {
  range: { from: string; to: string };
  totals: { orders: number; paidOrders: number; revenueMinor: number; avgOrderValueMinor: number };
  daily: { date: string; orders: number; revenueMinor: number }[];
  byType: { type: string; count: number }[];
  topItems: { name: string; quantity: number; revenueMinor: number }[];
}

const iso = (d: Date) => d.toISOString().slice(0, 10);

export default function ReportsPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [from, setFrom] = useState(iso(new Date(Date.now() - 29 * 86400000)));
  const [to, setTo] = useState(iso(new Date()));
  const [exporting, setExporting] = useState(false);
  const { toast, show } = useToast();

  useEffect(() => setSession(getSession()), []);

  const { data, loading, error, reload } = useApi<Report>(
    session ? `/admin/reports?from=${from}&to=${to}` : null,
    [from, to, session?.token],
  );

  const exportCsv = async () => {
    if (!session) return;
    setExporting(true);
    try {
      const res = await fetch(`${API_BASE}/admin/reports/export.csv?from=${from}&to=${to}`, {
        headers: { Authorization: `Bearer ${session.token}` },
      });
      if (!res.ok) throw new Error('Export failed. Check your permissions and try again.');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `grove-orders-${from}-to-${to}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      show('CSV exported', 'success');
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not export the report.', 'error');
    } finally {
      setExporting(false);
    }
  };

  if (!session) return null;

  return (
    <div className="page">
      <div className="card">
        <div className="toolbar">
          <div className="field">
            <label htmlFor="from">From</label>
            <input id="from" className="input" type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="to">To</label>
            <input id="to" className="input" type="date" value={to} min={from} max={iso(new Date())} onChange={(e) => setTo(e.target.value)} />
          </div>
          <button className="btn btn-ghost btn-sm" onClick={reload} style={{ marginTop: 18 }}>
            Refresh
          </button>
          <button className="btn btn-primary btn-sm" onClick={exportCsv} disabled={exporting} style={{ marginTop: 18, marginLeft: 'auto' }}>
            <Download size={15} />
            {exporting ? 'Exporting…' : 'Export CSV'}
          </button>
        </div>
        <div className="hint" style={{ marginTop: 10 }}>
          Revenue counts paid orders only and excludes cancelled orders. Times are restaurant-local (IST).
        </div>
      </div>

      {loading ? (
        <div className="card">
          <Spinner label="Building report…" />
        </div>
      ) : error ? (
        <div className="card">
          <ErrorState message={error} onRetry={reload} />
        </div>
      ) : data ? (
        <>
          <div className="grid grid-4">
            <StatCard
              label="Orders"
              value={String(data.totals.orders)}
              icon={<span style={{ fontSize: 18 }}>🧾</span>}
              tint="#FEF3C7"
              foot={`${data.totals.paidOrders} paid`}
            />
            <StatCard
              label="Revenue"
              value={formatMoney(data.totals.revenueMinor)}
              icon={<span style={{ fontSize: 18 }}>₹</span>}
              tint="#FFF2E6"
              foot="Paid orders incl. fees"
            />
            <StatCard
              label="Avg order"
              value={formatMoney(data.totals.avgOrderValueMinor)}
              icon={<span style={{ fontSize: 18 }}>📈</span>}
              tint="#E8F5EE"
              foot="Paid orders only"
            />
            <StatCard
              label="Days in range"
              value={String(data.daily.length)}
              icon={<span style={{ fontSize: 18 }}>🗓️</span>}
              tint="#EAF2FE"
              foot={`${from} → ${to}`}
            />
          </div>

          <div className="grid grid-3">
            <div className="card span-2">
              <div className="card-head">
                <h2 className="card-title">Daily breakdown</h2>
              </div>
              {data.daily.length === 0 ? (
                <EmptyState title="No orders in this range" subtitle="Try a wider date range." />
              ) : (
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Orders</th>
                        <th style={{ textAlign: 'right' }}>Revenue</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.daily.map((d) => (
                        <tr key={d.date}>
                          <td>{new Date(`${d.date}T12:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                          <td>{d.orders}</td>
                          <td style={{ textAlign: 'right', fontWeight: 600 }}>{formatMoney(d.revenueMinor)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="card">
              <div className="card-head">
                <h2 className="card-title">Top dishes</h2>
              </div>
              {data.topItems.length === 0 ? (
                <div className="hint">No item data yet.</div>
              ) : (
                <div style={{ display: 'grid', gap: 12 }}>
                  {data.topItems.slice(0, 6).map((item) => (
                    <div key={item.name}>
                      <div className="row-between" style={{ fontSize: 12 }}>
                        <span>{item.name}</span>
                        <strong>{formatMoney(item.revenueMinor)}</strong>
                      </div>
                      <div className="hint">{item.quantity} sold</div>
                    </div>
                  ))}
                </div>
              )}
              <div className="divider" />
              <div className="card-title" style={{ fontSize: 13, marginBottom: 8 }}>
                Fulfilment mix
              </div>
              {data.byType.map((t) => (
                <div key={t.type} className="row-between" style={{ fontSize: 12, marginBottom: 6 }}>
                  <span style={{ textTransform: 'capitalize' }}>{t.type.replace(/_/g, ' ')}</span>
                  <strong>{t.count}</strong>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}

      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
