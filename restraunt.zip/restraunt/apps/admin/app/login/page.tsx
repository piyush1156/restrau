'use client';

import { ChefHat, Eye, EyeOff, Lock, Mail } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { apiFetch, getSession, setSession, type AdminProfile } from '@/lib/api';

const STAFF_ROLES = ['owner', 'manager', 'kitchen', 'delivery'];

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const existing = getSession();
    if (existing) router.replace('/');
  }, [router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await apiFetch<{ profile: AdminProfile; token: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier: identifier.trim(), password }),
      });

      if (!STAFF_ROLES.includes(res.profile.role)) {
        setError('This account does not have staff access. Ask the owner to grant a role.');
        return;
      }
      setSession({ token: res.token, profile: res.profile });
      router.replace('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not sign in.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={submit} noValidate>
        <div className="row">
          <div className="brand-mark" style={{ width: 44, height: 44, borderRadius: 14 }}>
            <ChefHat size={22} />
          </div>
          <div>
            <div className="brand-name">The Grove</div>
            <div className="brand-sub">RESTAURANT &amp; CAFE</div>
          </div>
        </div>

        <h1>Staff sign in</h1>
        <p>Restaurant dashboard for orders, menu and reservations.</p>

        {error ? (
          <div
            className="badge badge-red"
            style={{ display: 'block', padding: '10px 12px', marginBottom: 14, borderRadius: 12, lineHeight: 1.4 }}
            role="alert"
          >
            {error}
          </div>
        ) : null}

        <div className="field" style={{ marginBottom: 14 }}>
          <label htmlFor="identifier">Email or phone</label>
          <div className="search" style={{ minWidth: 0 }}>
            <Mail size={16} color="#737373" />
            <input
              id="identifier"
              type="text"
              autoComplete="username"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="owner@thegrove.in"
              required
            />
          </div>
        </div>

        <div className="field" style={{ marginBottom: 20 }}>
          <label htmlFor="password">Password</label>
          <div className="row" style={{ position: 'relative' }}>
            <Lock size={16} color="#737373" style={{ position: 'absolute', left: 14 }} />
            <input
              id="password"
              className="input"
              style={{ paddingLeft: 38, paddingRight: 42 }}
              type={show ? 'text' : 'password'}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              style={{ position: 'absolute', right: 4, border: 'none', background: 'transparent' }}
              onClick={() => setShow((s) => !s)}
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <button className="btn btn-primary" type="submit" disabled={busy} style={{ width: '100%' }}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>

        <p style={{ marginTop: 16, fontSize: 11, textAlign: 'center' }}>
          Access is limited to staff roles. Customers should use the mobile app.
        </p>
      </form>
    </div>
  );
}
