'use client';

import { RefreshCw, Search, XCircle } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import {
  apiFetch,
  formatDate,
  formatMoney,
  getSession,
  useApi,
  useToast,
  type Session,
} from '@/lib/api';
import { EmptyState, ErrorState, Modal, StatusBadge, TableSkeleton, ToastAlert } from '@/components/ui';

interface OrderRow {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  type: 'delivery' | 'takeaway' | 'dine_in';
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  totals: { grandTotalMinor: number };
  createdAt: string;
  deliveryInstructions?: string | null;
  items: { id: string; name: string; quantity: number; unitPriceMinor: number }[];
}

const FILTERS = [
  { key: 'active', label: 'Active' },
  { key: 'pending', label: 'Pending' },
  { key: 'preparing', label: 'Preparing' },
  { key: 'out_for_delivery', label: 'On the way' },
  { key: 'delivered', label: 'Delivered' },
  { key: 'cancelled', label: 'Cancelled' },
  { key: 'all', label: 'All' },
];

const NEXT_ACTIONS: Record<string, { status: string; label: string }[]> = {
  pending: [
    { status: 'confirmed', label: 'Confirm' },
    { status: 'cancelled', label: 'Cancel' },
  ],
  confirmed: [
    { status: 'preparing', label: 'Start cooking' },
    { status: 'cancelled', label: 'Cancel' },
  ],
  preparing: [
    { status: 'ready', label: 'Mark ready' },
    { status: 'cancelled', label: 'Cancel' },
  ],
  ready: [
    { status: 'out_for_delivery', label: 'Out for delivery' },
    { status: 'delivered', label: 'Complete' },
  ],
  out_for_delivery: [{ status: 'delivered', label: 'Delivered' }],
};

const ROLE_ALLOWED: Record<string, string[]> = {
  owner: ['confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'],
  manager: ['confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'],
  kitchen: ['confirmed', 'preparing', 'ready'],
  delivery: ['out_for_delivery', 'delivered'],
};

export default function OrdersPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [filter, setFilter] = useState('active');
  const [query, setQuery] = useState('');
  const [cancelTarget, setCancelTarget] = useState<OrderRow | null>(null);
  const [reason, setReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const { toast, show } = useToast();

  useEffect(() => setSession(getSession()), []);

  const path = session
    ? `/admin/orders?status=${filter}&pageSize=50${query.trim() ? `&q=${encodeURIComponent(query.trim())}` : ''}`
    : null;
  const { data, loading, error, reload } = useApi<{ data: OrderRow[]; total: number }>(path, [filter, query, session?.token]);

  const orders = useMemo(() => data?.data ?? [], [data]);
  const role = session?.profile.role ?? 'delivery';

  const setStatus = async (order: OrderRow, status: string, cancelReason?: string) => {
    if (!session) return;
    setBusyId(order.id);
    try {
      await apiFetch(
        `/admin/orders/${order.id}/status`,
        { method: 'PATCH', body: JSON.stringify({ status, ...(cancelReason ? { cancelReason } : {}) }) },
        session.token,
      );
      show(`Order #${order.orderNumber} → ${status.replace(/_/g, ' ')}`, 'success');
      reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not update the order.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const confirmCancel = async () => {
    if (!cancelTarget) return;
    if (reason.trim().length < 4) {
      show('Please give a short cancellation reason.', 'error');
      return;
    }
    await setStatus(cancelTarget, 'cancelled', reason.trim());
    setCancelTarget(null);
    setReason('');
  };

  return (
    <div className="page">
      <div className="card">
        <div className="toolbar">
          <div className="search">
            <Search size={15} color="#737373" />
            <input
              placeholder="Search order number or phone"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search orders"
            />
          </div>
          <div className="row wrap" style={{ gap: 6 }}>
            {FILTERS.map((f) => (
              <button
                key={f.key}
                className={`btn btn-sm ${filter === f.key ? 'btn-primary' : 'btn-ghost'}`}
                onClick={() => setFilter(f.key)}
              >
                {f.label}
              </button>
            ))}
          </div>
          <button className="btn btn-ghost btn-sm" onClick={reload} style={{ marginLeft: 'auto' }}>
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>
        <div className="hint" style={{ marginTop: 10 }}>
          {orders.length} order{orders.length === 1 ? '' : 's'} shown • data refreshes when you reload
          {role === 'kitchen' ? ' • kitchen role can update cooking statuses only' : ''}
        </div>
      </div>

      <div className="card">
        {loading ? (
          <TableSkeleton rows={6} />
        ) : error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : orders.length === 0 ? (
          <EmptyState
            title="No orders in this view"
            subtitle="Try another filter, or wait for the next order to arrive."
            action={
              <button className="btn btn-ghost btn-sm" onClick={() => setFilter('all')}>
                Show all orders
              </button>
            }
          />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Items</th>
                  <th>Placed</th>
                  <th>Status</th>
                  <th>Payment</th>
                  <th style={{ textAlign: 'right' }}>Total</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => {
                  const actions = (NEXT_ACTIONS[order.status] ?? []).filter((a) =>
                    (ROLE_ALLOWED[role] ?? []).includes(a.status),
                  );
                  return (
                    <tr key={order.id} className="row-hover">
                      <td>
                        <strong>#{order.orderNumber}</strong>
                        <div style={{ fontSize: 11, color: '#737373', textTransform: 'capitalize' }}>
                          {order.type.replace(/_/g, ' ')}
                        </div>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{order.customerName}</div>
                        <div style={{ fontSize: 11, color: '#737373' }}>{order.customerPhone}</div>
                      </td>
                      <td style={{ maxWidth: 220 }}>
                        <div style={{ fontSize: 12 }}>
                          {order.items.slice(0, 3).map((i) => `${i.quantity}× ${i.name}`).join(', ')}
                          {order.items.length > 3 ? ` +${order.items.length - 3} more` : ''}
                        </div>
                        {order.deliveryInstructions ? (
                          <div style={{ fontSize: 11, color: '#B45309', marginTop: 2 }}>
                            “{order.deliveryInstructions}”
                          </div>
                        ) : null}
                      </td>
                      <td style={{ whiteSpace: 'nowrap', fontSize: 12 }}>{formatDate(order.createdAt)}</td>
                      <td>
                        <StatusBadge status={order.status} />
                      </td>
                      <td>
                        <StatusBadge status={order.paymentStatus} />
                        <div style={{ fontSize: 10, color: '#737373', marginTop: 3 }}>
                          {order.paymentMethod === 'cod' ? 'COD' : 'Razorpay'}
                        </div>
                      </td>
                      <td style={{ textAlign: 'right', fontWeight: 700 }}>
                        {formatMoney(order.totals.grandTotalMinor)}
                      </td>
                      <td>
                        <div className="row wrap" style={{ gap: 6 }}>
                          {actions.map((action) => (
                            <button
                              key={action.status}
                              className={`btn btn-sm ${action.status === 'cancelled' ? 'btn-danger' : 'btn-soft'}`}
                              disabled={busyId === order.id}
                              onClick={() =>
                                action.status === 'cancelled' ? setCancelTarget(order) : setStatus(order, action.status)
                              }
                            >
                              {action.label}
                            </button>
                          ))}
                          {actions.length === 0 ? (
                            <span style={{ fontSize: 11, color: '#A3A3A3' }}>
                              {order.status === 'delivered' || order.status === 'cancelled'
                                ? 'No actions'
                                : 'Awaiting another role'}
                            </span>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {cancelTarget ? (
        <Modal
          title={`Cancel order #${cancelTarget.orderNumber}`}
          subtitle="The customer is notified immediately. Paid orders are queued for refund."
          onClose={() => setCancelTarget(null)}
          footer={
            <>
              <button className="btn btn-ghost" onClick={() => setCancelTarget(null)}>
                Keep order
              </button>
              <button className="btn btn-danger" onClick={confirmCancel} disabled={busyId === cancelTarget.id}>
                <XCircle size={15} />
                Cancel order
              </button>
            </>
          }
        >
          <div className="field">
            <label htmlFor="reason">Reason (shown to the customer)</label>
            <textarea
              id="reason"
              className="textarea"
              value={reason}
              onChange={(e) => setReason(e.target.value.slice(0, 200))}
              placeholder="e.g. One dish is sold out — we’ve refunded the order."
            />
            <span className="hint">{reason.length}/200</span>
          </div>
        </Modal>
      ) : null}

      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
