'use client';

import { ChefHat, ClipboardList, IndianRupee, TrendingUp, XCircle } from 'lucide-react';
import Link from 'next/link';
import { useApi, formatMoney, formatDate, type Session } from '@/lib/api';
import { getSession } from '@/lib/api';
import { DonutChart, ErrorState, RevenueChart, Spinner, StatCard, StatusBadge } from '@/components/ui';
import { useEffect, useState } from 'react';

interface DashboardResponse {
  stats: {
    totalOrders: number;
    todayOrders: number;
    todayRevenueMinor: number;
    pendingOrders: number;
    preparingOrders: number;
    completedOrders: number;
    cancelledOrders: number;
    avgOrderValueMinor: number;
  };
  revenue: { label: string; orders: number; revenueMinor: number }[];
  popularDishes: { name: string; quantity: number }[];
  recentOrders: {
    id: string;
    orderNumber: string;
    status: string;
    type: string;
    paymentStatus: string;
    totals: { grandTotalMinor: number };
    createdAt: string;
    items: { name: string; quantity: number }[];
  }[];
}

export default function DashboardPage() {
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => setSession(getSession()), []);

  const { data, loading, error, reload } = useApi<DashboardResponse>(session ? '/admin/dashboard' : null, [session?.token]);

  if (!session) return null;

  return (
    <div className="page">
      {loading ? (
        <div className="card">
          <Spinner label="Loading today’s numbers…" />
        </div>
      ) : error ? (
        <div className="card">
          <ErrorState message={error} onRetry={reload} />
        </div>
      ) : data ? (
        <>
          <div className="grid grid-4">
            <StatCard
              label="Total orders (30d)"
              value={String(data.stats.totalOrders)}
              foot={`${data.stats.todayOrders} today`}
              icon={<ClipboardList size={20} color="#B45309" />}
              tint="#FEF3C7"
            />
            <StatCard
              label="Today’s revenue"
              value={formatMoney(data.stats.todayRevenueMinor)}
              foot="Paid orders only"
              icon={<IndianRupee size={20} color="#FF7900" />}
              tint="#FFF2E6"
            />
            <StatCard
              label="In the kitchen"
              value={String(data.stats.preparingOrders)}
              foot={`${data.stats.pendingOrders} awaiting confirmation`}
              icon={<ChefHat size={20} color="#198754" />}
              tint="#E8F5EE"
            />
            <StatCard
              label="Avg order value"
              value={formatMoney(data.stats.avgOrderValueMinor)}
              foot={`${data.stats.completedOrders} completed`}
              icon={<TrendingUp size={20} color="#0D6EFD" />}
              tint="#EAF2FE"
            />
          </div>

          <div className="grid grid-3">
            <div className="card span-2">
              <div className="card-head">
                <div>
                  <h2 className="card-title">Revenue — last 7 days</h2>
                  <div style={{ fontSize: 11, color: '#737373', marginTop: 2 }}>Paid orders, GST and fees included</div>
                </div>
                <span className="badge badge-orange">
                  <span className="dot" style={{ background: '#FF7900' }} /> Revenue
                </span>
              </div>
              <RevenueChart data={data.revenue} />
            </div>

            <div className="card">
              <div className="card-head">
                <h2 className="card-title">Order mix</h2>
                <Link href="/orders" className="badge badge-gray">
                  View all
                </Link>
              </div>
              <DonutChart
                centerLabel="orders"
                centerValue={String(data.stats.totalOrders)}
                segments={[
                  { label: 'Completed', value: data.stats.completedOrders, color: '#198754' },
                  { label: 'Preparing', value: data.stats.preparingOrders, color: '#FF7900' },
                  { label: 'Pending', value: data.stats.pendingOrders, color: '#F5B942' },
                  { label: 'Cancelled', value: data.stats.cancelledOrders, color: '#DC3545' },
                ]}
              />
              <div className="divider" />
              <div className="card-title" style={{ fontSize: 13, marginBottom: 10 }}>
                Popular dishes
              </div>
              {data.popularDishes.length === 0 ? (
                <div style={{ fontSize: 12, color: '#737373' }}>No dish data yet.</div>
              ) : (
                <div style={{ display: 'grid', gap: 10 }}>
                  {data.popularDishes.map((dish) => {
                    const max = data.popularDishes[0]?.quantity || 1;
                    return (
                      <div key={dish.name}>
                        <div className="row-between" style={{ fontSize: 12, marginBottom: 4 }}>
                          <span>{dish.name}</span>
                          <strong>{dish.quantity}</strong>
                        </div>
                        <div style={{ height: 6, background: '#F1F1F1', borderRadius: 999 }}>
                          <div
                            style={{
                              width: `${Math.max(8, (dish.quantity / max) * 100)}%`,
                              height: 6,
                              borderRadius: 999,
                              background: '#FF7900',
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="card">
            <div className="card-head">
              <h2 className="card-title">Recent orders</h2>
              <Link href="/orders" className="badge badge-orange">
                Open order queue
              </Link>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Order</th>
                    <th>Type</th>
                    <th>Items</th>
                    <th>Placed</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th style={{ textAlign: 'right' }}>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentOrders.length === 0 ? (
                    <tr>
                      <td colSpan={7}>
                        <div className="empty">No orders yet. New orders appear here in real time.</div>
                      </td>
                    </tr>
                  ) : (
                    data.recentOrders.map((order) => (
                      <tr key={order.id} className="row-hover">
                        <td>
                          <strong>#{order.orderNumber}</strong>
                        </td>
                        <td style={{ textTransform: 'capitalize' }}>{order.type.replace(/_/g, ' ')}</td>
                        <td style={{ color: '#737373' }}>
                          {order.items
                            .slice(0, 2)
                            .map((i) => `${i.quantity}× ${i.name}`)
                            .join(', ')}
                          {order.items.length > 2 ? ` +${order.items.length - 2}` : ''}
                        </td>
                        <td style={{ whiteSpace: 'nowrap' }}>{formatDate(order.createdAt)}</td>
                        <td>
                          <StatusBadge status={order.status} />
                        </td>
                        <td>
                          <StatusBadge status={order.paymentStatus} />
                        </td>
                        <td style={{ textAlign: 'right', fontWeight: 700 }}>
                          {formatMoney(order.totals.grandTotalMinor)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {data.stats.cancelledOrders > 0 ? (
            <div className="card" style={{ background: '#FDECEE', borderColor: '#F6C6CB' }}>
              <div className="row">
                <XCircle size={18} color="#DC3545" />
                <div style={{ fontSize: 13 }}>
                  <strong>{data.stats.cancelledOrders} cancelled orders</strong> in the last 30 days. Review reasons in the
                  order queue to spot kitchen or delivery issues.
                </div>
              </div>
            </div>
          ) : null}
        </>
      ) : null}
    </div>
  );
}
