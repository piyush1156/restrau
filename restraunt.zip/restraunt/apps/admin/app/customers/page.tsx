'use client';

import { Search } from 'lucide-react';
import { useEffect, useState } from 'react';
import { getSession, useApi, type Session } from '@/lib/api';
import { EmptyState, ErrorState, TableSkeleton } from '@/components/ui';

interface Customer {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  created_at: string;
}

export default function CustomersPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [query, setQuery] = useState('');
  useEffect(() => setSession(getSession()), []);

  const { data, loading, error, reload } = useApi<{ data: Customer[] }>(
    session ? `/admin/customers${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ''}` : null,
    [query, session?.token],
  );

  if (!session) return null;

  return (
    <div className="page">
      <div className="card">
        <div className="toolbar">
          <div className="search">
            <Search size={15} color="#737373" />
            <input
              placeholder="Search name, email or phone"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search customers"
            />
          </div>
          <span className="hint">Only fields needed for support are shown — addresses and payment data stay private.</span>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <TableSkeleton rows={6} />
        ) : error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (data?.data.length ?? 0) === 0 ? (
          <EmptyState title="No customers found" subtitle="Try a different search term." />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Joined</th>
                </tr>
              </thead>
              <tbody>
                {data!.data.map((c) => (
                  <tr key={c.id} className="row-hover">
                    <td>
                      <div className="row">
                        <div className="avatar" style={{ width: 30, height: 30, fontSize: 12 }}>
                          {c.full_name.charAt(0).toUpperCase()}
                        </div>
                        <strong>{c.full_name}</strong>
                      </div>
                    </td>
                    <td>{c.email}</td>
                    <td>{c.phone ?? '—'}</td>
                    <td>{new Date(c.created_at).toLocaleDateString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
