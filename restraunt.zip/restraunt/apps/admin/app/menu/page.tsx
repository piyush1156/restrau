'use client';

import { ImageOff, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { apiFetch, formatMoney, getSession, useApi, useToast, type Session } from '@/lib/api';
import { EmptyState, ErrorState, Field, Modal, TableSkeleton, ToastAlert } from '@/components/ui';

interface MenuRow {
  id: string;
  category_id: string;
  name: string;
  description: string;
  price_minor: number;
  discounted_price_minor: number | null;
  image_url: string;
  is_veg: boolean;
  is_available: boolean;
  is_special: boolean;
  ingredients: string[] | null;
  allergens: string[] | null;
  rating: string | number;
  review_count: number;
}

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface FormState {
  name: string;
  categoryId: string;
  description: string;
  price: string;
  discounted: string;
  imageUrl: string;
  isVeg: boolean;
  isAvailable: boolean;
  isSpecial: boolean;
  ingredients: string;
  allergens: string;
}

const emptyForm = (categoryId: string): FormState => ({
  name: '',
  categoryId,
  description: '',
  price: '',
  discounted: '',
  imageUrl: '',
  isVeg: true,
  isAvailable: true,
  isSpecial: false,
  ingredients: '',
  allergens: '',
});

export default function MenuPage() {
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => setSession(getSession()), []);

  const menu = useApi<{ data: MenuRow[] }>(session ? '/admin/menu' : null, [session?.token]);
  const categories = useApi<{ data: Category[] }>(session ? '/menu/categories' : null, [session?.token]);

  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<MenuRow | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm(''));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<MenuRow | null>(null);
  const { toast, show } = useToast();

  const role = session?.profile.role ?? 'kitchen';
  const canEdit = role === 'owner' || role === 'manager';

  const rows = useMemo(() => {
    const list = menu.data?.data ?? [];
    const q = query.trim().toLowerCase();
    return q ? list.filter((m) => m.name.toLowerCase().includes(q)) : list;
  }, [menu.data, query]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm(categories.data?.data[0]?.id ?? ''));
    setErrors({});
    setShowForm(true);
  };

  const openEdit = (row: MenuRow) => {
    setEditing(row);
    setForm({
      name: row.name,
      categoryId: row.category_id,
      description: row.description,
      price: String(row.price_minor / 100),
      discounted: row.discounted_price_minor ? String(row.discounted_price_minor / 100) : '',
      imageUrl: row.image_url,
      isVeg: row.is_veg,
      isAvailable: row.is_available,
      isSpecial: row.is_special,
      ingredients: (row.ingredients ?? []).join(', '),
      allergens: (row.allergens ?? []).join(', '),
    });
    setErrors({});
    setShowForm(true);
  };

  const validate = (): boolean => {
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = 'Enter a dish name';
    if (!form.categoryId) next.categoryId = 'Pick a category';
    if (form.description.trim().length < 5) next.description = 'Add a short description';
    const price = Math.round(Number(form.price) * 100);
    if (!Number.isFinite(price) || price < 100) next.price = 'Price must be at least ₹1';
    if (form.discounted) {
      const d = Math.round(Number(form.discounted) * 100);
      if (!Number.isFinite(d) || d < 100) next.discounted = 'Enter a valid discounted price';
      else if (d >= price) next.discounted = 'Discounted price must be lower than the price';
    }
    if (!/^https?:\/\//.test(form.imageUrl.trim())) next.imageUrl = 'Use a public https image URL';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session || !validate()) return;
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      categoryId: form.categoryId,
      description: form.description.trim(),
      priceMinor: Math.round(Number(form.price) * 100),
      discountedPriceMinor: form.discounted ? Math.round(Number(form.discounted) * 100) : null,
      imageUrl: form.imageUrl.trim(),
      isVeg: form.isVeg,
      isAvailable: form.isAvailable,
      isSpecial: form.isSpecial,
      ingredients: form.ingredients
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 30),
      allergens: form.allergens
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 30),
    };

    try {
      if (editing) {
        await apiFetch(`/admin/menu/${editing.id}`, { method: 'PATCH', body: JSON.stringify(payload) }, session.token);
        show('Dish updated', 'success');
      } else {
        await apiFetch('/admin/menu', { method: 'POST', body: JSON.stringify(payload) }, session.token);
        show('Dish added to the menu', 'success');
      }
      setShowForm(false);
      menu.reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not save this dish.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const toggleAvailability = async (row: MenuRow) => {
    if (!session) return;
    try {
      await apiFetch(
        `/admin/menu/${row.id}/availability`,
        { method: 'PATCH', body: JSON.stringify({ isAvailable: !row.is_available }) },
        session.token,
      );
      show(`${row.name} is now ${row.is_available ? 'sold out' : 'available'}`, 'success');
      menu.reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not update availability.', 'error');
    }
  };

  const remove = async () => {
    if (!session || !deleteTarget) return;
    try {
      await apiFetch(`/admin/menu/${deleteTarget.id}`, { method: 'DELETE' }, session.token);
      show(`${deleteTarget.name} hidden from the menu`, 'success');
      setDeleteTarget(null);
      menu.reload();
    } catch (err) {
      show(err instanceof Error ? err.message : 'Could not remove this dish.', 'error');
    }
  };

  if (!session) return null;

  return (
    <div className="page">
      <div className="card">
        <div className="toolbar">
          <div className="search">
            <Search size={15} color="#737373" />
            <input
              placeholder="Search dishes"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search menu"
            />
          </div>
          <span className="hint">{rows.length} dishes</span>
          <div style={{ marginLeft: 'auto' }} className="row">
            <button className="btn btn-ghost btn-sm" onClick={menu.reload}>
              Refresh
            </button>
            {canEdit ? (
              <button className="btn btn-primary btn-sm" onClick={openCreate}>
                <Plus size={15} />
                Add dish
              </button>
            ) : null}
          </div>
        </div>
      </div>

      <div className="card">
        {menu.loading ? (
          <TableSkeleton rows={7} />
        ) : menu.error ? (
          <ErrorState message={menu.error} onRetry={menu.reload} />
        ) : rows.length === 0 ? (
          <EmptyState
            title="No dishes found"
            subtitle={query ? 'Try a different search.' : 'Add your first dish to start taking orders.'}
            action={
              canEdit ? (
                <button className="btn btn-primary btn-sm" onClick={openCreate}>
                  <Plus size={15} /> Add dish
                </button>
              ) : undefined
            }
          />
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Dish</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Rating</th>
                  <th>Availability</th>
                  <th>Tags</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => {
                  const category = categories.data?.data.find((c) => c.id === row.category_id);
                  return (
                    <tr key={row.id} className="row-hover">
                      <td>
                        <div className="row">
                          {row.image_url ? (
                            <img
                              src={row.image_url}
                              alt=""
                              width={44}
                              height={44}
                              style={{ borderRadius: 10, objectFit: 'cover', background: '#F1F1F1' }}
                            />
                          ) : (
                            <div
                              style={{
                                width: 44,
                                height: 44,
                                borderRadius: 10,
                                background: '#F1F1F1',
                                display: 'grid',
                                placeItems: 'center',
                              }}
                            >
                              <ImageOff size={16} color="#A3A3A3" />
                            </div>
                          )}
                          <div style={{ minWidth: 0 }}>
                            <div style={{ fontWeight: 700 }}>{row.name}</div>
                            <div
                              style={{
                                fontSize: 11,
                                color: '#737373',
                                maxWidth: 260,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {row.description}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td style={{ fontSize: 12 }}>{category?.name ?? '—'}</td>
                      <td>
                        <div style={{ fontWeight: 700 }}>{formatMoney(row.discounted_price_minor ?? row.price_minor)}</div>
                        {row.discounted_price_minor ? (
                          <div style={{ fontSize: 11, color: '#A3A3A3', textDecoration: 'line-through' }}>
                            {formatMoney(row.price_minor)}
                          </div>
                        ) : null}
                      </td>
                      <td style={{ fontSize: 12 }}>
                        ★ {Number(row.rating).toFixed(1)}
                        <div style={{ color: '#A3A3A3', fontSize: 10 }}>{row.review_count} reviews</div>
                      </td>
                      <td>
                        <button
                          className={`badge ${row.is_available ? 'badge-green' : 'badge-red'}`}
                          style={{ border: 'none', cursor: 'pointer' }}
                          onClick={() => toggleAvailability(row)}
                          aria-label={`Toggle availability for ${row.name}`}
                        >
                          {row.is_available ? 'Available' : 'Sold out'}
                        </button>
                      </td>
                      <td>
                        <div className="row wrap" style={{ gap: 4 }}>
                          <span className={`badge ${row.is_veg ? 'badge-green' : 'badge-red'}`}>
                            {row.is_veg ? 'Veg' : 'Non-veg'}
                          </span>
                          {row.is_special ? <span className="badge badge-orange">Special</span> : null}
                        </div>
                      </td>
                      <td>
                        <div className="row" style={{ justifyContent: 'flex-end', gap: 6 }}>
                          {canEdit ? (
                            <>
                              <button className="btn btn-ghost btn-sm" onClick={() => openEdit(row)} aria-label={`Edit ${row.name}`}>
                                <Pencil size={14} />
                              </button>
                              <button
                                className="btn btn-danger btn-sm"
                                onClick={() => setDeleteTarget(row)}
                                aria-label={`Hide ${row.name}`}
                              >
                                <Trash2 size={14} />
                              </button>
                            </>
                          ) : (
                            <span className="hint">View only</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showForm ? (
        <Modal
          title={editing ? `Edit ${editing.name}` : 'Add a dish'}
          subtitle="Prices are stored as integer paise; the form takes rupees."
          onClose={() => setShowForm(false)}
          footer={
            <>
              <button className="btn btn-ghost" type="button" onClick={() => setShowForm(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" type="submit" form="menu-form" disabled={saving}>
                {saving ? 'Saving…' : editing ? 'Save changes' : 'Add dish'}
              </button>
            </>
          }
        >
          <form id="menu-form" onSubmit={save} className="form-grid" noValidate>
            <Field label="Dish name" error={errors.name} full>
              <input
                className={`input ${errors.name ? 'error' : ''}`}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                maxLength={80}
              />
            </Field>
            <Field label="Category" error={errors.categoryId}>
              <select
                className="select"
                value={form.categoryId}
                onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
              >
                {(categories.data?.data ?? []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Price (₹)" error={errors.price}>
              <input
                className={`input ${errors.price ? 'error' : ''}`}
                inputMode="decimal"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="249"
              />
            </Field>
            <Field label="Discounted price (₹)" hint="Optional — must be lower" error={errors.discounted}>
              <input
                className={`input ${errors.discounted ? 'error' : ''}`}
                inputMode="decimal"
                value={form.discounted}
                onChange={(e) => setForm({ ...form, discounted: e.target.value })}
                placeholder="269"
              />
            </Field>
            <Field label="Image URL" error={errors.imageUrl} hint="Use Supabase Storage or Unsplash URL">
              <input
                className={`input ${errors.imageUrl ? 'error' : ''}`}
                value={form.imageUrl}
                onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                placeholder="https://…"
              />
            </Field>
            <Field label="Description" error={errors.description} full>
              <textarea
                className={`textarea ${errors.description ? 'error' : ''}`}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                maxLength={400}
              />
            </Field>
            <Field label="Ingredients (comma separated)" full>
              <input
                className="input"
                value={form.ingredients}
                onChange={(e) => setForm({ ...form, ingredients: e.target.value })}
                placeholder="Paneer, Yogurt, Capsicum"
              />
            </Field>
            <Field label="Allergens (comma separated)" hint="Shown to customers before ordering" full>
              <input
                className="input"
                value={form.allergens}
                onChange={(e) => setForm({ ...form, allergens: e.target.value })}
                placeholder="Dairy, Nuts"
              />
            </Field>
            <div className="row wrap full" style={{ gap: 16 }}>
              {(
                [
                  ['isVeg', 'Vegetarian'],
                  ['isAvailable', 'Available'],
                  ['isSpecial', "Today's special"],
                ] as const
              ).map(([key, label]) => (
                <label key={key} className="row" style={{ gap: 6, fontSize: 13 }}>
                  <input
                    type="checkbox"
                    checked={form[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.checked })}
                  />
                  {label}
                </label>
              ))}
            </div>
          </form>
        </Modal>
      ) : null}

      {deleteTarget ? (
        <Modal
          title={`Hide ${deleteTarget.name}?`}
          subtitle="The dish disappears from the app, but past order history keeps its snapshot."
          onClose={() => setDeleteTarget(null)}
          footer={
            <>
              <button className="btn btn-ghost" onClick={() => setDeleteTarget(null)}>
                Keep dish
              </button>
              <button className="btn btn-danger" onClick={remove}>
                <Trash2 size={15} />
                Hide dish
              </button>
            </>
          }
        >
          <p style={{ fontSize: 13, color: '#525252', margin: 0 }}>
            Customers with this dish in their cart are told it is unavailable at checkout — they are never charged for it.
          </p>
        </Modal>
      ) : null}

      {toast ? <ToastAlert message={toast.message} type={toast.type} /> : null}
    </div>
  );
}
