'use client';

import { ArrowDownRight, ArrowUpRight, Inbox, Loader2, X } from 'lucide-react';
import { useEffect } from 'react';

/* ------------------------------------------------------------------ badges */

const ORDER_STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: 'Pending', cls: 'badge-amber' },
  confirmed: { label: 'Confirmed', cls: 'badge-orange' },
  preparing: { label: 'Preparing', cls: 'badge-orange' },
  ready: { label: 'Ready', cls: 'badge-orange' },
  out_for_delivery: { label: 'On the way', cls: 'badge-orange' },
  delivered: { label: 'Delivered', cls: 'badge-green' },
  completed: { label: 'Completed', cls: 'badge-green' },
  cancelled: { label: 'Cancelled', cls: 'badge-red' },
  rejected: { label: 'Rejected', cls: 'badge-red' },
  paid: { label: 'Paid', cls: 'badge-green' },
  created: { label: 'Payment initiated', cls: 'badge-amber' },
  failed: { label: 'Failed', cls: 'badge-red' },
  refunded: { label: 'Refunded', cls: 'badge-gray' },
};

export const StatusBadge = ({ status }: { status: string }) => {
  const meta = ORDER_STATUS[status] ?? { label: status.replace(/_/g, ' '), cls: 'badge-gray' };
  return <span className={`badge ${meta.cls}`}>{meta.label}</span>;
};

/* ------------------------------------------------------------------- stats */

export const StatCard = ({
  label,
  value,
  icon,
  tint,
  foot,
  trend,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  tint: string;
  foot?: string;
  trend?: number;
}) => (
  <div className="stat" style={{ background: tint }}>
    <div className="stat-icon">{icon}</div>
    <div style={{ minWidth: 0 }}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {foot ? <div className="stat-foot">{foot}</div> : null}
    </div>
    {trend !== undefined ? (
      <span
        className="badge"
        style={{
          marginLeft: 'auto',
          background: trend >= 0 ? 'rgba(25,135,84,0.1)' : 'rgba(220,53,69,0.1)',
          color: trend >= 0 ? '#198754' : '#DC3545',
        }}
      >
        {trend >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
        {Math.abs(trend)}%
      </span>
    ) : null}
  </div>
);

/* ------------------------------------------------------------------ states */

export const Spinner = ({ label = 'Loading…' }: { label?: string }) => (
  <div className="empty" role="status" aria-live="polite">
    <Loader2 size={22} style={{ animation: 'spin 1s linear infinite' }} />
    <div style={{ marginTop: 8, fontSize: 13 }}>{label}</div>
    <style>{'@keyframes spin{to{transform:rotate(360deg)}}'}</style>
  </div>
);

export const TableSkeleton = ({ rows = 5 }: { rows?: number }) => (
  <div style={{ display: 'grid', gap: 8 }} aria-hidden>
    {Array.from({ length: rows }).map((_, i) => (
      <div key={i} className="skeleton" style={{ height: 42 }} />
    ))}
  </div>
);

export const EmptyState = ({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) => (
  <div className="empty">
    <Inbox size={26} color="#A3A3A3" />
    <div style={{ fontWeight: 700, color: '#171717', marginTop: 10 }}>{title}</div>
    {subtitle ? <div style={{ fontSize: 13, marginTop: 4 }}>{subtitle}</div> : null}
    {action ? <div style={{ marginTop: 14 }}>{action}</div> : null}
  </div>
);

export const ErrorState = ({ message, onRetry }: { message: string; onRetry?: () => void }) => (
  <div className="empty" role="alert">
    <div style={{ fontWeight: 700, color: '#DC3545' }}>Something went wrong</div>
    <div style={{ fontSize: 13, marginTop: 4 }}>{message}</div>
    {onRetry ? (
      <button className="btn btn-ghost btn-sm" style={{ marginTop: 14 }} onClick={onRetry}>
        Retry
      </button>
    ) : null}
  </div>
);

/* ------------------------------------------------------------------- modal */

export const Modal = ({
  title,
  subtitle,
  onClose,
  children,
  footer,
}: {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) => {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="modal-backdrop" onClick={onClose} role="presentation">
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="row-between" style={{ marginBottom: 4 }}>
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Close dialog">
            <X size={16} />
          </button>
        </div>
        {subtitle ? <div className="modal-sub">{subtitle}</div> : null}
        {children}
        {footer ? (
          <div className="row-between" style={{ marginTop: 20, justifyContent: 'flex-end' }}>
            {footer}
          </div>
        ) : null}
      </div>
    </div>
  );
};

/* ------------------------------------------------------------------ charts */

export const RevenueChart = ({
  data,
  height = 220,
}: {
  data: { label: string; revenueMinor: number; orders?: number }[];
  height?: number;
}) => {
  if (data.length === 0) return <EmptyState title="No revenue yet" subtitle="Paid orders will appear here." />;

  const width = 720;
  const padX = 34;
  const padY = 22;
  const max = Math.max(...data.map((d) => d.revenueMinor), 100);
  const stepX = data.length > 1 ? (width - padX * 2) / (data.length - 1) : 0;

  const points = data.map((d, i) => {
    const x = padX + i * stepX;
    const y = height - padY - (d.revenueMinor / max) * (height - padY * 2);
    return { x, y, ...d };
  });

  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const area = `${line} L ${points[points.length - 1].x.toFixed(1)} ${height - padY} L ${points[0].x.toFixed(1)} ${height - padY} Z`;

  return (
    <div>
      <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} role="img" aria-label="Revenue trend">
        <defs>
          <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FF7900" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#FF7900" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75, 1].map((f) => (
          <line
            key={f}
            x1={padX}
            x2={width - padX}
            y1={height - padY - f * (height - padY * 2)}
            y2={height - padY - f * (height - padY * 2)}
            stroke="#F1F1F1"
            strokeDasharray="4 6"
          />
        ))}
        <path d={area} fill="url(#rev)" />
        <path d={line} fill="none" stroke="#FF7900" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p) => (
          <g key={p.label}>
            <circle cx={p.x} cy={p.y} r={3.5} fill="#fff" stroke="#FF7900" strokeWidth={2} />
            <text x={p.x} y={height - 4} textAnchor="middle" fontSize={10} fill="#8A8A8A">
              {p.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
};

export const DonutChart = ({
  segments,
  centerLabel,
  centerValue,
}: {
  segments: { label: string; value: number; color: string }[];
  centerLabel: string;
  centerValue: string;
}) => {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  let cursor = 0;
  const stops = segments
    .map((s) => {
      const start = (cursor / total) * 100;
      cursor += s.value;
      const end = (cursor / total) * 100;
      return `${s.color} ${start}% ${end}%`;
    })
    .join(', ');

  return (
    <div className="donut-wrap">
      <div
        className="donut"
        style={{ background: `conic-gradient(${stops || '#EEE 0% 100%'})` }}
        role="img"
        aria-label={`${centerLabel}: ${centerValue}`}
      >
        <div style={{ textAlign: 'center', zIndex: 2, position: 'relative' }}>
          <div className="donut-value">{centerValue}</div>
          <div style={{ fontSize: 10, color: '#737373', fontWeight: 600 }}>{centerLabel}</div>
        </div>
      </div>
      <div style={{ display: 'grid', gap: 8, flex: 1, minWidth: 150 }}>
        {segments.map((s) => (
          <div key={s.label} className="row-between" style={{ fontSize: 12 }}>
            <span>
              <span className="dot" style={{ background: s.color }} />
              {s.label}
            </span>
            <strong>{Math.round((s.value / total) * 100)}%</strong>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ------------------------------------------------------------------- forms */

export const Field = ({
  label,
  children,
  hint,
  error,
  full,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
  error?: string;
  full?: boolean;
}) => (
  <div className={`field ${full ? 'full' : ''}`}>
    <label>{label}</label>
    {children}
    {error ? <span className="error-text">{error}</span> : hint ? <span className="hint">{hint}</span> : null}
  </div>
);

export const ToastAlert = ({ message, type }: { message: string; type: 'success' | 'error' | 'info' }) => (
  <div className={`toast ${type}`} role="status" aria-live="polite">
    {message}
  </div>
);
