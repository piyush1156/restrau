'use client';

import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  BarChart3,
  CalendarDays,
  ChefHat,
  CircleUser,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  Menu as MenuIcon,
  ShieldCheck,
  TicketPercent,
  Users,
  UtensilsCrossed,
  X,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { clearSession, getSession, type Session, type StaffRole } from '@/lib/api';

const NAV: { href: string; label: string; icon: React.ComponentType<{ size?: number }>; roles: StaffRole[] }[] = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard, roles: ['owner', 'manager', 'kitchen', 'delivery'] },
  { href: '/orders', label: 'Orders', icon: ClipboardList, roles: ['owner', 'manager', 'kitchen', 'delivery'] },
  { href: '/menu', label: 'Menu', icon: UtensilsCrossed, roles: ['owner', 'manager', 'kitchen'] },
  { href: '/reservations', label: 'Reservations', icon: CalendarDays, roles: ['owner', 'manager'] },
  { href: '/coupons', label: 'Offers', icon: TicketPercent, roles: ['owner', 'manager'] },
  { href: '/reports', label: 'Reports', icon: BarChart3, roles: ['owner', 'manager'] },
  { href: '/customers', label: 'Customers', icon: Users, roles: ['owner', 'manager'] },
  { href: '/staff', label: 'Staff & roles', icon: ShieldCheck, roles: ['owner'] },
];

const TITLES: Record<string, { title: string; sub: string }> = {
  '/': { title: 'Dashboard', sub: 'Live restaurant performance' },
  '/orders': { title: 'Orders', sub: 'Kitchen queue and fulfilment' },
  '/menu': { title: 'Menu', sub: 'Dishes, prices and availability' },
  '/reservations': { title: 'Reservations', sub: 'Table bookings by date' },
  '/coupons': { title: 'Offers & coupons', sub: 'Discounts and validity' },
  '/reports': { title: 'Reports', sub: 'Revenue, orders and top dishes' },
  '/customers': { title: 'Customers', sub: 'Customer directory (privacy-scoped)' },
  '/staff': { title: 'Staff & roles', sub: 'Role-based access control' },
};

const ROLE_LABEL: Record<StaffRole, string> = {
  owner: 'Owner / Super Admin',
  manager: 'Restaurant Manager',
  kitchen: 'Kitchen Staff',
  delivery: 'Delivery Staff',
};

export const AppShell = ({ children }: { children: React.ReactNode }) => {
  const pathname = usePathname();
  const router = useRouter();
  const [session, setSession] = useState<Session | null | 'loading'>('loading');
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (pathname === '/login') {
      setSession(null);
      return;
    }
    const current = getSession();
    if (!current) {
      router.replace('/login');
      return;
    }
    setSession(current);
  }, [pathname, router]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  if (pathname === '/login') return <>{children}</>;

  if (session === 'loading') {
    return (
      <div className="login-wrap">
        <div style={{ color: '#737373', fontSize: 13 }}>Checking your session…</div>
      </div>
    );
  }

  if (!session) return null;

  const role = session.profile.role;
  const links = NAV.filter((item) => item.roles.includes(role));
  const meta = TITLES[pathname] ?? { title: 'The Grove', sub: 'Restaurant dashboard' };

  const logout = () => {
    clearSession();
    router.replace('/login');
  };

  return (
    <div className="app">
      <aside className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
        <div className="brand">
          <div className="brand-mark">
            <ChefHat size={20} />
          </div>
          <div>
            <div className="brand-name">The Grove</div>
            <div className="brand-sub">RESTAURANT &amp; CAFE</div>
          </div>
          <button
            className="btn btn-ghost btn-sm mobile-only"
            style={{ marginLeft: 'auto' }}
            onClick={() => setOpen(false)}
            aria-label="Close navigation"
          >
            <X size={16} />
          </button>
        </div>

        <div className="nav-section">Manage</div>
        {links.map((item) => {
          const active = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className={`nav-link ${active ? 'active' : ''}`}>
              <Icon size={18} />
              {item.label}
            </Link>
          );
        })}

        <div className="nav-spacer" />

        <div className="card" style={{ padding: 12, background: '#F8F9FB', boxShadow: 'none' }}>
          <div className="row">
            <div className="avatar" style={{ width: 34, height: 34, fontSize: 13 }}>
              {session.profile.fullName.charAt(0).toUpperCase()}
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {session.profile.fullName}
              </div>
              <div style={{ fontSize: 10, color: '#737373' }}>{ROLE_LABEL[role]}</div>
            </div>
          </div>
        </div>

        <button className="nav-link" onClick={logout} style={{ background: 'none', border: 'none', width: '100%' }}>
          <LogOut size={18} />
          Log out
        </button>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="row">
            <button
              className="btn btn-ghost btn-sm mobile-only"
              onClick={() => setOpen((v) => !v)}
              aria-label="Open navigation"
            >
              <MenuIcon size={16} />
            </button>
            <div>
              <h1>{meta.title}</h1>
              <div className="topbar-sub">{meta.sub}</div>
            </div>
          </div>
          <div className="topbar-user">
            <div style={{ textAlign: 'right' }} className="mobile-hide">
              <div style={{ fontSize: 13, fontWeight: 700 }}>{session.profile.email}</div>
              <div style={{ fontSize: 11, color: '#737373' }}>{ROLE_LABEL[role]}</div>
            </div>
            <div className="avatar">{session.profile.fullName.charAt(0).toUpperCase()}</div>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
};
