# The Grove Restaurant & Cafe

**Good Food • Good Mood** — a full-stack restaurant ordering and management platform.

| Part | Stack | Port |
| --- | --- | --- |
| Customer app | React Native + Expo SDK 52 + Expo Router + TypeScript | Expo Go / APK |
| Admin dashboard | Next.js 14 + TypeScript | 3000 |
| API | Node.js + Express + TypeScript | 4000 |
| Database / auth / storage | Supabase (Postgres + RLS + Auth + Storage) | — |
| Payments | Razorpay (server-created orders, server-side signature verification) | — |
| Assistant | OpenAI-compatible API with a rule-based fallback | — |

The mobile app runs **with zero credentials** in built-in demo mode (on-device data, simulated
payment sheet), and switches to the real backend automatically when `EXPO_PUBLIC_API_URL` is
configured. Nothing is faked silently: demo payments are labelled, and the app never shows a
fabricated driver location or guaranteed ETA.

---

## 1. What is included

### Customer app — 14 screens, all functional routes

1. Splash with session routing (no artificial delay beyond a short brand fade)
2. Login / register / forgot password (validation, show-password, session persistence)
3. Home — search, promo banner, service shortcuts, popular dishes, specials, drawer
4. Menu — category filters, case-insensitive search, veg markers, sold-out state, add to cart
5. Dish detail — image, rating, ingredients/allergens, add-ons, instructions, quantity, favourite, review
6. Cart — quantity controls, remove, clear, coupon validation, itemised bill, minimum order
7. Checkout — saved addresses, contact, delivery instructions, payment method, server re-price, idempotent order creation, Razorpay, COD
8. Order tracking — real status timeline, polling, partner contact when assigned, honest tracking fallback
9. Table booking — real availability, guest count, seating, conflict-free confirmation code, cancellation
10. Profile — edit details, reservations preview, address book, settings, logout
11. AI assistant — menu-grounded answers, suggested prompts, typing indicator, rule-based fallback
12. Order history — All / Completed / Cancelled, reorder with re-pricing at checkout
13. Favourites — server-synced
14. Side menu + Settings + Help + Privacy/Terms + Offer list

Accessibility: 44 px touch targets, labels on every interactive control, screen-reader roles,
safe-area handling, keyboard avoidance, retry and empty states.

### Admin dashboard

- Overview: revenue, order mix, popular dishes, recent orders, kitchen queue
- Orders: filter/search, role-aware status actions, cancellation with reason, audit trail
- Menu: create/edit/hide dishes, price + discounted price, veg/special flags, availability toggle, image URL
- Reservations: by-date list, confirm/reject/complete/cancel, table inventory
- Offers: create coupons, pause/activate, usage tracking
- Reports: date range, daily revenue, top dishes, fulfilment mix, CSV export
- Customers: privacy-scoped directory
- Staff: owner-only role grants + audit log

### Backend API

Auth, menu, favourites, addresses, coupons, checkout re-pricing, orders (idempotent), order
state machine, Razorpay create/verify/webhook, reservations with conflict prevention, assistant,
and admin endpoints. Input validation (Zod), structured errors, rate limits, CORS allow-list,
helmet, ownership checks and role checks on every protected route.

---

## 2. Repository layout

```
the-grove/
  apps/
    mobile/                 Expo app (app/, src/{components,services,store,hooks,data})
    admin/                  Next.js dashboard (app/, components/, lib/)
  backend/
    src/
      routes/               auth, catalog, orders, reservations, chat, admin
      lib/                  supabase, mappers, catalog/pricing, razorpay, chat, notifications, audit
      middleware/           JWT auth + role checks
      tests/                unit + opt-in end-to-end tests
  packages/shared/          types, Zod schemas, pricing, order-flow, constants (single source of truth)
  supabase/
    migrations/             schema, RLS policies, helper functions
    seed.sql                categories, dishes, add-ons, tables, hours, coupons
  docs/                     SETUP, API, DATABASE, DEPLOYMENT
```

Money is **always integer paise**. Pricing, tax, fees and coupon rules live in
`packages/shared/src/pricing.ts` and are re-computed on the server for every order.

---

## 3. Quick start (demo mode — no backend needed)

```bash
npm install
npm run dev:mobile        # Expo dev server; press a for Android, i for iOS
```

Scan the QR code with Expo Go, or run on an emulator. Sign in with **any** email/phone and a
password of 6+ characters. Demo data (menu, profile, orders, reservations, favourites) persists
on the device via AsyncStorage.

Demo staff account for permission checks in the app: `admin@thegrove.in` / `admin12345`.

> Expo Go does not include the native Razorpay module. In demo mode the app shows a clearly
> labelled test payment sheet. Real Razorpay Checkout works in a development/preview build.

## 4. Full stack setup

```bash
cp .env.example .env
cp backend/.env.example backend/.env
cp apps/mobile/.env.example apps/mobile/.env
cp apps/admin/.env.example apps/admin/.env
```

1. Create a Supabase project, then apply the schema:
   ```bash
   npx supabase link --project-ref <ref>
   npx supabase db push          # or paste supabase/migrations/*.sql in order
   # then run supabase/seed.sql in the SQL editor
   ```
2. Create a customer account in the app (or Supabase Auth), then grant yourself a staff role:
   ```sql
   select public.grant_staff('owner@thegrove.in', 'owner');
   ```
3. Fill `backend/.env` with `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_ANON_KEY`.
4. Start everything:
   ```bash
   npm run dev:backend       # http://localhost:4000/health
   npm run dev:admin         # http://localhost:3000
   npm run dev:mobile
   ```
5. Point the app at the API: `EXPO_PUBLIC_API_URL=http://<LAN-IP>:4000` in `apps/mobile/.env`
   (use your machine's LAN IP, not `localhost`, for a physical device) and
   `EXPO_PUBLIC_API_MODE=auto` (or `remote`).

Full instructions: [`docs/SETUP.md`](docs/SETUP.md).

## 5. Android APK (EAS Build)

```bash
cd apps/mobile
npx eas-cli login
npx eas-cli init                     # writes the real projectId into app.json
npx eas-cli build -p android --profile preview --non-interactive
```

`eas.json` defines `preview` with `"buildType": "apk"`, so the build page gives a directly
installable APK. For a local build with Android Studio installed:

```bash
npx eas-cli build -p android --profile preview --local
```

Add build-time env vars in `eas.json` (or `eas secret:create`) before building:

```json
"env": {
  "EXPO_PUBLIC_API_MODE": "remote",
  "EXPO_PUBLIC_API_URL": "https://api.yourdomain.com",
  "EXPO_PUBLIC_RAZORPAY_KEY_ID": "rzp_live_xxx"
}
```

iOS: `npx eas-cli build -p ios --profile production` (requires an Apple Developer account).

> An APK cannot be produced by a source-only environment: it needs an Expo account, EAS
> credentials and a build machine. Everything needed to produce it is configured here.

Details: [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).

## 6. Tests

```bash
npm test                    # shared pricing/validation + backend unit tests
npm run typecheck           # shared, backend, admin
cd apps/mobile && npm run typecheck
```

Covered: money formatting, tax/fee/discount math, coupon validity and caps, order status
machine, role permissions, reservation table selection and double-booking, Razorpay signature
and webhook verification, request validation, plus an opt-in full customer journey against a
running API (`backend/src/tests/customer-journey.e2e.test.ts`).

Endpoint reference: [`docs/API.md`](docs/API.md) · Schema: [`docs/DATABASE.md`](docs/DATABASE.md)

## 7. Security model

- Secrets only on the server; the app ships only `EXPO_PUBLIC_*` values.
- Every order total is recomputed server-side; client totals are display-only.
- Razorpay signatures are verified with HMAC-SHA256 (timing-safe); webhooks are verified over raw bytes.
- Order writes happen through the API; RLS prevents clients from writing orders/payments.
- Idempotency keys prevent duplicate orders and duplicate payment orders.
- Role checks on the server (`requireRole`) plus RLS policies; hiding UI is never the control.
- Login and password reset are rate-limited; passwords, tokens and signatures are redacted from logs.
- Reservation conflicts are blocked by a partial unique index *and* a trigger.

## 8. Known configuration requirements

| Feature | Needs |
| --- | --- |
| Real payments | `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_PUBLIC_KEY_ID`, webhook secret; set `PAYMENTS_DEMO=false` |
| AI assistant | `OPENAI_API_KEY` (+ optional base URL/model); otherwise the rule-based assistant answers |
| Push notifications | `EXPO_PUSH_ENABLED=true`, device tokens registered by the app |
| Email receipts | `RESEND_API_KEY` and a verified sender |
| Live map tracking | Not implemented: no provider is integrated, and the app says so instead of faking a driver location |

**Note on demo data:** the app and seed data contain sample dishes and demo orders only. They are
never presented as real transactions, and Razorpay is never charged in demo mode.
