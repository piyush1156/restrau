import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['src/tests/**/*.test.ts'],
    exclude: ['src/tests/**/*.e2e.test.ts'],
    env: { NODE_ENV: 'test' },
    testTimeout: 15_000,
  },
});
