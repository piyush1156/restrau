import { createApp } from './app.js';
import { config } from './config.js';
import { isConfigured } from './lib/supabase.js';

const app = createApp();

const server = app.listen(config.PORT, () => {
  console.log(`The Grove API listening on http://localhost:${config.PORT}`);
  console.log(`  env:        ${config.NODE_ENV}`);
  console.log(`  database:   ${isConfigured() ? 'configured' : 'NOT configured (demo client will be used)'}`);
  console.log(`  payments:   ${config.razorpayEnabled ? 'razorpay' : config.PAYMENTS_DEMO ? 'demo' : 'disabled'}`);
  console.log(`  assistant:  ${config.aiEnabled ? 'AI provider' : 'rule-based fallback'}`);
});

const shutdown = (signal: string) => {
  console.log(`\n${signal} received — closing server...`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 8000).unref();
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (reason) => {
  console.error('[fatal] unhandled rejection', reason);
});
