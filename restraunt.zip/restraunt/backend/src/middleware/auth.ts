import type { NextFunction, Request, Response } from 'express';
import type { Role } from '@grove/shared';
import { ADMIN_ROLES } from '@grove/shared';
import { db } from '../lib/supabase.js';
import { AppError, asyncHandler } from '../lib/http.js';

export interface AuthUser {
  id: string;
  email: string;
  role: Role;
  fullName: string;
  phone: string | null;
  locale: 'en' | 'hi';
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser;
      accessToken?: string;
    }
  }
}

const bearer = (req: Request): string | null => {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return null;
  return header.slice(7).trim() || null;
};

const loadUser = async (token: string): Promise<AuthUser> => {
  const { data, error } = await db().auth.getUser(token);
  if (error || !data.user) throw AppError.unauthorized('Your session has expired. Please sign in again.');

  const { data: profile, error: profileError } = await db()
    .from('profiles')
    .select('id, email, role, full_name, phone, locale')
    .eq('id', data.user.id)
    .maybeSingle();

  if (profileError) throw AppError.unavailable('Could not load your profile.');
  if (!profile) throw AppError.unauthorized('Profile missing. Please sign in again.');

  return {
    id: profile.id,
    email: profile.email,
    role: profile.role as Role,
    fullName: profile.full_name,
    phone: profile.phone,
    locale: profile.locale === 'hi' ? 'hi' : 'en',
  };
};

/** Rejects anonymous requests. */
export const requireAuth = asyncHandler(async (req, _res, next) => {
  const token = bearer(req);
  if (!token) throw AppError.unauthorized();
  req.user = await loadUser(token);
  req.accessToken = token;
  next();
});

/** Attaches the user when a valid token is present, but never blocks. */
export const optionalAuth = asyncHandler(async (req, _res, next) => {
  const token = bearer(req);
  if (!token) return next();
  try {
    req.user = await loadUser(token);
    req.accessToken = token;
  } catch {
    req.user = undefined;
  }
  next();
});

/** Server-side permission check — hiding UI buttons is never enough. */
export const requireRole =
  (...roles: Role[]) =>
  (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) return next(AppError.unauthorized());
    if (!roles.includes(req.user.role)) {
      return next(AppError.forbidden('Your staff role does not allow this action.'));
    }
    next();
  };

export const requireStaff = requireRole('owner', 'manager', 'kitchen', 'delivery');
export const requireAdmin = requireRole(...ADMIN_ROLES);
