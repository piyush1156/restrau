import { describe, expect, it } from 'vitest';
import { pickTable } from '../routes/reservations.js';
import type { RestaurantTable } from '@grove/shared';

const tables: RestaurantTable[] = [
  { id: 't1', tableNumber: 1, capacity: 2, seating: 'indoor', is_active: true },
  { id: 't2', tableNumber: 2, capacity: 4, seating: 'indoor', is_active: true },
  { id: 't3', tableNumber: 3, capacity: 6, seating: 'outdoor', is_active: true },
  { id: 't4', tableNumber: 4, capacity: 2, seating: 'outdoor', is_active: false },
];

describe('pickTable', () => {
  it('prefers the smallest table that fits the party', () => {
    expect(pickTable(tables, new Set(), 2, 'any')?.id).toBe('t1');
    expect(pickTable(tables, new Set(), 4, 'any')?.id).toBe('t2');
  });

  it('honours the seating preference', () => {
    expect(pickTable(tables, new Set(), 2, 'outdoor')?.id).toBe('t3');
    expect(pickTable(tables, new Set(), 2, 'indoor')?.id).toBe('t1');
  });

  it('falls back to another seating area when the preferred one is full', () => {
    // only indoor t1 fits 2 guests and it is taken → outdoor t3 fits 2 (capacity 6)
    const picked = pickTable(tables, new Set(['t1', 't2']), 2, 'indoor');
    expect(picked?.id).toBe('t3');
  });

  it('never returns an inactive table', () => {
    expect(pickTable(tables, new Set(['t1']), 2, 'outdoor')?.id).toBe('t3');
  });

  it('returns null when every fitting table is booked', () => {
    expect(pickTable(tables, new Set(['t1', 't2', 't3']), 2, 'any')).toBeNull();
  });

  it('returns null when no table is large enough', () => {
    expect(pickTable(tables, new Set(), 12, 'any')).toBeNull();
  });

  it('prevents the same table being assigned to two guests in one slot', () => {
    const taken = new Set<string>();
    const first = pickTable(tables, taken, 4, 'any');
    expect(first).not.toBeNull();
    taken.add(first!.id);
    const second = pickTable(tables, taken, 4, 'any');
    expect(second?.id).not.toBe(first?.id);
  });
});
