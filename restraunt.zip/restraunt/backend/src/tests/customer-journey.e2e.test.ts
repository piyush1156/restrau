import { describe, expect, it } from 'vitest';

/**
 * End-to-end customer journey:
 *   login → browse menu → open dish → add to cart → validate → checkout →
 *   (demo) payment → order confirmation → track order
 *
 * Runs only when E2E_BASE_URL is provided so `npm test` stays hermetic:
 *
 *   E2E_BASE_URL=http://localhost:4000 E2E_EMAIL=you@example.com E2E_PASSWORD=yourpass \
 *     npx vitest run src/tests/customer-journey.e2e.test.ts
 *
 * Payment uses sandbox/test mode only. Never point this at production.
 */
const BASE = process.env.E2E_BASE_URL;
const EMAIL = process.env.E2E_EMAIL ?? '';
const PASSWORD = process.env.E2E_PASSWORD ?? '';

const api = async (path: string, init: RequestInit = {}, token?: string) => {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
};

describe.skipIf(!BASE || !EMAIL || !PASSWORD)('customer journey (live API)', () => {
  it('completes an order end to end', async () => {
    const health = await api('/health');
    expect([200, 503]).toContain(health.status);

    const login = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier: EMAIL, password: PASSWORD }),
    });
    expect(login.status).toBe(200);
    const token: string = login.body.token;
    expect(token).toBeTruthy();

    const menu = await api('/menu');
    expect(menu.status).toBe(200);
    const item = menu.body.data.find((m: any) => m.isAvailable);
    expect(item).toBeTruthy();

    const detail = await api(`/menu/${item.id}`);
    expect(detail.status).toBe(200);

    const lines = [
      {
        key: `e2e-${Date.now()}`,
        menuItemId: item.id,
        name: item.name,
        imageUrl: item.imageUrl,
        unitPriceMinor: item.discountedPriceMinor ?? item.priceMinor,
        quantity: 1,
        addOns: [],
      },
    ];

    const reprice = await api('/checkout/reprice', { method: 'POST', body: JSON.stringify({ lines }) });
    expect(reprice.status).toBe(200);
    expect(reprice.body.lines).toHaveLength(1);

    const idempotencyKey = `e2e-${Date.now()}`;
    const placed = await api(
      '/orders',
      {
        method: 'POST',
        headers: { 'Idempotency-Key': idempotencyKey },
        body: JSON.stringify({
          checkout: {
            addressId: process.env.E2E_ADDRESS_ID ?? null,
            type: process.env.E2E_ADDRESS_ID ? 'delivery' : 'takeaway',
            paymentMethod: 'razorpay',
            contactPhone: '9876543210',
            deliveryInstructions: 'E2E test order',
            couponCode: '',
          },
          lines,
          idempotencyKey,
        }),
      },
      token,
    );
    expect([201, 200]).toContain(placed.status);
    const orderId: string = placed.body.data.id;

    // Replaying the same key must not create a second order.
    const replay = await api(
      '/orders',
      {
        method: 'POST',
        headers: { 'Idempotency-Key': idempotencyKey },
        body: JSON.stringify({
          checkout: { type: 'takeaway', paymentMethod: 'razorpay', contactPhone: '9876543210' },
          lines,
          idempotencyKey,
        }),
      },
      token,
    );
    expect(replay.body.data.id).toBe(orderId);

    const paymentOrder = await api('/payments/create-order', { method: 'POST', body: JSON.stringify({ orderId }) }, token);
    expect(paymentOrder.status).toBe(200);
    expect(paymentOrder.body.amountMinor).toBeGreaterThan(0);

    if (paymentOrder.body.demo) {
      const verified = await api(
        '/payments/verify',
        {
          method: 'POST',
          body: JSON.stringify({
            orderId,
            razorpayOrderId: paymentOrder.body.razorpayOrderId,
            razorpayPaymentId: `pay_demo_e2e_${Date.now()}`,
            razorpaySignature: `sig_demo_e2e_${Date.now()}`,
          }),
        },
        token,
      );
      expect(verified.status).toBe(200);
      expect(verified.body.data.paymentStatus).toBe('paid');
      expect(['confirmed', 'preparing']).toContain(verified.body.data.status);
    }

    const tracking = await api(`/orders/${orderId}`, {}, token);
    expect(tracking.status).toBe(200);
    expect(tracking.body.data.orderNumber).toMatch(/^TG\d+$/);
    expect(tracking.body.data.items.length).toBeGreaterThan(0);

    const history = await api('/orders?status=all', {}, token);
    expect(history.status).toBe(200);
    expect(history.body.data.some((o: any) => o.id === orderId)).toBe(true);
  }, 60_000);
});
