import { describe, expect, it } from 'vitest';
import {
  addressSchema,
  checkoutSchema,
  loginSchema,
  registerSchema,
  reservationSchema,
  reviewSchema,
} from '@grove/shared';

const validRegister = {
  fullName: 'Piyush Singh',
  email: 'piyush@example.com',
  phone: '9876543210',
  password: 'grove1234',
  confirmPassword: 'grove1234',
};

describe('registerSchema', () => {
  it('accepts a valid Indian registration', () => {
    expect(registerSchema.safeParse(validRegister).success).toBe(true);
  });

  it('rejects mismatched passwords', () => {
    const result = registerSchema.safeParse({ ...validRegister, confirmPassword: 'other1234' });
    expect(result.success).toBe(false);
  });

  it('rejects weak passwords and bad phone numbers', () => {
    expect(registerSchema.safeParse({ ...validRegister, password: 'short', confirmPassword: 'short' }).success).toBe(false);
    expect(
      registerSchema.safeParse({ ...validRegister, phone: '12345' }).success,
    ).toBe(false);
  });

  it('rejects unknown fields (mass assignment guard)', () => {
    const result = registerSchema.safeParse({ ...validRegister, role: 'owner' });
    expect(result.success).toBe(false);
  });
});

describe('loginSchema', () => {
  it('accepts an email or a phone identifier', () => {
    expect(loginSchema.safeParse({ identifier: 'piyush@example.com', password: 'grove1234' }).success).toBe(true);
    expect(loginSchema.safeParse({ identifier: '9876543210', password: 'grove1234' }).success).toBe(true);
  });

  it('rejects nonsense identifiers', () => {
    expect(loginSchema.safeParse({ identifier: 'not-an-email', password: 'grove1234' }).success).toBe(false);
  });
});

describe('checkoutSchema', () => {
  const base = {
    addressId: '11111111-1111-1111-1111-111111111111',
    type: 'delivery' as const,
    paymentMethod: 'razorpay' as const,
    contactPhone: '9876543210',
    deliveryInstructions: 'Ring the bell',
    couponCode: 'grove10',
  };

  it('accepts a delivery checkout and uppercases the coupon', () => {
    const parsed = checkoutSchema.parse(base);
    expect(parsed.couponCode).toBe('GROVE10');
  });

  it('requires an address for delivery', () => {
    expect(checkoutSchema.safeParse({ ...base, addressId: null }).success).toBe(false);
  });

  it('allows takeaway without an address', () => {
    expect(checkoutSchema.safeParse({ ...base, type: 'takeaway', addressId: null }).success).toBe(true);
  });

  it('rejects unsupported payment methods', () => {
    expect(checkoutSchema.safeParse({ ...base, paymentMethod: 'card' }).success).toBe(false);
  });
});

describe('addressSchema', () => {
  it('validates pincodes and labels', () => {
    const ok = addressSchema.safeParse({
      label: 'Home',
      line1: '123, Green Park',
      city: 'New Delhi',
      pincode: '110016',
    });
    expect(ok.success).toBe(true);

    expect(
      addressSchema.safeParse({ label: 'Home', line1: '123, Green Park', city: 'New Delhi', pincode: '000111' }).success,
    ).toBe(false);
    expect(
      addressSchema.safeParse({ label: 'Castle', line1: '123, Green Park', city: 'New Delhi', pincode: '110016' }).success,
    ).toBe(false);
  });
});

describe('reservationSchema', () => {
  it('accepts today with a valid slot', () => {
    const today = new Date().toISOString().slice(0, 10);
    expect(
      reservationSchema.safeParse({ date: today, time: '19:30', guests: 4, seating: 'indoor' }).success,
    ).toBe(true);
  });

  it('rejects past dates and oversized parties', () => {
    const past = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    expect(reservationSchema.safeParse({ date: past, time: '19:30', guests: 4, seating: 'any' }).success).toBe(false);
    expect(
      reservationSchema.safeParse({ date: new Date().toISOString().slice(0, 10), time: '19:30', guests: 40, seating: 'any' })
        .success,
    ).toBe(false);
  });
});

describe('reviewSchema', () => {
  it('bounds ratings to 1..5', () => {
    expect(reviewSchema.safeParse({ rating: 5, comment: 'Loved it' }).success).toBe(true);
    expect(reviewSchema.safeParse({ rating: 6, comment: 'Loved it' }).success).toBe(false);
    expect(reviewSchema.safeParse({ rating: 4, comment: 'x' }).success).toBe(false);
  });
});
