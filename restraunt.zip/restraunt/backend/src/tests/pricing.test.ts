import { describe, expect, it } from 'vitest';
import { computeTotals, couponDiscount, couponIsValid, DEFAULT_RESTAURANT_CONFIG } from '@grove/shared';
import type { CartLine, Coupon } from '@grove/shared';

const config = { ...DEFAULT_RESTAURANT_CONFIG, deliveryFeeMinor: 4000, platformFeeMinor: 2000, taxBps: 500 };

const line = (priceMinor: number, quantity = 1): CartLine => ({
  key: `k-${priceMinor}-${quantity}`,
  menuItemId: 'mi',
  name: 'Dish',
  imageUrl: '',
  unitPriceMinor: priceMinor,
  addOns: [],
  quantity,
});

const coupon = (over: Partial<Coupon> = {}): Coupon => ({
  code: 'TEST10',
  description: 'test',
  discountPercent: 10,
  maxDiscountMinor: 5000,
  minOrderMinor: 19900,
  expiresAt: new Date(Date.now() + 86400000).toISOString(),
  isActive: true,
  usageLimit: 100,
  usedCount: 0,
  ...over,
});

describe('computeTotals', () => {
  it('adds 5% GST, delivery and platform fee for delivery orders', () => {
    const totals = computeTotals({
      lines: [line(24900, 2)],
      coupon: null,
      config,
      orderType: 'delivery',
    });
    expect(totals.subtotalMinor).toBe(49800);
    expect(totals.taxesMinor).toBe(2490); // 5% of 49800
    expect(totals.deliveryFeeMinor).toBe(4000);
    expect(totals.platformFeeMinor).toBe(2000);
    expect(totals.grandTotalMinor).toBe(49800 + 2490 + 4000 + 2000);
  });

  it('gives free delivery above the threshold', () => {
    const totals = computeTotals({
      lines: [line(50000)],
      coupon: null,
      config,
      orderType: 'delivery',
    });
    expect(totals.deliveryFeeMinor).toBe(0);
  });

  it('never charges delivery for takeaway and still applies platform fee', () => {
    const totals = computeTotals({ lines: [line(30000)], coupon: null, config, orderType: 'takeaway' });
    expect(totals.deliveryFeeMinor).toBe(0);
    expect(totals.platformFeeMinor).toBe(2000);
  });

  it('applies coupon discount before tax, capped at the coupon maximum', () => {
    const totals = computeTotals({
      lines: [line(100000)],
      coupon: coupon({ discountPercent: 10, maxDiscountMinor: 5000 }),
      config,
      orderType: 'takeaway',
    });
    expect(totals.discountMinor).toBe(5000); // 10% = 10000, capped at 5000
    expect(totals.taxesMinor).toBe(Math.round((100000 - 5000) * 0.05));
    expect(totals.grandTotalMinor).toBe(95000 + 4750 + 2000);
  });

  it('reports the minimum-order issue below ₹199 for delivery only', () => {
    const delivery = computeTotals({ lines: [line(15000)], coupon: null, config, orderType: 'delivery' });
    expect(delivery.issues.length).toBe(1);
    expect(delivery.issues[0]).toContain('Minimum order');

    const takeaway = computeTotals({ lines: [line(15000)], coupon: null, config, orderType: 'takeaway' });
    expect(takeaway.issues).toEqual([]);
  });

  it('returns zero fees and total for an empty cart', () => {
    const totals = computeTotals({ lines: [], coupon: null, config, orderType: 'delivery' });
    expect(totals).toMatchObject({
      subtotalMinor: 0,
      taxesMinor: 0,
      deliveryFeeMinor: 0,
      platformFeeMinor: 0,
      grandTotalMinor: 0,
    });
  });

  it('works in whole paise without floating point drift', () => {
    const totals = computeTotals({ lines: [line(33333, 3)], coupon: null, config, orderType: 'takeaway' });
    expect(Number.isInteger(totals.grandTotalMinor)).toBe(true);
    expect(totals.subtotalMinor).toBe(99999);
    expect(totals.taxesMinor).toBe(5000); // 4999.95 → 5000 integer paise
  });
});

describe('coupon rules', () => {
  it('rejects expired coupons', () => {
    expect(couponIsValid(coupon({ expiresAt: new Date(Date.now() - 1000).toISOString() }), 50000)).toBe(false);
  });

  it('rejects carts below the minimum order', () => {
    expect(couponIsValid(coupon(), 5000)).toBe(false);
  });

  it('rejects coupons that hit their usage limit', () => {
    expect(couponIsValid(coupon({ usageLimit: 5, usedCount: 5 }), 50000)).toBe(false);
  });

  it('caps flat discounts at the subtotal', () => {
    const { discountMinor, applied } = couponDiscount(
      coupon({ discountPercent: undefined, discountFlatMinor: 90000, minOrderMinor: 0 }),
      40000,
    );
    expect(applied).toBe(true);
    expect(discountMinor).toBe(40000);
  });

  it('never reports a discount for an inactive coupon', () => {
    expect(couponDiscount(coupon({ isActive: false }), 90000)).toEqual({ discountMinor: 0, applied: false });
  });
});
