import { describe, expect, it } from 'vitest';
import {
  canCustomerCancel,
  canRoleSetStatus,
  canTransition,
  canTransitionReservation,
  trackingStepsFor,
} from '@grove/shared';

describe('order status machine', () => {
  it('walks the happy delivery path', () => {
    const path = ['pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered'] as const;
    for (let i = 0; i < path.length - 1; i++) {
      expect(canTransition(path[i], path[i + 1])).toBe(true);
    }
  });

  it('blocks skipping preparation', () => {
    expect(canTransition('pending', 'delivered')).toBe(false);
    expect(canTransition('confirmed', 'out_for_delivery')).toBe(false);
  });

  it('treats delivered and cancelled as terminal', () => {
    expect(canTransition('delivered', 'cancelled')).toBe(false);
    expect(canTransition('cancelled', 'confirmed')).toBe(false);
  });

  it('allows cancellation only before cooking', () => {
    expect(canCustomerCancel('pending')).toBe(true);
    expect(canCustomerCancel('confirmed')).toBe(true);
    expect(canCustomerCancel('preparing')).toBe(false);
    expect(canCustomerCancel('out_for_delivery')).toBe(false);
  });

  it('uses different tracking steps for delivery and takeaway', () => {
    expect(trackingStepsFor('delivery')).toEqual(['confirmed', 'preparing', 'out_for_delivery', 'delivered']);
    expect(trackingStepsFor('takeaway')).toEqual(['confirmed', 'preparing', 'ready', 'delivered']);
  });
});

describe('staff permissions', () => {
  it('lets kitchen staff advance cooking but not cancel orders', () => {
    expect(canRoleSetStatus('kitchen', 'preparing')).toBe(true);
    expect(canRoleSetStatus('kitchen', 'ready')).toBe(true);
    expect(canRoleSetStatus('kitchen', 'cancelled')).toBe(false);
  });

  it('lets delivery staff complete deliveries only', () => {
    expect(canRoleSetStatus('delivery', 'out_for_delivery')).toBe(true);
    expect(canRoleSetStatus('delivery', 'delivered')).toBe(true);
    expect(canRoleSetStatus('delivery', 'preparing')).toBe(false);
  });

  it('reserves cancellations for managers and owners', () => {
    expect(canRoleSetStatus('manager', 'cancelled')).toBe(true);
    expect(canRoleSetStatus('owner', 'cancelled')).toBe(true);
    expect(canRoleSetStatus('delivery', 'cancelled')).toBe(false);
    expect(canRoleSetStatus('customer', 'confirmed')).toBe(false);
  });
});

describe('reservation status machine', () => {
  it('allows confirm → complete and confirm → cancel', () => {
    expect(canTransitionReservation('pending', 'confirmed')).toBe(true);
    expect(canTransitionReservation('confirmed', 'completed')).toBe(true);
    expect(canTransitionReservation('confirmed', 'cancelled')).toBe(true);
  });

  it('does not resurrect rejected or cancelled bookings', () => {
    expect(canTransitionReservation('rejected', 'confirmed')).toBe(false);
    expect(canTransitionReservation('cancelled', 'confirmed')).toBe(false);
    expect(canTransitionReservation('completed', 'cancelled')).toBe(false);
  });
});
