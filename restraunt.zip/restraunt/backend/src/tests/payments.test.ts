import crypto from 'node:crypto';
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';

const KEY_SECRET = 'test_secret_key_value';
const WEBHOOK_SECRET = 'test_webhook_secret';

let razorpay: typeof import('../lib/razorpay.js');

beforeAll(async () => {
  vi.resetModules();
  process.env.NODE_ENV = 'test';
  process.env.RAZORPAY_KEY_ID = 'rzp_test_key';
  process.env.RAZORPAY_KEY_SECRET = KEY_SECRET;
  process.env.RAZORPAY_WEBHOOK_SECRET = WEBHOOK_SECRET;
  process.env.SUPABASE_URL = 'https://example.supabase.co';
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-role-test';
  process.env.SUPABASE_ANON_KEY = 'anon-test';
  razorpay = await import('../lib/razorpay.js');
});

afterEach(() => {
  vi.restoreAllMocks();
});

const signPayment = (orderId: string, paymentId: string) =>
  crypto.createHmac('sha256', KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');

describe('verifyPaymentSignature', () => {
  it('accepts a signature produced with the key secret', () => {
    const payload = { razorpayOrderId: 'order_123', razorpayPaymentId: 'pay_456' };
    expect(
      razorpay.verifyPaymentSignature({ ...payload, signature: signPayment(payload.razorpayOrderId, payload.razorpayPaymentId) }),
    ).toBe(true);
  });

  it('rejects a tampered payment id', () => {
    const signature = signPayment('order_123', 'pay_456');
    expect(
      razorpay.verifyPaymentSignature({
        razorpayOrderId: 'order_123',
        razorpayPaymentId: 'pay_999',
        signature,
      }),
    ).toBe(false);
  });

  it('rejects an empty signature', () => {
    expect(
      razorpay.verifyPaymentSignature({ razorpayOrderId: 'o', razorpayPaymentId: 'p', signature: '   ' }),
    ).toBe(false);
  });

  it('rejects signatures of a different length without throwing', () => {
    expect(
      razorpay.verifyPaymentSignature({ razorpayOrderId: 'o', razorpayPaymentId: 'p', signature: 'abc' }),
    ).toBe(false);
  });
});

describe('verifyWebhookSignature', () => {
  const body = Buffer.from(JSON.stringify({ event: 'payment.captured' }));

  it('accepts a webhook signed over the exact raw body', () => {
    const signature = crypto.createHmac('sha256', WEBHOOK_SECRET).update(body).digest('hex');
    expect(razorpay.verifyWebhookSignature(body, signature)).toBe(true);
  });

  it('rejects a modified body', () => {
    const signature = crypto.createHmac('sha256', WEBHOOK_SECRET).update(body).digest('hex');
    const tampered = Buffer.from(JSON.stringify({ event: 'payment.captured', amount: 1 }));
    expect(razorpay.verifyWebhookSignature(tampered, signature)).toBe(false);
  });

  it('rejects an unsigned request', () => {
    expect(razorpay.verifyWebhookSignature(body, '')).toBe(false);
  });
});

describe('publicKeyId', () => {
  it('exposes only the public key, never the secret', () => {
    const key = razorpay.publicKeyId();
    expect(key).toBe('rzp_test_key');
    expect(key).not.toContain(KEY_SECRET);
  });
});
