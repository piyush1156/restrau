import express, { type Express } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { errorHandler, notFoundHandler } from './lib/http.js';
import { isConfigured } from './lib/supabase.js';
import { authRouter } from './routes/auth.js';
import { catalogRouter } from './routes/catalog.js';
import { ordersRouter, razorpayWebhook } from './routes/orders.js';
import { reservationsRouter } from './routes/reservations.js';
import { chatRouter } from './routes/chat.js';
import { adminRouter } from './routes/admin.js';

const limiter = (windowMs: number, max: number, message: string) =>
  rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => config.isTest,
    handler: (_req, res) => {
      res.status(429).json({ error: { code: 'rate_limited', message } });
    },
  });

export const createApp = (): Express => {
  const app = express();

  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(
    helmet({
      contentSecurityPolicy: false, // API only; the admin app serves its own CSP
      crossOriginResourcePolicy: { policy: 'cross-origin' },
    }),
  );

  app.use(
    cors({
      origin(origin, callback) {
        if (!origin) return callback(null, true); // native apps send no Origin
        if (config.corsOrigins.includes(origin)) return callback(null, true);
        return callback(new Error('Origin not allowed by CORS'));
      },
      credentials: false,
      methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key'],
      maxAge: 600,
    }),
  );

  // Webhook needs the exact raw bytes for signature verification.
  app.post('/payments/webhook', express.raw({ type: 'application/json', limit: '1mb' }), razorpayWebhook);

  app.use(express.json({ limit: '512kb' }));

  app.get('/health', (_req, res) => {
    const dbReady = isConfigured();
    res.status(dbReady || !config.isProd ? 200 : 503).json({
      ok: dbReady || !config.isProd,
      service: 'the-grove-api',
      version: '1.0.0',
      db: dbReady,
      payments: config.razorpayEnabled ? 'live' : config.PAYMENTS_DEMO ? 'demo' : 'disabled',
      ai: config.aiEnabled ? 'enabled' : 'rules-fallback',
      time: new Date().toISOString(),
    });
  });

  // Global ceiling first, then stricter limits on sensitive paths.
  app.use(limiter(60_000, 300, 'Too many requests. Please slow down.'));

  const authLimiter = limiter(15 * 60_000, 20, 'Too many attempts. Please wait 15 minutes and try again.');
  app.use(
    [
      '/login',
      '/register',
      '/reset-password',
      '/auth/login',
      '/auth/register',
      '/auth/reset-password',
    ],
    authLimiter,
  );

  app.use(
    '/chat/messages',
    limiter(60_000, 20, 'You are sending messages too quickly. Please wait a moment.'),
  );

  // authRouter exposes both /auth/* and /me so the mobile client can use either.
  app.use('/', authRouter);
  app.use('/', catalogRouter);
  app.use('/', ordersRouter);
  app.use('/', reservationsRouter);
  app.use('/', chatRouter);
  app.use('/', adminRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
};
