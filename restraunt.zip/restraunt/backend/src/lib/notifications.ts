import { config } from '../config.js';
import { db } from './supabase.js';

export type NotificationCategory = 'order' | 'reservation' | 'marketing';

interface NotificationInput {
  userId: string;
  title: string;
  body: string;
  data?: Record<string, unknown>;
  /** Optional preference gate: push/email are skipped when the customer opted out. */
  category?: NotificationCategory;
}

/**
 * Persists an in-app notification and best-effort delivers push + email.
 * Delivery failures are logged, never thrown: a failed push must not roll back
 * a successful order or status change.
 */
export const notifyUser = async (input: NotificationInput): Promise<void> => {
  try {
    await db().from('notifications').insert({
      user_id: input.userId,
      title: input.title,
      body: input.body,
      data: input.data ?? {},
      channel: 'in_app',
    });
  } catch (err) {
    console.warn('[notifications] could not persist notification', (err as Error).message);
  }

  if (input.category) {
    try {
      const { data: prefs } = await db()
        .from('profiles')
        .select('notify_order_updates, notify_offers, notify_reservations')
        .eq('id', input.userId)
        .maybeSingle();

      const enabled =
        input.category === 'order'
          ? prefs?.notify_order_updates !== false
          : input.category === 'reservation'
            ? prefs?.notify_reservations !== false
            : prefs?.notify_offers !== false;
      if (!enabled) return;
    } catch (err) {
      // If preferences cannot be read, default to sending rather than dropping updates.
      console.warn('[notifications] could not read preferences', (err as Error).message);
    }
  }

  if (config.EXPO_PUSH_ENABLED) {
    void sendPush(input).catch((err) =>
      console.warn('[notifications] push failed', (err as Error).message),
    );
  }
  if (config.RESEND_API_KEY) {
    void sendEmail(input).catch((err) =>
      console.warn('[notifications] email failed', (err as Error).message),
    );
  }
};

const sendPush = async (input: NotificationInput): Promise<void> => {
  const { data: profile } = await db()
    .from('profiles')
    .select('push_tokens')
    .eq('id', input.userId)
    .maybeSingle();

  const tokens: string[] = (profile?.push_tokens ?? []).filter(Boolean);
  if (tokens.length === 0) return;

  const messages = tokens.map((to) => ({
    to,
    sound: 'default',
    title: input.title,
    body: input.body,
    data: input.data ?? {},
  }));

  const res = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(messages),
  });
  if (!res.ok) throw new Error(`Expo push returned ${res.status}`);
};

const sendEmail = async (input: NotificationInput): Promise<void> => {
  const { data: profile } = await db()
    .from('profiles')
    .select('email')
    .eq('id', input.userId)
    .maybeSingle();
  if (!profile?.email) return;

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: config.EMAIL_FROM,
      to: profile.email,
      subject: input.title,
      text: input.body,
    }),
  });
  if (!res.ok) throw new Error(`Resend returned ${res.status}`);
};
