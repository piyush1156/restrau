import type { MenuItem, OpeningHour, Order } from '@grove/shared';
import { formatMinor } from '@grove/shared';
import { config } from '../config.js';

export interface ChatContext {
  menu: MenuItem[];
  hours: OpeningHour[];
  orders: Order[];
  isAuthenticated: boolean;
  locale: 'en' | 'hi';
  customerName?: string;
}

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const available = (menu: MenuItem[]) => menu.filter((m) => m.isAvailable);
const fmt = (m: MenuItem) => `${m.name} — ${formatMinor(m.discountedPriceMinor ?? m.priceMinor)}${m.isVeg ? ' (veg)' : ' (non-veg)'}`;

/**
 * Deterministic assistant used when no AI key is configured, and as the
 * fallback whenever the AI provider errors. It only answers from real data.
 */
export const ruleBasedReply = (message: string, ctx: ChatContext): string => {
  const text = message.toLowerCase();
  const hi = ctx.locale === 'hi';
  const menu = available(ctx.menu);
  const active = ctx.orders.find((o) => !['delivered', 'cancelled'].includes(o.status));

  if (/order|status|track|kahan|कहाँ|ऑर्डर/.test(text) && /order|track|status|kahan|कहाँ|ऑर्डर/.test(text)) {
    if (/track|status|kahan|कहाँ/.test(text)) {
      if (!ctx.isAuthenticated) {
        return hi
          ? 'ऑर्डर की जानकारी देखने के लिए कृपया साइन इन करें।'
          : 'Please sign in so I can look up your order — I can only share order details with the account that placed them.';
      }
      if (!active) {
        const last = ctx.orders[0];
        return last
          ? hi
            ? `अभी कोई चालू ऑर्डर नहीं है। आपका पिछला ऑर्डर #${last.orderNumber} ${last.status} था।`
            : `You have no active orders right now. Your most recent order #${last.orderNumber} is ${last.status.replace(/_/g, ' ')}.`
          : hi
            ? 'आपके खाते में अभी कोई ऑर्डर नहीं है।'
            : 'I don’t see any orders on your account yet.';
      }
      return hi
        ? `ऑर्डर #${active.orderNumber} अभी "${active.status.replace(/_/g, ' ')}" है। पूरी टाइमलाइन ऑर्डर स्क्रीन पर देखें।`
        : `Order #${active.orderNumber} is currently “${active.status.replace(/_/g, ' ')}”. Open Orders → this order for the live timeline.`;
    }
  }

  if (/veg|vegetarian|शाकाहारी/.test(text)) {
    const veg = menu.filter((m) => m.isVeg).slice(0, 6);
    return hi
      ? `हमारे शाकाहारी विकल्प: ${veg.map(fmt).join(', ')}.`
      : `Our vegetarian options include: ${veg.map(fmt).join(', ')}. Ask me about any allergen and I’ll check the dish details.`;
  }

  if (/non[- ]?veg|chicken|mutton|fish|मटन|चिकन/.test(text)) {
    const nv = menu.filter((m) => !m.isVeg).slice(0, 6);
    return nv.length
      ? hi
        ? `नॉन-वेज विकल्प: ${nv.map(fmt).join(', ')}.`
        : `Non-vegetarian picks: ${nv.map(fmt).join(', ')}.`
      : hi
        ? 'अभी नॉन-वेज व्यंजन उपलब्ध नहीं हैं।'
        : 'No non-vegetarian dishes are available right now.';
  }

  if (/nut|peanut|allerg|gluten|dairy|egg|एलर्जी/.test(text)) {
    const flagged = menu.filter((m) => m.allergens.length > 0).slice(0, 6);
    return hi
      ? `हमारी रसोई में डेयरी, नट्स, ग्लूटेन और अंडा इस्तेमाल होता है। एलर्जी वाले व्यंजन: ${flagged
          .map((m) => `${m.name} (${m.allergens.join(', ')})`)
          .join('; ')}. गंभीर एलर्जी के लिए ऑर्डर से पहले हमें कॉल करें।`
      : `Our kitchen handles dairy, nuts, gluten and egg, so cross-contact is possible. Dishes with listed allergens: ${flagged
          .map((m) => `${m.name} (${m.allergens.join(', ')})`)
          .join('; ')}. For a severe allergy please call us before ordering.`;
  }

  if (/special|today|recommend|suggest|popular|best|क्या|सुझाव|स्पेशल/.test(text)) {
    const specials = menu.filter((m) => m.isSpecial).slice(0, 4);
    const picks = specials.length ? specials : [...menu].sort((a, b) => b.rating - a.rating).slice(0, 4);
    return hi
      ? `आज के सुझाव: ${picks.map(fmt).join(', ')}. बताइए कितने लोग हैं और कितना तीखा पसंद है।`
      : `Today’s picks: ${picks.map(fmt).join(', ')}. Tell me your party size and spice preference if you want a sharper recommendation.`;
  }

  if (/book|table|reservation|बुक|टेबल/.test(text)) {
    const today = ctx.hours.find((h) => h.day === new Date().getDay());
    return hi
      ? `टेबल बुक करने के लिए ऐप में Table Booking खोलें। आज का समय: ${today?.opensAt ?? '09:00'}–${today?.closesAt ?? '23:00'}.`
      : `Open Table Booking in the app to pick a date, slot and party size — we only confirm tables that are actually free. Today we’re open ${today?.opensAt ?? '09:00'}–${today?.closesAt ?? '23:00'}.`;
  }

  if (/hour|open|close|timing|समय|खुल/.test(text)) {
    return hi
      ? `खुलने का समय: ${ctx.hours.map((h) => `${DAYS[h.day]} ${h.opensAt}–${h.closesAt}`).join(', ')}.`
      : `Opening hours: ${ctx.hours.map((h) => `${DAYS[h.day]} ${h.opensAt}–${h.closesAt}`).join(', ')}. Kitchen takes last orders 45 minutes before closing.`;
  }

  if (/human|support|contact|call|staff|मदद|संपर्क/.test(text)) {
    return hi
      ? 'हमें +91 98765 43210 पर कॉल करें या Help & Support से ईमेल करें — हम 5 मिनट में जवाब देते हैं।'
      : 'You can call us on +91 98765 43210 or email support@thegrove.in — we usually reply within 5 minutes during opening hours.';
  }

  if (/price|cost|rate|कीमत/.test(text)) {
    return hi
      ? `मुख्य व्यंजन: ${menu.slice(0, 5).map(fmt).join(', ')}. पूरा मेनू Menu टैब में है।`
      : `Popular prices: ${menu.slice(0, 5).map(fmt).join(', ')}. The full menu with live prices is in the Menu tab.`;
  }

  return hi
    ? `मैं मेनू, समय, एलर्जी, टेबल बुकिंग और आपके ऑर्डर में मदद कर सकता हूँ। जैसे: "${menu[0] ? menu[0].name : 'आज का स्पेशल'} कैसा है?"`
    : `I can help with the menu, opening hours, allergens, table bookings and your order status. Try “What’s today’s special?” or “Track my order”. If I can’t help, I’ll connect you to the team.`;
};

/** Compact, factual context for the LLM. It never includes other customers' data. */
const buildSystemPrompt = (ctx: ChatContext): string => {
  const menuLines = ctx.menu.map(
    (m) =>
      `- ${m.name} | ₹${(m.discountedPriceMinor ?? m.priceMinor) / 100} | ${m.isVeg ? 'veg' : 'non-veg'} | ${
        m.isAvailable ? 'available' : 'sold out'
      } | allergens: ${m.allergens.join(', ') || 'none listed'} | rating ${m.rating}`,
  );
  const hours = ctx.hours.map((h) => `${DAYS[h.day]} ${h.opensAt}-${h.closesAt}`);
  const orders = ctx.orders.slice(0, 3).map((o) => ({
    number: o.orderNumber,
    status: o.status,
    type: o.type,
    total: `₹${o.totals.grandTotalMinor / 100}`,
    items: o.items.map((i) => i.name),
  }));

  return `You are the assistant for The Grove Restaurant & Cafe in New Delhi ("Good Food • Good Mood").
Rules:
- Answer ONLY from the RESTAURANT DATA below. Never invent dishes, prices, order statuses, reservation availability or payment results.
- If data is missing, say you don't have that detail and offer human support (+91 98765 43210 / support@thegrove.in).
- Recommend only dishes marked available.
- Never reveal another customer's data. Order data below belongs to the signed-in customer only; if none, ask them to sign in.
- Reply in ${ctx.locale === 'hi' ? 'Hindi (Devanagari)' : 'English'}, in 2-5 short sentences. Be warm, never pushy.
- You cannot place orders, take payments, confirm bookings or cancel orders. Direct the customer to the relevant screen.

RESTAURANT DATA
Menu:
${menuLines.join('\n')}
Opening hours: ${hours.join('; ')}
Policies: 5% GST; free delivery above ₹499; minimum delivery order ₹199; delivery fee ₹40; platform fee ₹20.
Cancellation: free while pending/confirmed; after preparation, call the restaurant.
Allergies: kitchen handles dairy, nuts, gluten, egg and soy; cross-contact possible.

CUSTOMER
Authenticated: ${ctx.isAuthenticated ? 'yes' : 'no'}${ctx.customerName ? ` (${ctx.customerName})` : ''}
Recent orders: ${orders.length ? JSON.stringify(orders) : 'none'}`;
};

export interface ChatResult {
  text: string;
  provider: 'ai' | 'rules';
}

export const generateReply = async (message: string, ctx: ChatContext): Promise<ChatResult> => {
  if (!config.aiEnabled) return { text: ruleBasedReply(message, ctx), provider: 'rules' };

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12_000);
    const res = await fetch(`${config.OPENAI_BASE_URL.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${config.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: config.OPENAI_MODEL,
        temperature: 0.3,
        max_tokens: 320,
        messages: [
          { role: 'system', content: buildSystemPrompt(ctx) },
          { role: 'user', content: message },
        ],
      }),
    });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`AI provider returned ${res.status}`);
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error('Empty AI response');
    return { text, provider: 'ai' };
  } catch (err) {
    console.warn('[chat] AI failed, using rule-based fallback:', (err as Error).message);
    return { text: ruleBasedReply(message, ctx), provider: 'rules' };
  }
};
