import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { config } from '../config.js';
import { AppError } from './http.js';

/**
 * Server-side Supabase access.
 *
 * - `admin`: service-role client. Bypasses RLS, so every route MUST scope
 *   queries by the authenticated user id itself. Never expose this key.
 * - `anon`: used only for password grant / reset email calls.
 * - `userClient(token)`: request-scoped client that honours RLS, used for
 *   defence-in-depth reads where ownership matters.
 */
const create = (key: string): SupabaseClient =>
  createClient(config.SUPABASE_URL!, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { 'x-application-name': 'the-grove-api' } },
  });

let adminClient: SupabaseClient | null = null;
let anonClient: SupabaseClient | null = null;

export const db = (): SupabaseClient => {
  if (!config.SUPABASE_URL || !config.SUPABASE_SERVICE_ROLE_KEY) {
    throw new AppError(
      503,
      'not_configured',
      'The database is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.',
    );
  }
  adminClient ??= create(config.SUPABASE_SERVICE_ROLE_KEY);
  return adminClient;
};

export const authClient = (): SupabaseClient => {
  if (!config.SUPABASE_URL || !config.SUPABASE_ANON_KEY) {
    throw new AppError(503, 'not_configured', 'Supabase auth is not configured.');
  }
  anonClient ??= create(config.SUPABASE_ANON_KEY);
  return anonClient;
};

export const userClient = (accessToken: string): SupabaseClient => {
  if (!config.SUPABASE_URL || !config.SUPABASE_ANON_KEY) {
    throw new AppError(503, 'not_configured', 'Supabase auth is not configured.');
  }
  return createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${accessToken}` } },
  });
};

export const isConfigured = (): boolean =>
  Boolean(config.SUPABASE_URL && config.SUPABASE_SERVICE_ROLE_KEY);
