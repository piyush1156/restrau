import type { Request } from 'express';
import { db } from './supabase.js';

/**
 * Records an administrative change. Failures are logged but never block the
 * operation itself — an audit outage must not take the restaurant offline.
 */
export const audit = async (
  req: Request,
  action: string,
  entity: string,
  entityId?: string | null,
  before?: unknown,
  after?: unknown,
): Promise<void> => {
  try {
    await db().from('audit_logs').insert({
      actor_id: req.user?.id ?? null,
      action,
      entity,
      entity_id: entityId ?? null,
      before: before ?? null,
      after: after ?? null,
      ip: req.ip ?? null,
    });
  } catch (err) {
    console.warn('[audit] failed to write audit log', (err as Error).message);
  }
};
