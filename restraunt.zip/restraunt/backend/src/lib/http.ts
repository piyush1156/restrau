import type { NextFunction, Request, Response } from 'express';
import type { ZodSchema } from 'zod';
import { ZodError } from 'zod';

/** Every API error is shaped as { error: { code, message, details? } }. */
export class AppError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }

  static badRequest(message: string, details?: unknown) {
    return new AppError(400, 'bad_request', message, details);
  }
  static unauthorized(message = 'Please sign in to continue.') {
    return new AppError(401, 'unauthorized', message);
  }
  static forbidden(message = 'You do not have permission to do that.') {
    return new AppError(403, 'forbidden', message);
  }
  static notFound(message = 'Not found.') {
    return new AppError(404, 'not_found', message);
  }
  static conflict(message: string, details?: unknown) {
    return new AppError(409, 'conflict', message, details);
  }
  static tooMany(message = 'Too many requests. Please wait a moment.') {
    return new AppError(429, 'rate_limited', message);
  }
  static unavailable(message = 'Service temporarily unavailable.') {
    return new AppError(503, 'unavailable', message);
  }
}

export const asyncHandler =
  <T>(fn: (req: Request, res: Response, next: NextFunction) => Promise<T>) =>
  (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };

export const parseBody = <T>(schema: ZodSchema<T>, value: unknown): T => {
  const result = schema.safeParse(value);
  if (!result.success) {
    const fieldErrors = result.error.flatten();
    throw AppError.badRequest('Please check the highlighted fields.', fieldErrors);
  }
  return result.data;
};

export const parseQuery = <T>(schema: ZodSchema<T>, value: unknown): T => {
  const result = schema.safeParse(value);
  if (!result.success) {
    throw AppError.badRequest('Invalid query parameters.', result.error.flatten());
  }
  return result.data;
};

export const errorHandler = (
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction,
): void => {
  if (err instanceof ZodError) {
    res.status(400).json({
      error: { code: 'validation_error', message: 'Invalid request.', details: err.flatten() },
    });
    return;
  }

  if (err instanceof AppError) {
    res.status(err.status).json({
      error: { code: err.code, message: err.message, details: err.details },
    });
    return;
  }

  // Supabase / Postgres errors bubble up with a code and message.
  const pg = err as { code?: string; message?: string; details?: string };
  if (pg?.code === '23505') {
    res.status(409).json({
      error: { code: 'conflict', message: 'That record already exists.' },
    });
    return;
  }

  const message = pg?.message ?? 'Something went wrong.';
  console.error(`[error] ${req.method} ${req.originalUrl}`, {
    message,
    code: pg?.code,
    // never log tokens, passwords or payment secrets
    body: redact(req.body),
  });

  res.status(500).json({
    error: {
      code: 'internal_error',
      message: 'We could not complete that request. Please try again.',
    },
  });
};

const SENSITIVE = ['password', 'token', 'authorization', 'signature', 'otp', 'secret', 'cvv'];

export const redact = (value: unknown): unknown => {
  if (!value || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(redact);
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>).map(([k, v]) => [
      k,
      SENSITIVE.some((s) => k.toLowerCase().includes(s)) ? '[redacted]' : redact(v),
    ]),
  );
};

export const notFoundHandler = (_req: Request, res: Response): void => {
  res.status(404).json({ error: { code: 'not_found', message: 'Route not found.' } });
};
