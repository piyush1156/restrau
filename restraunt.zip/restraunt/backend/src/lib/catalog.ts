import { DEFAULT_RESTAURANT_CONFIG, computeTotals, type Coupon, type MenuItem, type RestaurantConfig } from '@grove/shared';
import { db } from './supabase.js';
import { toCartLine, toCoupon, toMenuItem, type IncomingLine } from './mappers.js';
import { AppError } from './http.js';

/** Fees/tax config lives server-side; the client only displays it. */
export const restaurantConfig: RestaurantConfig = {
  ...DEFAULT_RESTAURANT_CONFIG,
  codEnabled: process.env.COD_ENABLED ? ['1', 'true', 'yes', 'on'].includes(process.env.COD_ENABLED.toLowerCase()) : true,
};

export const MENU_SELECT = `
  id, category_id, name, description, price_minor, discounted_price_minor, image_url,
  rating, review_count, is_veg, is_available, is_special, ingredients, allergens, prep_time_mins,
  categories ( slug ),
  item_add_ons ( add_ons ( id, name, price_minor, is_available ) )
`;

export const fetchMenuItems = async (params: { category?: string; search?: string; ids?: string[] }) => {
  let query = db().from('menu_items').select(MENU_SELECT).order('name', { ascending: true });
  if (params.ids?.length) query = query.in('id', params.ids);
  if (params.search?.trim()) {
    const term = params.search.trim().replace(/[%,()]/g, ' ');
    query = query.or(`name.ilike.%${term}%,description.ilike.%${term}%`);
  }
  const { data, error } = await query;
  if (error) throw AppError.unavailable('Could not load the menu right now.');

  let items = (data ?? []).map(toMenuItem);
  if (params.category && params.category !== 'all') {
    items = items.filter((m) => m.categorySlug === params.category || m.categoryId === params.category);
  }
  return items;
};

export const getMenuItemOrThrow = async (id: string): Promise<MenuItem> => {
  const { data, error } = await db().from('menu_items').select(MENU_SELECT).eq('id', id).maybeSingle();
  if (error) throw AppError.unavailable('Could not load this dish.');
  if (!data) throw AppError.notFound('That dish is no longer on the menu.');
  return toMenuItem(data);
};

export interface ValidationResult {
  lines: ReturnType<typeof toCartLine>[];
  removed: { key: string; name: string; reason: 'unavailable' | 'price_changed' | 'removed_from_menu' }[];
}

/**
 * Re-price a cart against live menu data.
 * Prices, add-on prices and availability always come from the database.
 */
export const validateCart = async (incoming: IncomingLine[]): Promise<ValidationResult> => {
  const ids = [...new Set(incoming.map((l) => l.menuItemId))];
  const items = ids.length ? await fetchMenuItems({ ids }) : [];
  const byId = new Map(items.map((i) => [i.id, i]));
  const removed: ValidationResult['removed'] = [];
  const lines: ValidationResult['lines'] = [];

  for (const line of incoming) {
    const item = byId.get(line.menuItemId);
    if (!item) {
      removed.push({ key: line.key, name: line.name, reason: 'removed_from_menu' });
      continue;
    }
    if (!item.isAvailable) {
      removed.push({ key: line.key, name: line.name, reason: 'unavailable' });
      continue;
    }
    const repriced = toCartLine(line, item);
    if (repriced.unitPriceMinor !== line.unitPriceMinor) {
      removed.push({ key: line.key, name: line.name, reason: 'price_changed' });
    }
    lines.push(repriced);
  }

  return { lines, removed };
};

export const findCoupon = async (code: string): Promise<Coupon | null> => {
  const { data, error } = await db()
    .from('coupons')
    .select('*')
    .ilike('code', code.trim())
    .maybeSingle();
  if (error) throw AppError.unavailable('Could not check that coupon.');
  return data ? toCoupon(data) : null;
};

export const priceOrder = (lines: ReturnType<typeof toCartLine>[], coupon: Coupon | null, orderType: 'delivery' | 'takeaway' | 'dine_in') =>
  computeTotals({ lines, coupon, config: restaurantConfig, orderType });

export type { IncomingLine };
