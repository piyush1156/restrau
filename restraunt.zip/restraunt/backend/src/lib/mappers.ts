import type {
  Address,
  AddOn,
  CartLine,
  Category,
  Coupon,
  MenuItem,
  Order,
  OrderItem,
  OrderTotals,
  Profile,
  Reservation,
  RestaurantTable,
  Role,
} from '@grove/shared';

/* eslint-disable @typescript-eslint/no-explicit-any */

export const toProfile = (row: any): Profile => ({
  id: row.id,
  fullName: row.full_name,
  email: row.email,
  phone: row.phone ?? null,
  role: (row.role ?? 'customer') as Role,
  locale: row.locale ?? 'en',
  avatarUrl: row.avatar_url ?? null,
  pushTokens: row.push_tokens ?? [],
  notifyOrderUpdates: row.notify_order_updates ?? true,
  notifyOffers: row.notify_offers ?? true,
  notifyReservations: row.notify_reservations ?? true,
  shareAnalytics: row.share_analytics ?? false,
  createdAt: row.created_at,
});

export const toAddress = (row: any): Address => ({
  id: row.id,
  label: row.label,
  line1: row.line1,
  line2: row.line2 ?? null,
  landmark: row.landmark ?? null,
  city: row.city,
  pincode: row.pincode,
  lat: row.lat != null ? Number(row.lat) : null,
  lng: row.lng != null ? Number(row.lng) : null,
  isDefault: Boolean(row.is_default),
});

export const toCategory = (row: any): Category => ({
  id: row.id,
  name: row.name,
  slug: row.slug,
  sortOrder: row.sort_order ?? 0,
});

export const toMenuItem = (row: any): MenuItem => {
  const linked = (row.item_add_ons ?? []) as any[];
  const addOns: AddOn[] = linked
    .map((l) => l.add_ons ?? l)
    .filter(Boolean)
    .map((a: any) => ({
      id: a.id,
      name: a.name,
      priceMinor: a.price_minor,
      isAvailable: a.is_available ?? true,
    }));

  return {
    id: row.id,
    categoryId: row.category_id,
    categorySlug: row.categories?.slug ?? row.category_slug ?? undefined,
    name: row.name,
    description: row.description,
    priceMinor: row.price_minor,
    discountedPriceMinor: row.discounted_price_minor ?? null,
    imageUrl: row.image_url,
    rating: Number(row.rating ?? 4.5),
    reviewCount: row.review_count ?? 0,
    isVeg: Boolean(row.is_veg),
    isAvailable: Boolean(row.is_available),
    isSpecial: Boolean(row.is_special),
    ingredients: row.ingredients ?? [],
    allergens: row.allergens ?? [],
    addOns,
    prepTimeMins: row.prep_time_mins ?? undefined,
  };
};

export const toCoupon = (row: any): Coupon => ({
  code: row.code,
  description: row.description,
  discountPercent: row.discount_percent ?? undefined,
  discountFlatMinor: row.discount_flat_minor ?? undefined,
  maxDiscountMinor: row.max_discount_minor ?? null,
  minOrderMinor: row.min_order_minor ?? 0,
  expiresAt: row.expires_at,
  isActive: Boolean(row.is_active),
  usageLimit: row.usage_limit ?? null,
  usedCount: row.used_count ?? 0,
});

export const toOrderItem = (row: any): OrderItem => ({
  id: row.id,
  menuItemId: row.menu_item_id ?? null,
  name: row.name,
  imageUrl: row.image_url,
  quantity: row.quantity,
  unitPriceMinor: row.unit_price_minor,
  addOns: Array.isArray(row.add_ons) ? row.add_ons : [],
  specialInstructions: row.special_instructions ?? null,
});

export const toOrderTotals = (row: any): OrderTotals => ({
  itemsTotalMinor: row.items_total_minor,
  subtotalMinor: row.items_total_minor,
  discountMinor: row.discount_minor,
  taxesMinor: row.taxes_minor,
  deliveryFeeMinor: row.delivery_fee_minor,
  platformFeeMinor: row.platform_fee_minor,
  grandTotalMinor: row.grand_total_minor,
});

export const toOrder = (
  row: any,
  items: any[] = [],
  extras: { partner?: { id: string; name: string; phone: string; vehicle?: string | null } | null } = {},
): Order => ({
  id: row.id,
  orderNumber: row.order_number,
  userId: row.user_id,
  customerName: row.profiles?.full_name ?? row.customer_name ?? 'Customer',
  customerPhone: row.contact_phone,
  type: row.type,
  status: row.status,
  paymentMethod: row.payment_method,
  paymentStatus: row.payment_status,
  items: items.map(toOrderItem),
  totals: toOrderTotals(row),
  address: row.address_snapshot ? (row.address_snapshot as Address) : null,
  deliveryInstructions: row.delivery_instructions ?? null,
  couponCode: row.coupon_code ?? null,
  deliveryPartner: extras.partner ?? null,
  estimatedAt: row.estimated_at ?? null,
  cancelReason: row.cancel_reason ?? null,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

export const toReservation = (row: any): Reservation => ({
  id: row.id,
  code: row.code,
  userId: row.user_id,
  customerName: row.profiles?.full_name ?? row.customer_name ?? 'Customer',
  customerPhone: row.profiles?.phone ?? row.customer_phone ?? '',
  date: row.reservation_date,
  time: String(row.reservation_time).slice(0, 5),
  guests: row.guests,
  seating: row.seating,
  tableNumber: row.restaurant_tables?.table_number ?? null,
  specialRequests: row.special_requests ?? null,
  status: row.status,
  createdAt: row.created_at,
});

export const toTable = (row: any): RestaurantTable => ({
  id: row.id,
  tableNumber: row.table_number,
  capacity: row.capacity,
  seating: row.seating,
  is_active: Boolean(row.is_active),
});

/** Cart lines sent by the client are untrusted; this is the shape we accept. */
export interface IncomingLine {
  key: string;
  menuItemId: string;
  name: string;
  imageUrl: string;
  unitPriceMinor: number;
  quantity: number;
  specialInstructions?: string;
  addOns: { id: string; name: string; priceMinor: number }[];
}

export const toCartLine = (line: IncomingLine, item: MenuItem): CartLine => ({
  key: line.key,
  menuItemId: item.id,
  name: item.name,
  imageUrl: item.imageUrl,
  unitPriceMinor:
    (item.discountedPriceMinor ?? item.priceMinor) +
    line.addOns.reduce((sum, a) => {
      const live = item.addOns.find((x) => x.id === a.id);
      return sum + (live?.priceMinor ?? 0);
    }, 0),
  addOns: line.addOns
    .filter((a) => item.addOns.some((x) => x.id === a.id))
    .map((a) => {
      const live = item.addOns.find((x) => x.id === a.id)!;
      return { id: live.id, name: live.name, priceMinor: live.priceMinor };
    }),
  quantity: line.quantity,
  specialInstructions: line.specialInstructions,
});
