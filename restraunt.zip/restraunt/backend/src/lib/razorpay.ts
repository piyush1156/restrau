import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from './http.js';

const API = 'https://api.razorpay.com/v1';

const authHeader = (): string => {
  if (!config.RAZORPAY_KEY_ID || !config.RAZORPAY_KEY_SECRET) {
    throw AppError.unavailable('Online payments are not configured. Please choose Cash on Delivery.');
  }
  return `Basic ${Buffer.from(`${config.RAZORPAY_KEY_ID}:${config.RAZORPAY_KEY_SECRET}`).toString('base64')}`;
};

const call = async <T>(path: string, init: RequestInit = {}): Promise<T> => {
  const res = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      Authorization: authHeader(),
      ...(init.headers ?? {}),
    },
  });
  const text = await res.text();
  const body = text ? JSON.parse(text) : {};
  if (!res.ok) {
    const message: string = body?.error?.description ?? 'Razorpay request failed.';
    // Card data never reaches us; only these provider-side errors are surfaced.
    throw new AppError(502, 'payment_provider_error', message);
  }
  return body as T;
};

export interface RazorpayOrder {
  id: string;
  amount: number;
  currency: string;
  receipt?: string;
  status: string;
}

export const createRazorpayOrder = (input: {
  amountMinor: number;
  receipt: string;
  notes?: Record<string, string>;
}): Promise<RazorpayOrder> =>
  call<RazorpayOrder>('/orders', {
    method: 'POST',
    body: JSON.stringify({
      amount: input.amountMinor,
      currency: 'INR',
      receipt: input.receipt,
      payment_capture: 1,
      notes: input.notes ?? {},
    }),
  });

export interface RazorpayPayment {
  id: string;
  order_id: string;
  amount: number;
  currency: string;
  status: 'created' | 'authorized' | 'captured' | 'refunded' | 'failed';
  method?: string;
  error_description?: string;
}

export const fetchRazorpayPayment = (paymentId: string): Promise<RazorpayPayment> =>
  call<RazorpayPayment>(`/payments/${paymentId}`);

/**
 * Razorpay signs `razorpay_order_id|razorpay_payment_id` with the key secret.
 * Uses a timing-safe comparison so signatures cannot be brute-forced.
 */
export const verifyPaymentSignature = (input: {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  signature: string;
}): boolean => {
  if (!config.RAZORPAY_KEY_SECRET) return false;
  const expected = crypto
    .createHmac('sha256', config.RAZORPAY_KEY_SECRET)
    .update(`${input.razorpayOrderId}|${input.razorpayPaymentId}`)
    .digest('hex');
  return safeEqual(expected, input.signature);
};

/** Webhooks are signed over the raw request body. */
export const verifyWebhookSignature = (rawBody: Buffer | string, signature: string): boolean => {
  if (!config.RAZORPAY_WEBHOOK_SECRET) return false;
  const expected = crypto
    .createHmac('sha256', config.RAZORPAY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return safeEqual(expected, signature);
};

const safeEqual = (a: string, b: string): boolean => {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b ?? '', 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
};

/** Public key id for the mobile SDK (safe to expose). */
export const publicKeyId = (): string =>
  config.RAZORPAY_PUBLIC_KEY_ID || config.RAZORPAY_KEY_ID || 'rzp_demo_key';
