import { Router } from 'express';
import { loginSchema, registerSchema, forgotPasswordSchema } from '@grove/shared';
import { z } from 'zod';
import { config } from '../config.js';
import { authClient, db } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody } from '../lib/http.js';
import { requireAuth } from '../middleware/auth.js';
import { toProfile } from '../lib/mappers.js';
import { audit } from '../lib/audit.js';

export const authRouter = Router();

const profileSelect =
  'id, full_name, email, phone, role, locale, avatar_url, push_tokens, notify_order_updates, notify_offers, notify_reservations, share_analytics, created_at';

authRouter.post(
  '/register',
  asyncHandler(async (req, res) => {
    const input = parseBody(registerSchema, req.body);

    const { data: created, error: createError } = await db().auth.admin.createUser({
      email: input.email,
      password: input.password,
      email_confirm: true,
      user_metadata: { full_name: input.fullName, phone: input.phone },
    });
    if (createError || !created.user) {
      const conflict = /already|exists/i.test(createError?.message ?? '');
      throw conflict
        ? AppError.conflict('An account with this email already exists. Try signing in.')
        : AppError.badRequest(createError?.message ?? 'Could not create your account.');
    }

    const { error: profileError } = await db().from('profiles').insert({
      id: created.user.id,
      full_name: input.fullName,
      email: input.email,
      phone: input.phone,
      role: 'customer',
      locale: 'en',
    });
    if (profileError) {
      // roll back the auth user so the email is not left in a half-created state
      await db().auth.admin.deleteUser(created.user.id);
      throw AppError.unavailable('Could not finish creating your profile. Please try again.');
    }

    const { data: signIn, error: signInError } = await authClient().auth.signInWithPassword({
      email: input.email,
      password: input.password,
    });
    if (signInError || !signIn.session) throw AppError.unavailable('Account created — please sign in.');

    const { data: profile } = await db().from('profiles').select(profileSelect).eq('id', created.user.id).single();

    res.status(201).json({
      profile: toProfile(profile),
      token: signIn.session.access_token,
      expiresAt: signIn.session.expires_at,
    });
  }),
);

authRouter.post(
  '/login',
  asyncHandler(async (req, res) => {
    const input = parseBody(loginSchema, req.body);
    const identifier = input.identifier.trim();

    // Accept either an email or a 10-digit mobile number.
    let email = identifier;
    if (!identifier.includes('@')) {
      const { data: profile } = await db()
        .from('profiles')
        .select('email')
        .eq('phone', identifier.replace(/\D/g, ''))
        .maybeSingle();
      if (!profile) throw AppError.unauthorized('Incorrect email/phone or password.');
      email = profile.email;
    }

    const { data, error } = await authClient().auth.signInWithPassword({ email, password: input.password });
    if (error || !data.session || !data.user) {
      throw AppError.unauthorized('Incorrect email/phone or password.');
    }

    const { data: profile, error: profileError } = await db()
      .from('profiles')
      .select(profileSelect)
      .eq('id', data.user.id)
      .maybeSingle();

    if (profileError || !profile) throw AppError.unauthorized('Your profile is missing. Contact support.');

    res.json({
      profile: toProfile(profile),
      token: data.session.access_token,
      expiresAt: data.session.expires_at,
    });
  }),
);

/**
 * Tokens are stateless JWTs. The client discards its token; this endpoint
 * exists so the app has a single, explicit sign-out call to make.
 */
authRouter.post(
  '/logout',
  requireAuth,
  asyncHandler(async (req, res) => {
    await audit(req, 'auth.logout', 'profile', req.user!.id);
    res.json({ ok: true });
  }),
);

authRouter.post(
  '/reset-password',
  asyncHandler(async (req, res) => {
    const { email } = parseBody(forgotPasswordSchema, req.body);

    // Always return 200 so the endpoint cannot be used to enumerate accounts.
    const { error } = await authClient().auth.resetPasswordForEmail(email, {
      redirectTo: config.PASSWORD_RESET_REDIRECT_URL,
    });
    if (error) console.warn('[auth] reset-password dispatch failed', error.message);

    res.json({ ok: true, message: 'If that email is registered, a reset link is on its way.' });
  }),
);

authRouter.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { data, error } = await db().from('profiles').select(profileSelect).eq('id', req.user!.id).single();
    if (error) throw AppError.unavailable('Could not load your profile.');
    res.json(toProfile(data));
  }),
);

const profilePatchSchema = z
  .object({
    fullName: z.string().trim().min(2).max(80).optional(),
    phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number').nullable().optional(),
    avatarUrl: z.string().url().max(500).nullable().optional(),
    locale: z.enum(['en', 'hi']).optional(),
    pushTokens: z.array(z.string().max(200)).max(5).optional(),
    notifyOrderUpdates: z.boolean().optional(),
    notifyOffers: z.boolean().optional(),
    notifyReservations: z.boolean().optional(),
    shareAnalytics: z.boolean().optional(),
  })
  .strict();

authRouter.patch(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const patch = parseBody(profilePatchSchema, req.body);
    const update: Record<string, unknown> = {};
    if (patch.fullName !== undefined) update.full_name = patch.fullName;
    if (patch.phone !== undefined) update.phone = patch.phone;
    if (patch.avatarUrl !== undefined) update.avatar_url = patch.avatarUrl;
    if (patch.locale !== undefined) update.locale = patch.locale;
    if (patch.pushTokens !== undefined) update.push_tokens = patch.pushTokens;
    if (patch.notifyOrderUpdates !== undefined) update.notify_order_updates = patch.notifyOrderUpdates;
    if (patch.notifyOffers !== undefined) update.notify_offers = patch.notifyOffers;
    if (patch.notifyReservations !== undefined) update.notify_reservations = patch.notifyReservations;
    if (patch.shareAnalytics !== undefined) update.share_analytics = patch.shareAnalytics;

    if (Object.keys(update).length === 0) throw AppError.badRequest('Nothing to update.');

    const { data, error } = await db()
      .from('profiles')
      .update(update)
      .eq('id', req.user!.id)
      .select(profileSelect)
      .single();
    if (error) throw AppError.unavailable('Could not save your profile.');

    res.json(toProfile(data));
  }),
);

/** Account deletion request (7-day grace period, handled by staff/cron). */
authRouter.post(
  '/delete-request',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { error } = await db()
      .from('profiles')
      .update({ deletion_requested_at: new Date().toISOString() })
      .eq('id', req.user!.id);
    if (error) throw AppError.unavailable('Could not record your request.');
    await audit(req, 'profile.deletion_requested', 'profile', req.user!.id);
    res.json({ ok: true, message: 'Deletion requested. We will confirm by email within 7 days.' });
  }),
);
