import { Router } from 'express';
import {
  adminCouponSchema,
  adminMenuItemSchema,
  adminOrderStatusSchema,
  adminReservationStatusSchema,
  canRoleSetStatus,
  canTransition,
  canTransitionReservation,
  formatMinor,
  type OrderStatus,
} from '@grove/shared';
import { z } from 'zod';
import { db } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody } from '../lib/http.js';
import { requireAdmin, requireStaff } from '../middleware/auth.js';
import { toCoupon, toOrder, toReservation, toTable } from '../lib/mappers.js';
import { audit } from '../lib/audit.js';
import { notifyUser } from '../lib/notifications.js';
import { estimateMinutes } from './orders.js';

export const adminRouter = Router();
adminRouter.use(requireStaff);

/* --------------------------------------------------------------- dashboard */

adminRouter.get(
  '/admin/dashboard',
  asyncHandler(async (_req, res) => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const { data: orders, error } = await db()
      .from('orders')
      .select('id, status, payment_status, grand_total_minor, created_at, type, order_number, contact_phone')
      .gte('created_at', new Date(Date.now() - 30 * 86400000).toISOString());
    if (error) throw AppError.unavailable('Could not load dashboard data.');

    const rows = orders ?? [];
    const todayRows = rows.filter((o) => new Date(o.created_at) >= todayStart);
    const paid = rows.filter((o) => o.payment_status === 'paid');

    const stats = {
      totalOrders: rows.length,
      todayOrders: todayRows.length,
      todayRevenueMinor: todayRows
        .filter((o) => o.payment_status === 'paid')
        .reduce((s, o) => s + o.grand_total_minor, 0),
      pendingOrders: rows.filter((o) => o.status === 'pending').length,
      preparingOrders: rows.filter((o) => ['confirmed', 'preparing'].includes(o.status)).length,
      completedOrders: rows.filter((o) => o.status === 'delivered').length,
      cancelledOrders: rows.filter((o) => o.status === 'cancelled').length,
      avgOrderValueMinor: paid.length
        ? Math.round(paid.reduce((s, o) => s + o.grand_total_minor, 0) / paid.length)
        : 0,
    };

    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(Date.now() - (6 - i) * 86400000);
      const label = d.toLocaleDateString('en-IN', { weekday: 'short' });
      const dayOrders = rows.filter((o) => new Date(o.created_at).toDateString() === d.toDateString());
      return {
        label,
        orders: dayOrders.length,
        revenueMinor: dayOrders
          .filter((o) => o.payment_status === 'paid')
          .reduce((s, o) => s + o.grand_total_minor, 0),
      };
    });

    const { data: topItems } = await db()
      .from('order_items')
      .select('name, quantity, order_id')
      .limit(500);

    const popularity = new Map<string, number>();
    (topItems ?? []).forEach((i: any) => popularity.set(i.name, (popularity.get(i.name) ?? 0) + i.quantity));
    const popularDishes = [...popularity.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, quantity]) => ({ name, quantity }));

    const { data: recent } = await db()
      .from('orders')
      .select('*, order_items(*)')
      .order('created_at', { ascending: false })
      .limit(8);

    res.json({
      stats,
      revenue: days,
      popularDishes,
      recentOrders: (recent ?? []).map((r: any) => toOrder(r, r.order_items ?? [])),
    });
  }),
);

/* ------------------------------------------------------------------ orders */

const orderListQuery = z.object({
  status: z.string().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  q: z.string().max(80).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(25),
});

adminRouter.get(
  '/admin/orders',
  asyncHandler(async (req, res) => {
    const q = orderListQuery.parse(req.query);
    let query = db().from('orders').select('*, order_items(*)', { count: 'exact' }).order('created_at', { ascending: false });

    if (q.status && q.status !== 'all') query = query.eq('status', q.status);
    if (q.from) query = query.gte('created_at', new Date(q.from).toISOString());
    if (q.to) query = query.lte('created_at', new Date(`${q.to}T23:59:59`).toISOString());
    if (q.q) {
      // strip PostgREST filter syntax characters so search terms cannot alter the query
      const term = q.q.replace(/[%,()]/g, ' ').trim();
      if (term) query = query.or(`order_number.ilike.%${term}%,contact_phone.ilike.%${term}%`);
    }

    const { data, error, count } = await query.range((q.page - 1) * q.pageSize, q.page * q.pageSize - 1);
    if (error) throw AppError.unavailable('Could not load orders.');

    res.json({
      data: (data ?? []).map((r: any) => toOrder(r, r.order_items ?? [])),
      page: q.page,
      pageSize: q.pageSize,
      total: count ?? 0,
    });
  }),
);

adminRouter.patch(
  '/admin/orders/:id/status',
  asyncHandler(async (req, res) => {
    const input = parseBody(adminOrderStatusSchema, req.body);
    const role = req.user!.role;

    const { data: order } = await db().from('orders').select('*').eq('id', req.params.id).maybeSingle();
    if (!order) throw AppError.notFound('Order not found.');

    if (!canRoleSetStatus(role, input.status)) {
      throw AppError.forbidden(`A ${role} cannot move an order to ${input.status}.`);
    }
    if (!canTransition(order.status, input.status)) {
      throw AppError.badRequest(`Cannot move an order from ${order.status} to ${input.status}.`);
    }
    if (input.status === 'cancelled' && !input.cancelReason) {
      throw AppError.badRequest('A cancellation reason is required.');
    }

    const patch: Record<string, unknown> = { status: input.status };
    if (input.cancelReason) patch.cancel_reason = input.cancelReason;
    if (input.status === 'confirmed' && !order.estimated_at) {
      patch.estimated_at = new Date(Date.now() + estimateMinutes(order.type) * 60_000).toISOString();
    }

    const { data: updated, error } = await db()
      .from('orders')
      .update(patch)
      .eq('id', order.id)
      .select('*')
      .single();
    if (error) throw AppError.unavailable('Could not update the order status.');

    await db().from('order_status_history').insert({
      order_id: order.id,
      status: input.status,
      changed_by: req.user!.id,
      note: input.cancelReason ?? `Marked ${input.status} by staff`,
    });
    await audit(req, 'order.status_changed', 'order', order.id, { status: order.status }, { status: input.status });

    void notifyUser({
      userId: order.user_id,
      title: input.status === 'cancelled' ? 'Order cancelled' : 'Order update',
      body:
        input.status === 'cancelled'
          ? `Order ${order.order_number} was cancelled: ${input.cancelReason}.`
          : `Order ${order.order_number} is now ${input.status.replace(/_/g, ' ')}.`,
      data: { orderId: order.id },
      category: 'order',
    });

    const { data: items } = await db().from('order_items').select('*').eq('order_id', order.id);
    res.json({ data: toOrder(updated, items ?? []) });
  }),
);

adminRouter.post(
  '/admin/orders/:id/assign',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { partnerId } = z.object({ partnerId: z.string().uuid() }).parse(req.body);
    const { data: order } = await db().from('orders').select('id, type, status').eq('id', req.params.id).maybeSingle();
    if (!order) throw AppError.notFound('Order not found.');
    if (order.type !== 'delivery') throw AppError.badRequest('Only delivery orders can be assigned.');
    if (order.status === 'cancelled') throw AppError.badRequest('This order is cancelled.');

    const { data: partner } = await db().from('profiles').select('id, role').eq('id', partnerId).maybeSingle();
    if (!partner || partner.role !== 'delivery') throw AppError.badRequest('That user is not delivery staff.');

    const { error } = await db()
      .from('delivery_assignments')
      .upsert({ order_id: order.id, partner_id: partnerId }, { onConflict: 'order_id' });
    if (error) throw AppError.unavailable('Could not assign the delivery partner.');

    await audit(req, 'order.delivery_assigned', 'order', order.id, null, { partnerId });
    res.json({ ok: true });
  }),
);

/* -------------------------------------------------------------------- menu */

adminRouter.get(
  '/admin/menu',
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const { data, error } = await db().from('menu_items').select('*').order('name');
    if (error) throw AppError.unavailable('Could not load the menu.');
    res.json({ data: data ?? [] });
  }),
);

adminRouter.post(
  '/admin/menu',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const input = parseBody(adminMenuItemSchema, req.body);
    const { data, error } = await db()
      .from('menu_items')
      .insert({
        category_id: input.categoryId,
        name: input.name,
        description: input.description,
        price_minor: input.priceMinor,
        discounted_price_minor: input.discountedPriceMinor ?? null,
        image_url: input.imageUrl,
        is_veg: input.isVeg,
        is_available: input.isAvailable,
        is_special: input.isSpecial,
        ingredients: input.ingredients,
        allergens: input.allergens,
      })
      .select('*')
      .single();
    if (error) throw AppError.badRequest('Could not create that dish. Check the category and prices.');

    await audit(req, 'menu.created', 'menu_item', data.id, null, data);
    res.status(201).json({ data });
  }),
);

adminRouter.patch(
  '/admin/menu/:id',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const input = parseBody(adminMenuItemSchema.partial(), req.body);
    const { data: before } = await db().from('menu_items').select('*').eq('id', req.params.id).maybeSingle();
    if (!before) throw AppError.notFound('Dish not found.');

    const patch: Record<string, unknown> = {};
    if (input.name !== undefined) patch.name = input.name;
    if (input.description !== undefined) patch.description = input.description;
    if (input.categoryId !== undefined) patch.category_id = input.categoryId;
    if (input.priceMinor !== undefined) patch.price_minor = input.priceMinor;
    if (input.discountedPriceMinor !== undefined) patch.discounted_price_minor = input.discountedPriceMinor;
    if (input.imageUrl !== undefined) patch.image_url = input.imageUrl;
    if (input.isVeg !== undefined) patch.is_veg = input.isVeg;
    if (input.isAvailable !== undefined) patch.is_available = input.isAvailable;
    if (input.isSpecial !== undefined) patch.is_special = input.isSpecial;
    if (input.ingredients !== undefined) patch.ingredients = input.ingredients;
    if (input.allergens !== undefined) patch.allergens = input.allergens;

    const { data, error } = await db().from('menu_items').update(patch).eq('id', req.params.id).select('*').single();
    if (error) throw AppError.badRequest('Could not update that dish.');
    await audit(req, 'menu.updated', 'menu_item', data.id, before, data);
    res.json({ data });
  }),
);

adminRouter.patch(
  '/admin/menu/:id/availability',
  asyncHandler(async (req, res) => {
    const { isAvailable } = z.object({ isAvailable: z.boolean() }).parse(req.body);
    const { data, error } = await db()
      .from('menu_items')
      .update({ is_available: isAvailable })
      .eq('id', req.params.id)
      .select('id, name, is_available')
      .single();
    if (error) throw AppError.unavailable('Could not update availability.');
    await audit(req, 'menu.availability_changed', 'menu_item', data.id, null, { isAvailable });
    res.json({ data });
  }),
);

adminRouter.delete(
  '/admin/menu/:id',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { data: before } = await db().from('menu_items').select('*').eq('id', req.params.id).maybeSingle();
    if (!before) throw AppError.notFound('Dish not found.');

    // Soft-delete: historical order items must keep their snapshot.
    const { error } = await db().from('menu_items').update({ is_available: false }).eq('id', req.params.id);
    if (error) throw AppError.unavailable('Could not remove that dish.');
    await audit(req, 'menu.removed', 'menu_item', req.params.id, before, { is_available: false });
    res.json({ ok: true, message: 'Dish hidden from the menu. Order history is preserved.' });
  }),
);

/* ---------------------------------------------------------------- coupons */

adminRouter.get(
  '/admin/coupons',
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const { data, error } = await db().from('coupons').select('*').order('created_at', { ascending: false });
    if (error) throw AppError.unavailable('Could not load coupons.');
    res.json({ data: (data ?? []).map(toCoupon) });
  }),
);

adminRouter.post(
  '/admin/coupons',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const input = parseBody(adminCouponSchema, req.body);
    const { data, error } = await db()
      .from('coupons')
      .insert({
        code: input.code,
        description: input.description,
        discount_percent: input.discountPercent ?? null,
        discount_flat_minor: input.discountFlatMinor ?? null,
        max_discount_minor: input.maxDiscountMinor ?? null,
        min_order_minor: input.minOrderMinor,
        expires_at: input.expiresAt,
        usage_limit: input.usageLimit ?? null,
        is_active: true,
      })
      .select('*')
      .single();
    if (error) throw AppError.conflict('That coupon code already exists.');
    await audit(req, 'coupon.created', 'coupon', data.id, null, data);
    res.status(201).json({ data: toCoupon(data) });
  }),
);

adminRouter.patch(
  '/admin/coupons/:id',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const patchSchema = z
      .object({
        description: z.string().trim().min(3).max(140).optional(),
        isActive: z.boolean().optional(),
        expiresAt: z.string().datetime({ offset: true }).optional(),
        usageLimit: z.number().int().min(1).nullable().optional(),
      })
      .strict();
    const input = parseBody(patchSchema, req.body);

    const patch: Record<string, unknown> = {};
    if (input.description !== undefined) patch.description = input.description;
    if (input.isActive !== undefined) patch.is_active = input.isActive;
    if (input.expiresAt !== undefined) patch.expires_at = input.expiresAt;
    if (input.usageLimit !== undefined) patch.usage_limit = input.usageLimit;

    const { data, error } = await db().from('coupons').update(patch).eq('id', req.params.id).select('*').single();
    if (error) throw AppError.unavailable('Could not update the coupon.');
    await audit(req, 'coupon.updated', 'coupon', data.id, null, patch);
    res.json({ data: toCoupon(data) });
  }),
);

/* ----------------------------------------------------------- reservations */

adminRouter.get(
  '/admin/reservations',
  asyncHandler(async (req, res) => {
    const date = typeof req.query.date === 'string' ? req.query.date : new Date().toISOString().slice(0, 10);
    const { data, error } = await db()
      .from('reservations')
      .select('*, profiles(full_name, phone), restaurant_tables(*)')
      .eq('reservation_date', date)
      .order('reservation_time');
    if (error) throw AppError.unavailable('Could not load reservations.');

    const { data: allTables } = await db().from('restaurant_tables').select('*').eq('is_active', true).order('table_number');

    res.json({
      date,
      data: (data ?? []).map(toReservation),
      tables: (allTables ?? []).map(toTable),
    });
  }),
);

adminRouter.patch(
  '/admin/reservations/:id/status',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const input = parseBody(adminReservationStatusSchema, req.body);
    const { data: existing } = await db().from('reservations').select('*').eq('id', req.params.id).maybeSingle();
    if (!existing) throw AppError.notFound('Reservation not found.');
    if (!canTransitionReservation(existing.status, input.status)) {
      throw AppError.badRequest(`Cannot move a reservation from ${existing.status} to ${input.status}.`);
    }

    const { data, error } = await db()
      .from('reservations')
      .update({ status: input.status })
      .eq('id', req.params.id)
      .select('*, restaurant_tables(table_number)')
      .single();
    if (error) throw AppError.unavailable('Could not update the reservation.');

    await audit(req, 'reservation.status_changed', 'reservation', data.id, { status: existing.status }, { status: input.status });
    void notifyUser({
      userId: existing.user_id,
      title: 'Reservation update',
      body: `Your table on ${existing.reservation_date} at ${String(existing.reservation_time).slice(0, 5)} is now ${input.status}.`,
      data: { reservationId: existing.id },
      category: 'reservation',
    });

    res.json({ data: toReservation(data) });
  }),
);

/* ----------------------------------------------------------------- reports */

const rangeQuery = z.object({
  from: z.string().optional(),
  to: z.string().optional(),
});

const loadRange = (query: z.infer<typeof rangeQuery>) => {
  const to = query.to ? new Date(`${query.to}T23:59:59`) : new Date();
  const from = query.from ? new Date(`${query.from}T00:00:00`) : new Date(to.getTime() - 29 * 86400000);
  return { from, to };
};

adminRouter.get(
  '/admin/reports',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { from, to } = loadRange(rangeQuery.parse(req.query));

    const { data: orders, error } = await db()
      .from('orders')
      .select('id, status, payment_status, grand_total_minor, created_at, type')
      .gte('created_at', from.toISOString())
      .lte('created_at', to.toISOString());
    if (error) throw AppError.unavailable('Could not build the report.');

    const rows = (orders ?? []).filter((o) => o.status !== 'cancelled');
    const paid = rows.filter((o) => o.payment_status === 'paid');

    const daily = new Map<string, { orders: number; revenueMinor: number }>();
    rows.forEach((o) => {
      const day = new Date(o.created_at).toISOString().slice(0, 10);
      const entry = daily.get(day) ?? { orders: 0, revenueMinor: 0 };
      entry.orders += 1;
      if (o.payment_status === 'paid') entry.revenueMinor += o.grand_total_minor;
      daily.set(day, entry);
    });

    const byType = new Map<string, number>();
    rows.forEach((o) => byType.set(o.type, (byType.get(o.type) ?? 0) + 1));

    const orderIds = rows.map((o) => o.id);
    const { data: items } = orderIds.length
      ? await db().from('order_items').select('name, quantity, unit_price_minor, order_id').in('order_id', orderIds)
      : { data: [] as any[] };

    const itemTotals = new Map<string, { quantity: number; revenueMinor: number }>();
    (items ?? []).forEach((i: any) => {
      const entry = itemTotals.get(i.name) ?? { quantity: 0, revenueMinor: 0 };
      entry.quantity += i.quantity;
      entry.revenueMinor += i.quantity * i.unit_price_minor;
      itemTotals.set(i.name, entry);
    });

    res.json({
      range: { from: from.toISOString(), to: to.toISOString() },
      totals: {
        orders: rows.length,
        paidOrders: paid.length,
        revenueMinor: paid.reduce((s, o) => s + o.grand_total_minor, 0),
        avgOrderValueMinor: paid.length
          ? Math.round(paid.reduce((s, o) => s + o.grand_total_minor, 0) / paid.length)
          : 0,
      },
      daily: [...daily.entries()].sort().map(([date, v]) => ({ date, ...v })),
      byType: [...byType.entries()].map(([type, count]) => ({ type, count })),
      topItems: [...itemTotals.entries()]
        .sort((a, b) => b[1].revenueMinor - a[1].revenueMinor)
        .slice(0, 10)
        .map(([name, v]) => ({ name, ...v })),
    });
  }),
);

adminRouter.get(
  '/admin/reports/export.csv',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const { from, to } = loadRange(rangeQuery.parse(req.query));
    const { data: orders, error } = await db()
      .from('orders')
      .select('order_number, created_at, type, status, payment_method, payment_status, items_total_minor, discount_minor, taxes_minor, delivery_fee_minor, platform_fee_minor, grand_total_minor, contact_phone')
      .gte('created_at', from.toISOString())
      .lte('created_at', to.toISOString())
      .order('created_at');
    if (error) throw AppError.unavailable('Could not export orders.');

    const header = [
      'order_number', 'created_at', 'type', 'status', 'payment_method', 'payment_status',
      'items_total', 'discount', 'taxes', 'delivery_fee', 'platform_fee', 'grand_total',
    ];
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = [header.join(',')];
    (orders ?? []).forEach((o: any) => {
      lines.push(
        [
          o.order_number,
          o.created_at,
          o.type,
          o.status,
          o.payment_method,
          o.payment_status,
          formatMinor(o.items_total_minor).replace('₹', ''),
          formatMinor(o.discount_minor).replace('₹', ''),
          formatMinor(o.taxes_minor).replace('₹', ''),
          formatMinor(o.delivery_fee_minor).replace('₹', ''),
          formatMinor(o.platform_fee_minor).replace('₹', ''),
          formatMinor(o.grand_total_minor).replace('₹', ''),
        ]
          .map(esc)
          .join(','),
      );
    });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="grove-orders-${from.toISOString().slice(0, 10)}.csv"`);
    res.send(lines.join('\n'));
  }),
);

/* ------------------------------------------------- customers and staff */

adminRouter.get(
  '/admin/customers',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q.slice(0, 60) : '';
    let query = db()
      .from('profiles')
      .select('id, full_name, email, phone, created_at, role')
      .eq('role', 'customer')
      .order('created_at', { ascending: false })
      .limit(50);
    const term = q.replace(/[%,()]/g, ' ').trim();
    if (term) query = query.or(`full_name.ilike.%${term}%,email.ilike.%${term}%,phone.ilike.%${term}%`);
    const { data, error } = await query;
    if (error) throw AppError.unavailable('Could not load customers.');
    res.json({ data: data ?? [] });
  }),
);

adminRouter.get(
  '/admin/staff',
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const { data, error } = await db()
      .from('staff_roles')
      .select('user_id, role, created_at, profiles(full_name, email)')
      .order('created_at');
    if (error) throw AppError.unavailable('Could not load staff roles.');
    res.json({ data: data ?? [] });
  }),
);

adminRouter.post(
  '/admin/staff',
  asyncHandler(async (req, res) => {
    if (req.user!.role !== 'owner') throw AppError.forbidden('Only the owner can change staff roles.');

    const input = z
      .object({ email: z.string().email(), role: z.enum(['owner', 'manager', 'kitchen', 'delivery']) })
      .parse(req.body);

    const { data: profile } = await db().from('profiles').select('id').eq('email', input.email).maybeSingle();
    if (!profile) throw AppError.notFound('No account with that email. Ask them to sign up first.');

    const { error } = await db()
      .from('staff_roles')
      .upsert({ user_id: profile.id, role: input.role, granted_by: req.user!.id }, { onConflict: 'user_id' });
    if (error) throw AppError.unavailable('Could not grant that role.');

    await db().from('profiles').update({ role: input.role }).eq('id', profile.id);
    await audit(req, 'staff.role_granted', 'profile', profile.id, null, { role: input.role });
    res.json({ ok: true });
  }),
);

adminRouter.get(
  '/admin/audit',
  requireAdmin,
  asyncHandler(async (_req, res) => {
    const { data, error } = await db()
      .from('audit_logs')
      .select('id, action, entity, entity_id, created_at, actor_id, profiles(full_name)')
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) throw AppError.unavailable('Could not load the audit log.');
    res.json({ data: data ?? [] });
  }),
);

export type { OrderStatus };
