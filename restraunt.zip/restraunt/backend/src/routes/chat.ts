import { Router } from 'express';
import { chatMessageSchema, ACTIVE_ORDER_STATUSES, type ChatMessage, type OpeningHour, type Order } from '@grove/shared';
import { db, isConfigured } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody } from '../lib/http.js';
import { optionalAuth } from '../middleware/auth.js';
import { generateReply } from '../lib/chat.js';
import { fetchMenuItems } from '../lib/catalog.js';
import { toOrder } from '../lib/mappers.js';

export const chatRouter = Router();

const loadHours = async (): Promise<OpeningHour[]> => {
  const { data } = await db().from('restaurant_opening_hours').select('*').order('day');
  return (data ?? []).map((r: any) => ({
    day: r.day,
    opensAt: String(r.opens_at).slice(0, 5),
    closesAt: String(r.closes_at).slice(0, 5),
    isClosed: r.is_closed,
  }));
};

const loadRecentOrders = async (userId: string): Promise<Order[]> => {
  const { data } = await db()
    .from('orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(5);
  const rows = data ?? [];
  const ids = rows.map((r) => r.id);
  const { data: items } = ids.length
    ? await db().from('order_items').select('*').in('order_id', ids)
    : { data: [] as any[] };
  const byOrder = new Map<string, any[]>();
  for (const item of items ?? []) byOrder.set(item.order_id, [...(byOrder.get(item.order_id) ?? []), item]);
  return rows.map((row) => toOrder(row, byOrder.get(row.id) ?? []));
};

/** Persist the exchange for human follow-up; never blocks the reply. */
const persistExchange = async (userId: string | null, question: string, answer: string): Promise<void> => {
  if (!userId) return;
  try {
    const { data: open } = await db()
      .from('support_conversations')
      .select('id')
      .eq('user_id', userId)
      .eq('status', 'open')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const conversationId =
      open?.id ??
      (
        await db()
          .from('support_conversations')
          .insert({ user_id: userId, subject: 'App assistant conversation' })
          .select('id')
          .single()
      ).data?.id;

    if (!conversationId) return;
    await db().from('support_messages').insert([
      { conversation_id: conversationId, role: 'user', user_id: userId, body: question },
      { conversation_id: conversationId, role: 'assistant', user_id: null, body: answer },
    ]);
  } catch (err) {
    console.warn('[chat] could not persist conversation', (err as Error).message);
  }
};

chatRouter.post(
  '/chat/messages',
  optionalAuth,
  asyncHandler(async (req, res) => {
    const { message } = parseBody(chatMessageSchema, req.body);
    if (!isConfigured()) throw AppError.unavailable('The assistant is not configured yet.');

    const [menu, hours] = await Promise.all([
      fetchMenuItems({}).catch(() => []),
      loadHours().catch(() => []),
    ]);
    const orders = req.user ? await loadRecentOrders(req.user.id).catch(() => []) : [];

    const { text } = await generateReply(message, {
      menu,
      hours,
      orders,
      isAuthenticated: Boolean(req.user),
      locale: req.user?.locale ?? 'en',
      customerName: req.user?.fullName,
    });

    const reply: ChatMessage = {
      id: `msg_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
      role: 'assistant',
      text,
      createdAt: new Date().toISOString(),
    };

    void persistExchange(req.user?.id ?? null, message, text);

    res.json(reply);
  }),
);

/** Lightweight status endpoint so the app can show "assistant online". */
chatRouter.get('/chat/status', (_req, res) => {
  res.json({ online: true });
});
