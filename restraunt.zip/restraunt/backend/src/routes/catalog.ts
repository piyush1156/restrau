import { Router } from 'express';
import { addressSchema, reviewSchema, couponCodeSchema } from '@grove/shared';
import { z } from 'zod';
import { db } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody } from '../lib/http.js';
import { requireAuth } from '../middleware/auth.js';
import { fetchMenuItems, findCoupon, getMenuItemOrThrow } from '../lib/catalog.js';
import { toAddress, toCategory, toCoupon, toMenuItem } from '../lib/mappers.js';
import { couponIsValid } from '@grove/shared';

export const catalogRouter = Router();

/* ------------------------------------------------------------------- menu */

catalogRouter.get(
  '/menu',
  asyncHandler(async (req, res) => {
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const search = typeof req.query.search === 'string' ? req.query.search.slice(0, 80) : undefined;
    const items = await fetchMenuItems({ category, search });
    res.json({ data: items });
  }),
);

catalogRouter.get(
  '/menu/categories',
  asyncHandler(async (_req, res) => {
    const { data, error } = await db().from('categories').select('*').order('sort_order');
    if (error) throw AppError.unavailable('Could not load categories.');
    res.json({ data: (data ?? []).map(toCategory) });
  }),
);

catalogRouter.get(
  '/menu/:id',
  asyncHandler(async (req, res) => {
    const item = await getMenuItemOrThrow(req.params.id);
    res.json({ data: item });
  }),
);

catalogRouter.post(
  '/menu/:id/reviews',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { rating, comment } = parseBody(reviewSchema, req.body);
    await getMenuItemOrThrow(req.params.id);

    const { data: existing } = await db()
      .from('reviews')
      .select('id')
      .eq('menu_item_id', req.params.id)
      .eq('user_id', req.user!.id)
      .maybeSingle();
    if (existing) throw AppError.conflict('You have already reviewed this dish.');

    const { data: delivered } = await db()
      .from('orders')
      .select('id')
      .eq('user_id', req.user!.id)
      .eq('status', 'delivered')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    const { error } = await db().from('reviews').insert({
      menu_item_id: req.params.id,
      user_id: req.user!.id,
      order_id: delivered?.id ?? null,
      rating,
      comment,
    });
    if (error) {
      if (error.code === '23505') throw AppError.conflict('You have already reviewed this dish.');
      throw AppError.unavailable('Could not save your review.');
    }

    res.status(201).json({ ok: true });
  }),
);

catalogRouter.get(
  '/menu/:id/reviews',
  asyncHandler(async (req, res) => {
    const { data, error } = await db()
      .from('reviews')
      .select('id, rating, comment, created_at, profiles(full_name)')
      .eq('menu_item_id', req.params.id)
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) throw AppError.unavailable('Could not load reviews.');
    res.json({
      data: (data ?? []).map((r: any) => ({
        id: r.id,
        rating: r.rating,
        comment: r.comment,
        createdAt: r.created_at,
        userName: r.profiles?.full_name ?? 'Grove guest',
      })),
    });
  }),
);

/* ------------------------------------------------------------- favourites */

catalogRouter.get(
  '/favourites',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { data, error } = await db()
      .from('favourites')
      .select(`menu_item_id, menu_items (${'id, category_id, name, description, price_minor, discounted_price_minor, image_url, rating, review_count, is_veg, is_available, is_special, ingredients, allergens, prep_time_mins, categories(slug), item_add_ons(add_ons(id,name,price_minor,is_available))'})`)
      .eq('user_id', req.user!.id);
    if (error) throw AppError.unavailable('Could not load favourites.');
    const items = (data ?? [])
      .map((row: any) => row.menu_items)
      .filter(Boolean)
      .map(toMenuItem);
    res.json({ data: items });
  }),
);

catalogRouter.post(
  '/favourites/:menuItemId',
  requireAuth,
  asyncHandler(async (req, res) => {
    await getMenuItemOrThrow(req.params.menuItemId);
    const { error } = await db()
      .from('favourites')
      .upsert({ user_id: req.user!.id, menu_item_id: req.params.menuItemId }, { onConflict: 'user_id,menu_item_id' });
    if (error) throw AppError.unavailable('Could not save that favourite.');
    res.status(201).json({ ok: true });
  }),
);

catalogRouter.delete(
  '/favourites/:menuItemId',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { error } = await db()
      .from('favourites')
      .delete()
      .eq('user_id', req.user!.id)
      .eq('menu_item_id', req.params.menuItemId);
    if (error) throw AppError.unavailable('Could not remove that favourite.');
    res.json({ ok: true });
  }),
);

/* -------------------------------------------------------------- addresses */

catalogRouter.get(
  '/addresses',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { data, error } = await db()
      .from('addresses')
      .select('*')
      .eq('user_id', req.user!.id)
      .order('is_default', { ascending: false })
      .order('created_at', { ascending: true });
    if (error) throw AppError.unavailable('Could not load addresses.');
    res.json({ data: (data ?? []).map(toAddress) });
  }),
);

const addressWithId = addressSchema.extend({ id: z.string().uuid().optional() });

catalogRouter.post(
  '/addresses',
  requireAuth,
  asyncHandler(async (req, res) => {
    const input = parseBody(addressWithId, req.body);
    const row = {
      user_id: req.user!.id,
      label: input.label,
      line1: input.line1,
      line2: input.line2 || null,
      landmark: input.landmark || null,
      city: input.city,
      pincode: input.pincode,
      is_default: Boolean(input.isDefault),
    };

    // a partial unique index allows only one default address per user
    if (row.is_default) {
      await db().from('addresses').update({ is_default: false }).eq('user_id', req.user!.id);
    }
    const { data, error } = await db().from('addresses').insert(row).select('*').single();
    if (error) throw AppError.unavailable('Could not save that address.');
    res.status(201).json({ data: toAddress(data) });
  }),
);

catalogRouter.patch(
  '/addresses/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    const input = parseBody(addressWithId, req.body);
    const { data: existing } = await db()
      .from('addresses')
      .select('id, user_id')
      .eq('id', req.params.id)
      .maybeSingle();
    if (!existing || existing.user_id !== req.user!.id) throw AppError.notFound('Address not found.');

    if (input.isDefault) {
      await db().from('addresses').update({ is_default: false }).eq('user_id', req.user!.id);
    }
    const { data, error } = await db()
      .from('addresses')
      .update({
        label: input.label,
        line1: input.line1,
        line2: input.line2 || null,
        landmark: input.landmark || null,
        city: input.city,
        pincode: input.pincode,
        is_default: Boolean(input.isDefault),
      })
      .eq('id', req.params.id)
      .eq('user_id', req.user!.id)
      .select('*')
      .single();
    if (error) throw AppError.unavailable('Could not update that address.');
    res.json({ data: toAddress(data) });
  }),
);

catalogRouter.delete(
  '/addresses/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { error } = await db()
      .from('addresses')
      .delete()
      .eq('id', req.params.id)
      .eq('user_id', req.user!.id);
    if (error) throw AppError.unavailable('Could not delete that address.');
    res.json({ ok: true });
  }),
);

/* ---------------------------------------------------------------- coupons */

catalogRouter.get(
  '/coupons',
  asyncHandler(async (_req, res) => {
    const { data, error } = await db()
      .from('coupons')
      .select('*')
      .eq('is_active', true)
      .gt('expires_at', new Date().toISOString())
      .order('min_order_minor', { ascending: true });
    if (error) throw AppError.unavailable('Could not load offers.');
    res.json({ data: (data ?? []).map(toCoupon) });
  }),
);

catalogRouter.post(
  '/coupons/validate',
  asyncHandler(async (req, res) => {
    const { code } = parseBody(couponCodeSchema, req.body);
    const coupon = await findCoupon(code);
    if (!coupon) throw AppError.notFound('This coupon code does not exist.');
    if (!couponIsValid(coupon, 0) && new Date(coupon.expiresAt) < new Date()) {
      throw AppError.badRequest('This coupon has expired.');
    }
    res.json({ data: coupon });
  }),
);
