import { Router, type Request, type Response } from 'express';
import { ACTIVE_ORDER_STATUSES, canCustomerCancel, checkoutSchema } from '@grove/shared';
import type { Order, OrderTotals } from '@grove/shared';
import { z } from 'zod';
import { config } from '../config.js';
import { db } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody } from '../lib/http.js';
import { requireAuth } from '../middleware/auth.js';
import {
  findCoupon,
  priceOrder,
  restaurantConfig,
  validateCart,
  type IncomingLine,
} from '../lib/catalog.js';
import { toAddress, toOrder } from '../lib/mappers.js';
import {
  createRazorpayOrder,
  fetchRazorpayPayment,
  publicKeyId,
  verifyPaymentSignature,
  verifyWebhookSignature,
} from '../lib/razorpay.js';
import { notifyUser } from '../lib/notifications.js';

export const ordersRouter = Router();

/* ------------------------------------------------------------------ schemas */

const lineSchema = z.object({
  key: z.string().min(1).max(200),
  menuItemId: z.string().min(1).max(80),
  name: z.string().min(1).max(120),
  imageUrl: z.string().max(500).default(''),
  unitPriceMinor: z.number().int().min(0),
  quantity: z.number().int().min(1).max(20),
  specialInstructions: z.string().max(200).optional(),
  addOns: z
    .array(z.object({ id: z.string().max(80), name: z.string().max(80), priceMinor: z.number().int().min(0) }))
    .max(10)
    .default([]),
});

const cartSchema = z.object({ lines: z.array(lineSchema).min(1).max(40) }).strict();

const placeOrderSchema = z
  .object({
    checkout: checkoutSchema,
    lines: z.array(lineSchema).min(1).max(40),
    couponCode: z.string().max(24).nullable().optional(),
    idempotencyKey: z.string().min(8).max(100).optional(),
    // totals are accepted for logging only; the server always recomputes
    totals: z.record(z.unknown()).optional(),
  })
  .strict();

/* ------------------------------------------------------------------ helpers */

const loadOrder = async (orderId: string, userId?: string): Promise<Order> => {
  let query = db().from('orders').select('*, profiles(full_name)').eq('id', orderId);
  if (userId) query = query.eq('user_id', userId);
  const { data: row, error } = await query.maybeSingle();
  if (error) throw AppError.unavailable('Could not load that order.');
  if (!row) throw AppError.notFound('Order not found.');

  const { data: items } = await db().from('order_items').select('*').eq('order_id', orderId);
  const { data: assignment } = await db()
    .from('delivery_assignments')
    .select('partner_id, profiles(full_name, phone)')
    .eq('order_id', orderId)
    .maybeSingle();

  const partnerRow = (assignment as any)?.profiles;
  return toOrder(row, items ?? [], {
    partner: partnerRow
      ? { id: (assignment as any).partner_id, name: partnerRow.full_name, phone: partnerRow.phone, vehicle: null }
      : null,
  });
};

const requireIdempotencyKey = (req: Request, bodyKey?: string): string => {
  const key = (req.header('Idempotency-Key') ?? bodyKey ?? '').trim();
  if (key.length < 8 || key.length > 100) {
    throw AppError.badRequest('A valid Idempotency-Key header (8–100 chars) is required.');
  }
  return key;
};

const claimIdempotency = async (userId: string, key: string, scope: string) => {
  const { error } = await db().from('idempotency_keys').insert({ key, user_id: userId, scope });
  if (!error) return { fresh: true as const };

  if (error.code !== '23505') throw AppError.unavailable('Could not secure this checkout attempt.');

  const { data } = await db().from('idempotency_keys').select('scope, response').eq('key', key).maybeSingle();
  if (!data || data.scope !== scope) throw AppError.conflict('This idempotency key was used for another request.');
  if (!data.response) throw AppError.conflict('This checkout is still being processed. Please wait a moment.');
  return { fresh: false as const, response: data.response };
};

/* --------------------------------------------------------------- checkout */

ordersRouter.post(
  '/checkout/reprice',
  asyncHandler(async (req, res) => {
    const { lines } = parseBody(cartSchema, req.body);
    const result = await validateCart(lines as IncomingLine[]);
    res.json(result);
  }),
);

ordersRouter.post(
  '/checkout/validate',
  asyncHandler(async (req, res) => {
    const schema = z
      .object({
        couponCode: z.string().min(3).max(24),
        subtotalMinor: z.number().int().min(0),
        lines: z.array(lineSchema).max(40).optional(),
      })
      .strict();
    const input = parseBody(schema, req.body);

    const coupon = await findCoupon(input.couponCode.toUpperCase());
    if (!coupon) throw AppError.notFound('This coupon code does not exist.');
    if (!coupon.isActive) throw AppError.badRequest('This coupon is no longer active.');
    if (new Date(coupon.expiresAt) < new Date()) throw AppError.badRequest('This coupon has expired.');
    if (input.subtotalMinor > 0 && input.subtotalMinor < coupon.minOrderMinor) {
      const shortfall = Math.ceil((coupon.minOrderMinor - input.subtotalMinor) / 100);
      throw AppError.badRequest(`Add items worth ₹${shortfall} more to use ${coupon.code}.`);
    }
    if (coupon.usageLimit != null && coupon.usedCount >= coupon.usageLimit) {
      throw AppError.badRequest('This coupon has reached its usage limit.');
    }
    res.json({ data: coupon });
  }),
);

/* ----------------------------------------------------------------- orders */

ordersRouter.post(
  '/orders',
  requireAuth,
  asyncHandler(async (req, res) => {
    const input = parseBody(placeOrderSchema, req.body);
    const userId = req.user!.id;
    const key = requireIdempotencyKey(req, input.idempotencyKey);

    const claim = await claimIdempotency(userId, key, 'place_order');
    if (!claim.fresh) {
      res.status(200).json({ data: claim.response });
      return;
    }

    try {
      // 1. Re-price against the live menu — client prices are never trusted.
      const validated = await validateCart(input.lines as IncomingLine[]);
      const blocked = validated.removed.filter((r) => r.reason !== 'price_changed');
      if (blocked.length) {
        throw AppError.conflict(
          `Some items are no longer available: ${blocked.map((b) => b.name).join(', ')}.`,
          { removed: blocked },
        );
      }
      if (validated.lines.length === 0) throw AppError.badRequest('Your cart is empty.');

      // 2. Coupon + totals, server-side.
      const couponCode = (input.couponCode ?? input.checkout.couponCode ?? '').trim().toUpperCase();
      let coupon = null as Awaited<ReturnType<typeof findCoupon>>;
      if (couponCode) {
        coupon = await findCoupon(couponCode);
        if (!coupon) throw AppError.badRequest('That coupon code is not valid.');
      }

      const totals = priceOrder(validated.lines, coupon, input.checkout.type);
      if (totals.issues.length) throw AppError.badRequest(totals.issues[0]);

      if (input.checkout.paymentMethod === 'cod' && !restaurantConfig.codEnabled) {
        throw AppError.badRequest('Cash on Delivery is currently disabled by the restaurant.');
      }

      // 3. Address ownership + immutable snapshot.
      let addressSnapshot: ReturnType<typeof toAddress> | null = null;
      if (input.checkout.type === 'delivery') {
        if (!input.checkout.addressId) throw AppError.badRequest('A delivery address is required.');
        const { data: addressRow } = await db()
          .from('addresses')
          .select('*')
          .eq('id', input.checkout.addressId)
          .eq('user_id', userId)
          .maybeSingle();
        if (!addressRow) throw AppError.badRequest('That delivery address is not on your account.');
        addressSnapshot = toAddress(addressRow);
      }

      const orderTotals: OrderTotals = {
        itemsTotalMinor: totals.itemsTotalMinor,
        subtotalMinor: totals.subtotalMinor,
        discountMinor: totals.discountMinor,
        taxesMinor: totals.taxesMinor,
        deliveryFeeMinor: totals.deliveryFeeMinor,
        platformFeeMinor: totals.platformFeeMinor,
        grandTotalMinor: totals.grandTotalMinor,
      };

      // 4. Create the order.
      const { data: orderRow, error: orderError } = await db()
        .from('orders')
        .insert({
          user_id: userId,
          type: input.checkout.type,
          status: 'pending',
          payment_method: input.checkout.paymentMethod,
          payment_status: 'pending',
          items_total_minor: orderTotals.itemsTotalMinor,
          discount_minor: orderTotals.discountMinor,
          taxes_minor: orderTotals.taxesMinor,
          delivery_fee_minor: orderTotals.deliveryFeeMinor,
          platform_fee_minor: orderTotals.platformFeeMinor,
          grand_total_minor: orderTotals.grandTotalMinor,
          coupon_code: totals.couponCode,
          address_id: input.checkout.addressId,
          address_snapshot: addressSnapshot,
          contact_phone: input.checkout.contactPhone,
          delivery_instructions: input.checkout.deliveryInstructions || null,
        })
        .select('*')
        .single();

      if (orderError || !orderRow) throw AppError.unavailable('Could not create your order. Please retry.');

      const { error: itemsError } = await db().from('order_items').insert(
        validated.lines.map((line) => ({
          order_id: orderRow.id,
          menu_item_id: line.menuItemId,
          name: line.name,
          image_url: line.imageUrl,
          quantity: line.quantity,
          unit_price_minor: line.unitPriceMinor,
          add_ons: line.addOns,
          special_instructions: line.specialInstructions ?? null,
        })),
      );

      if (itemsError) {
        await db().from('orders').delete().eq('id', orderRow.id);
        throw AppError.unavailable('Could not save your order items. Nothing was charged.');
      }

      await db().from('order_status_history').insert({
        order_id: orderRow.id,
        status: 'pending',
        changed_by: userId,
        note: 'Order placed',
      });

      if (coupon) {
        const { error: redeemError } = await db().rpc('increment_coupon_usage', { coupon_code: coupon.code });
        if (redeemError) console.warn('[orders] coupon usage increment failed', redeemError.message);
        await db().from('coupon_redemptions').insert({
          coupon_code: coupon.code,
          user_id: userId,
          order_id: orderRow.id,
          discount_minor: totals.discountMinor,
        });
      }

      const order = await loadOrder(orderRow.id, userId);
      await db().from('idempotency_keys').update({ response: order }).eq('key', key);

      void notifyUser({
        userId,
        title: 'Order placed',
        body: `Order ${order.orderNumber} received. We will confirm it shortly.`,
        data: { orderId: order.id, screen: 'order' },
        category: 'order',
      });

      res.status(201).json({ data: order });
    } catch (err) {
      // Release the key so the customer can retry a failed attempt.
      await db().from('idempotency_keys').delete().eq('key', key).eq('user_id', userId);
      throw err;
    }
  }),
);

ordersRouter.get(
  '/orders',
  requireAuth,
  asyncHandler(async (req, res) => {
    const page = Math.max(1, Number(req.query.page ?? 1) || 1);
    const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize ?? 20) || 20));
    const status = String(req.query.status ?? 'all');

    let query = db()
      .from('orders')
      .select('*', { count: 'exact' })
      .eq('user_id', req.user!.id)
      .order('created_at', { ascending: false })
      .range((page - 1) * pageSize, page * pageSize - 1);

    if (status === 'active') query = query.in('status', ACTIVE_ORDER_STATUSES);
    else if (status === 'delivered') query = query.eq('status', 'delivered');
    else if (status === 'cancelled') query = query.eq('status', 'cancelled');
    else if (status !== 'all') query = query.eq('status', status);

    const { data, error, count } = await query;
    if (error) throw AppError.unavailable('Could not load your orders.');

    const ids = (data ?? []).map((o) => o.id);
    const { data: items } = ids.length
      ? await db().from('order_items').select('*').in('order_id', ids)
      : { data: [] as any[] };

    const byOrder = new Map<string, any[]>();
    for (const item of items ?? []) {
      byOrder.set(item.order_id, [...(byOrder.get(item.order_id) ?? []), item]);
    }

    res.json({
      data: (data ?? []).map((row) => toOrder(row, byOrder.get(row.id) ?? [])),
      page,
      pageSize,
      total: count ?? 0,
    });
  }),
);

ordersRouter.get(
  '/orders/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    const order = await loadOrder(req.params.id, req.user!.id);
    res.json({ data: order });
  }),
);

ordersRouter.post(
  '/orders/:id/cancel',
  requireAuth,
  asyncHandler(async (req, res) => {
    const reason = z
      .object({ reason: z.string().trim().max(200).optional() })
      .parse(req.body ?? {}).reason ?? 'Cancelled by customer';

    const { data: order } = await db()
      .from('orders')
      .select('*')
      .eq('id', req.params.id)
      .eq('user_id', req.user!.id)
      .maybeSingle();
    if (!order) throw AppError.notFound('Order not found.');
    if (!canCustomerCancel(order.status)) {
      throw AppError.badRequest('This order can no longer be cancelled online. Please call the restaurant.');
    }

    const refundNeeded = order.payment_status === 'paid';
    const { error } = await db()
      .from('orders')
      .update({
        status: 'cancelled',
        cancel_reason: reason,
        payment_status: refundNeeded ? 'paid' : order.payment_status,
      })
      .eq('id', order.id)
      .eq('user_id', req.user!.id);
    if (error) throw AppError.unavailable('Could not cancel this order.');

    await db().from('order_status_history').insert({
      order_id: order.id,
      status: 'cancelled',
      changed_by: req.user!.id,
      note: reason,
    });

    void notifyUser({
      userId: req.user!.id,
      title: 'Order cancelled',
      body: refundNeeded
        ? `Order ${order.order_number} is cancelled. Your refund is being processed.`
        : `Order ${order.order_number} is cancelled.`,
      data: { orderId: order.id },
      category: 'order',
    });

    const updated = await loadOrder(order.id, req.user!.id);
    res.json({ data: updated });
  }),
);

/* --------------------------------------------------------------- payments */

const paymentSchema = z
  .object({
    orderId: z.string().uuid(),
    razorpayOrderId: z.string().min(3).max(120),
    razorpayPaymentId: z.string().min(3).max(120),
    razorpaySignature: z.string().min(3).max(300),
  })
  .strict();

ordersRouter.post(
  '/payments/create-order',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { orderId } = z.object({ orderId: z.string().uuid() }).strict().parse(req.body);

    const { data: order } = await db()
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', req.user!.id)
      .maybeSingle();
    if (!order) throw AppError.notFound('Order not found.');
    if (order.status === 'cancelled') throw AppError.badRequest('This order was cancelled.');
    if (order.payment_status === 'paid') throw AppError.conflict('This order is already paid.');
    if (order.payment_method === 'cod') throw AppError.badRequest('This order is Cash on Delivery.');

    const { data: existing } = await db()
      .from('payments')
      .select('*')
      .eq('order_id', order.id)
      .eq('status', 'created')
      .order('created_at', { ascending: false })
      .maybeSingle();
    if (existing?.provider_order_id && !config.PAYMENTS_DEMO) {
      res.json({
        razorpayOrderId: existing.provider_order_id,
        amountMinor: existing.amount_minor,
        currency: existing.currency,
        keyId: publicKeyId(),
        demo: false,
      });
      return;
    }

    if (!config.razorpayEnabled) {
      if (!config.PAYMENTS_DEMO) {
        throw AppError.unavailable('Online payments are not configured. Please choose Cash on Delivery.');
      }
      // Explicit development-only simulation. Never enabled in production.
      const demoOrderId = `order_demo_${order.order_number}`;
      await db().from('payments').insert({
        order_id: order.id,
        provider: 'razorpay',
        provider_order_id: demoOrderId,
        amount_minor: order.grand_total_minor,
        currency: 'INR',
        status: 'created',
      });
      res.json({
        razorpayOrderId: demoOrderId,
        amountMinor: order.grand_total_minor,
        currency: 'INR',
        keyId: 'rzp_demo_key',
        demo: true,
      });
      return;
    }

    const rp = await createRazorpayOrder({
      amountMinor: order.grand_total_minor,
      receipt: order.order_number,
      notes: { orderId: order.id, orderNumber: order.order_number },
    });

    await db().from('payments').insert({
      order_id: order.id,
      provider: 'razorpay',
      provider_order_id: rp.id,
      amount_minor: rp.amount,
      currency: rp.currency,
      status: 'created',
    });

    res.json({
      razorpayOrderId: rp.id,
      amountMinor: rp.amount,
      currency: rp.currency,
      keyId: publicKeyId(),
      demo: false,
    });
  }),
);

ordersRouter.post(
  '/payments/verify',
  requireAuth,
  asyncHandler(async (req, res) => {
    const input = parseBody(paymentSchema, req.body);
    const { orderId } = input;

    const { data: order } = await db()
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('user_id', req.user!.id)
      .maybeSingle();
    if (!order) throw AppError.notFound('Order not found.');
    if (order.payment_status === 'paid') {
      res.json({ data: await loadOrder(order.id, req.user!.id) });
      return;
    }

    const { data: payment } = await db()
      .from('payments')
      .select('*')
      .eq('order_id', order.id)
      .eq('provider_order_id', input.razorpayOrderId)
      .maybeSingle();
    if (!payment) throw AppError.badRequest('No payment attempt matches this order.');

    const isDemo = input.razorpaySignature.startsWith('sig_demo_') || input.razorpayPaymentId.startsWith('pay_demo_');
    if (isDemo && !config.PAYMENTS_DEMO) {
      throw AppError.badRequest('Test payments are not accepted by this server.');
    }

    if (!isDemo) {
      if (!verifyPaymentSignature(input)) {
        await db()
          .from('payments')
          .update({ status: 'failed', failure_reason: 'Signature mismatch' })
          .eq('id', payment.id);
        throw AppError.badRequest('Payment verification failed. No money was captured — please retry.');
      }
      const rp = await fetchRazorpayPayment(input.razorpayPaymentId);
      const validStatus = rp.status === 'captured' || rp.status === 'authorized';
      if (!validStatus || rp.amount !== order.grand_total_minor || rp.order_id !== input.razorpayOrderId) {
        await db()
          .from('payments')
          .update({ status: 'failed', failure_reason: `Provider status: ${rp.status}`, raw_response: rp })
          .eq('id', payment.id);
        throw AppError.badRequest('The payment was not completed successfully.');
      }
    }

    await db()
      .from('payments')
      .update({
        status: 'paid',
        provider_payment_id: input.razorpayPaymentId,
        signature_verified: !isDemo,
        raw_response: { demo: isDemo },
      })
      .eq('id', payment.id);

    const { error: orderError } = await db()
      .from('orders')
      .update({
        payment_status: 'paid',
        status: order.status === 'pending' ? 'confirmed' : order.status,
        estimated_at: order.estimated_at ?? new Date(Date.now() + 35 * 60_000).toISOString(),
      })
      .eq('id', order.id);
    if (orderError) throw AppError.unavailable('Payment captured but the order could not be updated. Contact support.');

    await db().from('order_status_history').insert({
      order_id: order.id,
      status: 'confirmed',
      changed_by: null,
      note: 'Payment verified',
    });

    void notifyUser({
      userId: order.user_id,
      title: 'Payment received',
      body: `We have your payment for order ${order.order_number}. The kitchen is starting now.`,
      data: { orderId: order.id },
      category: 'order',
    });

    res.json({ data: await loadOrder(order.id, req.user!.id) });
  }),
);

/**
 * Webhook keeps payment state correct even if the app closes mid-payment.
 * Mounted with express.raw() so the signature can be checked over exact bytes.
 */
export const razorpayWebhook = async (req: Request, res: Response): Promise<void> => {
  const signature = req.header('X-Razorpay-Signature') ?? '';
  const raw = req.body as Buffer;

  if (!Buffer.isBuffer(raw) || !verifyWebhookSignature(raw, signature)) {
    res.status(400).json({ error: { code: 'invalid_signature', message: 'Invalid webhook signature.' } });
    return;
  }

  let event: any;
  try {
    event = JSON.parse(raw.toString('utf8'));
  } catch {
    res.status(400).json({ error: { code: 'bad_payload', message: 'Invalid JSON.' } });
    return;
  }

  // Always acknowledge quickly; Razorpay retries non-2xx responses.
  res.status(200).json({ received: true });

  try {
    const type: string = event?.event ?? '';
    const entity = event?.payload?.payment?.entity ?? event?.payload?.refund?.entity;
    const providerPaymentId: string | undefined = entity?.id;
    const providerOrderId: string | undefined = entity?.order_id;

    if (!providerOrderId) return;

    const { data: payment } = await db()
      .from('payments')
      .select('*, orders(id, user_id, order_number, grand_total_minor, status)')
      .eq('provider_order_id', providerOrderId)
      .maybeSingle();
    if (!payment) return;

    const orderRow: any = (payment as any).orders;
    if (!orderRow) return;

    if (type === 'payment.captured' || type === 'order.paid') {
      if (payment.status === 'paid') return;
      if (entity?.amount && entity.amount !== orderRow.grand_total_minor) return;

      await db()
        .from('payments')
        .update({
          status: 'paid',
          provider_payment_id: providerPaymentId,
          signature_verified: true,
          raw_response: event,
        })
        .eq('id', payment.id);

      await db()
        .from('orders')
        .update({
          payment_status: 'paid',
          status: orderRow.status === 'pending' ? 'confirmed' : orderRow.status,
        })
        .eq('id', orderRow.id);

      await db().from('order_status_history').insert({
        order_id: orderRow.id,
        status: 'confirmed',
        note: 'Payment captured (webhook)',
      });
      return;
    }

    if (type === 'payment.failed') {
      await db()
        .from('payments')
        .update({ status: 'failed', failure_reason: entity?.error_description ?? 'Payment failed', raw_response: event })
        .eq('id', payment.id);
      await db().from('orders').update({ payment_status: 'failed' }).eq('id', orderRow.id);
      return;
    }

    if (type === 'refund.processed') {
      await db().from('payments').update({ status: 'refunded', raw_response: event }).eq('id', payment.id);
      await db().from('orders').update({ payment_status: 'refunded' }).eq('id', orderRow.id);
    }
  } catch (err) {
    console.error('[webhook] processing failed', (err as Error).message);
  }
};

/** Prep-time estimate in minutes, used when staff confirm an order. */
export const estimateMinutes = (type: string): number =>
  type === 'delivery' ? 40 : type === 'takeaway' ? 25 : 15;
