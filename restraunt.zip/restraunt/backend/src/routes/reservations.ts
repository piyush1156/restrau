import { Router } from 'express';
import { reservationSchema } from '@grove/shared';
import type { OpeningHour, SeatPreference } from '@grove/shared';
import { z } from 'zod';
import { db } from '../lib/supabase.js';
import { AppError, asyncHandler, parseBody, parseQuery } from '../lib/http.js';
import { requireAuth } from '../middleware/auth.js';
import { toReservation, toTable } from '../lib/mappers.js';
import { notifyUser } from '../lib/notifications.js';

export const reservationsRouter = Router();

const SLOT_MINUTES = 30;
const LAST_SEATING_BEFORE_CLOSE = 90;

/**
 * Chooses the first free table that fits, honouring the seating preference.
 * Exported for tests; the route still re-checks the DB before inserting.
 */
export const pickTable = (
  tables: { id: string; tableNumber: number; capacity: number; seating: 'indoor' | 'outdoor'; is_active: boolean }[],
  takenIds: Set<string>,
  guests: number,
  preference: SeatPreference,
) => {
  const fitting = tables
    .filter((t) => t.is_active && t.capacity >= guests && !takenIds.has(t.id))
    .sort((a, b) => a.capacity - b.capacity);
  const preferred = fitting.filter((t) => preference === 'any' || t.seating === preference);
  const fallback = fitting.filter((t) => preference !== 'any' && t.seating !== preference);
  return preferred[0] ?? fallback[0] ?? null;
};

const hoursForDate = async (date: string): Promise<OpeningHour | null> => {
  const [y, m, d] = date.split('-').map(Number);
  const day = new Date(y, m - 1, d).getDay();
  const { data } = await db().from('restaurant_opening_hours').select('*').eq('day', day).maybeSingle();
  if (!data) return null;
  return {
    day: data.day,
    opensAt: String(data.opens_at).slice(0, 5),
    closesAt: String(data.closes_at).slice(0, 5),
    isClosed: data.is_closed,
  };
};

/** Restaurant-local (IST) date and minutes since midnight. */
const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
const nowInIst = (): Date => new Date(Date.now() + IST_OFFSET_MS);
const todayInTimezone = (): string => nowInIst().toISOString().slice(0, 10);

/** Slots every 30 min; today hides times inside the 60-minute lead window. */
const buildSlots = (hours: OpeningHour, date: string): string[] => {
  if (hours.isClosed) return [];
  const [oh, om] = hours.opensAt.split(':').map(Number);
  const [ch, cm] = hours.closesAt.split(':').map(Number);
  const lastStart = ch * 60 + cm - LAST_SEATING_BEFORE_CLOSE;
  const ist = nowInIst();
  const isToday = date === ist.toISOString().slice(0, 10);
  const cutoff = ist.getUTCHours() * 60 + ist.getUTCMinutes() + 60;
  const slots: string[] = [];
  for (let t = oh * 60 + om; t <= lastStart; t += SLOT_MINUTES) {
    if (isToday && t < cutoff) continue;
    slots.push(`${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`);
  }
  return slots;
};

const availabilityQuery = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  guests: z.coerce.number().int().min(1).max(20),
});

reservationsRouter.get(
  '/reservations/availability',
  asyncHandler(async (req, res) => {
    const { date, guests } = parseQuery(availabilityQuery, req.query);
    if (date < todayInTimezone()) throw AppError.badRequest('Pick today or a future date.');

    const hours = await hoursForDate(date);
    if (!hours) throw AppError.unavailable('Opening hours are not configured.');
    const slots = buildSlots(hours, date);
    if (slots.length === 0) {
      res.json({ slots: [], bookedTimes: [], tables: [], seatingFull: { indoor: true, outdoor: true } });
      return;
    }

    const { data: tables, error: tableError } = await db()
      .from('restaurant_tables')
      .select('*')
      .eq('is_active', true)
      .gte('capacity', guests)
      .order('capacity');
    if (tableError) throw AppError.unavailable('Could not load tables.');
    const fitting = (tables ?? []).map(toTable);

    const { data: active, error: resError } = await db()
      .from('reservations')
      .select('reservation_time, table_id, seating, status')
      .eq('reservation_date', date)
      .in('status', ['pending', 'confirmed']);
    if (resError) throw AppError.unavailable('Could not check availability.');

    const bookedByTime = new Map<string, Set<string>>();
    (active ?? []).forEach((r: any) => {
      const time = String(r.reservation_time).slice(0, 5);
      const set = bookedByTime.get(time) ?? new Set<string>();
      if (r.table_id) set.add(r.table_id);
      bookedByTime.set(time, set);
    });

    // A slot is only reported "full" when no table in the whole restaurant is free.
    const bookedTimes = slots.filter((slot) => {
      const taken = bookedByTime.get(slot) ?? new Set<string>();
      return fitting.length > 0 && fitting.every((t) => taken.has(t.id));
    });

    const firstSlot = slots[0];
    const takenNow = bookedByTime.get(firstSlot) ?? new Set<string>();
    const seatingFull = {
      indoor: !fitting.some((t) => t.seating === 'indoor' && !takenNow.has(t.id)),
      outdoor: !fitting.some((t) => t.seating === 'outdoor' && !takenNow.has(t.id)),
    };

    res.json({ slots, bookedTimes, tables: fitting, seatingFull });
  }),
);

reservationsRouter.post(
  '/reservations',
  requireAuth,
  asyncHandler(async (req, res) => {
    const input = parseBody(reservationSchema, req.body);
    if (input.date < todayInTimezone()) throw AppError.badRequest('Pick today or a future date.');

    const hours = await hoursForDate(input.date);
    if (!hours || hours.isClosed) throw AppError.badRequest('We are closed on that date.');
    const slots = buildSlots(hours, input.date);
    if (!slots.includes(input.time)) {
      throw AppError.badRequest('That time slot is not available. Please pick another.');
    }

    const { data: tables, error: tableError } = await db()
      .from('restaurant_tables')
      .select('*')
      .eq('is_active', true)
      .gte('capacity', input.guests)
      .order('capacity');
    if (tableError) throw AppError.unavailable('Could not load tables.');
    if (!tables?.length) {
      throw AppError.conflict(`We have no table that seats ${input.guests} guests. Please call us for large groups.`);
    }

    const preferred: SeatPreference = input.seating;
    const candidates = tables
      .map(toTable)
      .filter((t) => preferred === 'any' || t.seating === preferred)
      .concat(preferred === 'any' ? [] : tables.map(toTable).filter((t) => t.seating !== preferred));

    // Try each candidate; the DB unique index is the final guard against races.
    for (const table of candidates) {
      const { data: clash } = await db()
        .from('reservations')
        .select('id')
        .eq('table_id', table.id)
        .eq('reservation_date', input.date)
        .eq('reservation_time', input.time)
        .in('status', ['pending', 'confirmed'])
        .maybeSingle();
      if (clash) continue;

      const { data: created, error } = await db()
        .from('reservations')
        .insert({
          user_id: req.user!.id,
          reservation_date: input.date,
          reservation_time: input.time,
          guests: input.guests,
          seating: input.seating,
          table_id: table.id,
          special_requests: input.specialRequests || null,
          status: 'confirmed',
        })
        .select('*, restaurant_tables(table_number)')
        .single();

      if (error) {
        if (error.code === '23505') continue; // lost the race for this table, try the next
        throw AppError.unavailable('Could not confirm your reservation.');
      }

      const reservation = toReservation(created);
      void notifyUser({
        userId: req.user!.id,
        title: 'Table confirmed',
        body: `Table ${table.tableNumber} is booked for ${input.guests} guests at ${input.time} on ${input.date}. Code ${reservation.code}.`,
        data: { reservationId: reservation.id },
        category: 'reservation',
      });
      res.status(201).json({ data: reservation });
      return;
    }

    throw AppError.conflict('All matching tables are booked for that slot. Please choose another time.');
  }),
);

reservationsRouter.get(
  '/reservations',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { data, error } = await db()
      .from('reservations')
      .select('*, restaurant_tables(table_number)')
      .eq('user_id', req.user!.id)
      .order('reservation_date', { ascending: false })
      .order('reservation_time', { ascending: false })
      .limit(50);
    if (error) throw AppError.unavailable('Could not load your reservations.');
    res.json({ data: (data ?? []).map(toReservation) });
  }),
);

reservationsRouter.post(
  '/reservations/:id/cancel',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { data: existing } = await db()
      .from('reservations')
      .select('*')
      .eq('id', req.params.id)
      .eq('user_id', req.user!.id)
      .maybeSingle();
    if (!existing) throw AppError.notFound('Reservation not found.');
    if (['cancelled', 'rejected', 'completed'].includes(existing.status)) {
      throw AppError.badRequest('This reservation cannot be cancelled.');
    }

    const startsAt = new Date(`${existing.reservation_date}T${String(existing.reservation_time).slice(0, 5)}:00+05:30`);
    if (startsAt.getTime() < Date.now()) {
      throw AppError.badRequest('This reservation has already started. Please call the restaurant.');
    }

    const { data, error } = await db()
      .from('reservations')
      .update({ status: 'cancelled' })
      .eq('id', req.params.id)
      .eq('user_id', req.user!.id)
      .select('*, restaurant_tables(table_number)')
      .single();
    if (error) throw AppError.unavailable('Could not cancel the reservation.');

    res.json({ data: toReservation(data) });
  }),
);
