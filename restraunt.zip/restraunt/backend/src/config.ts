import 'dotenv/config';
import { z } from 'zod';

const bool = (def: boolean) =>
  z
    .string()
    .optional()
    .transform((v) => (v == null || v === '' ? def : ['1', 'true', 'yes', 'on'].includes(v.toLowerCase())));

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  CORS_ORIGINS: z.string().default('http://localhost:3000'),
  SUPABASE_URL: z.string().url().optional(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().optional(),
  SUPABASE_ANON_KEY: z.string().optional(),
  PASSWORD_RESET_REDIRECT_URL: z.string().default('thegrove://reset-password'),
  RAZORPAY_KEY_ID: z.string().optional(),
  RAZORPAY_KEY_SECRET: z.string().optional(),
  RAZORPAY_WEBHOOK_SECRET: z.string().optional(),
  RAZORPAY_PUBLIC_KEY_ID: z.string().optional(),
  PAYMENTS_DEMO: bool(false),
  COD_ENABLED: bool(true),
  OPENAI_API_KEY: z.string().optional(),
  OPENAI_BASE_URL: z.string().default('https://api.openai.com/v1'),
  OPENAI_MODEL: z.string().default('gpt-4o-mini'),
  EXPO_PUSH_ENABLED: bool(false),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default('The Grove <orders@thegrove.in>'),
  RESTAURANT_TIMEZONE: z.string().default('Asia/Kolkata'),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  // Fail fast with readable output instead of undefined behaviour at runtime.
  console.error('Invalid environment configuration:', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

const env = parsed.data;

export const config = {
  ...env,
  isProd: env.NODE_ENV === 'production',
  isTest: env.NODE_ENV === 'test',
  corsOrigins: env.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
  hasSupabase: Boolean(env.SUPABASE_URL && env.SUPABASE_SERVICE_ROLE_KEY),
  razorpayEnabled: Boolean(env.RAZORPAY_KEY_ID && env.RAZORPAY_KEY_SECRET),
  aiEnabled: Boolean(env.OPENAI_API_KEY),
  timezone: env.RESTAURANT_TIMEZONE,
};

if (config.isProd && config.PAYMENTS_DEMO) {
  console.error('Refusing to start: PAYMENTS_DEMO must be false in production.');
  process.exit(1);
}
if (config.isProd && env.CORS_ORIGINS.includes('*')) {
  console.error('Refusing to start: wildcard CORS is not allowed in production.');
  process.exit(1);
}

export type AppConfig = typeof config;
