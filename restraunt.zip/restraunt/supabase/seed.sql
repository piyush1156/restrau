-- ============================================================================
-- The Grove — seed data (safe to re-run)
-- Run after migrations:  supabase db reset   (or paste into SQL editor)
-- ============================================================================

insert into categories (name, slug, sort_order) values
  ('Starters', 'starters', 1),
  ('Main Course', 'main-course', 2),
  ('Desserts', 'desserts', 3),
  ('Beverages', 'beverages', 4)
on conflict (slug) do update set name = excluded.name, sort_order = excluded.sort_order;

-- --------------------------------------------------------------- add-ons
insert into add_ons (name, price_minor) values
  ('Extra Paneer', 4000),
  ('Mint Chutney', 2000),
  ('Extra Mint Chutney', 2000),
  ('Extra Chilli Sauce', 1500),
  ('Extra Sev', 1000),
  ('Extra Gravy', 5000),
  ('Extra Roti (2 pcs)', 4000),
  ('Extra Cheese', 5000),
  ('Jalapenos', 3000),
  ('Extra Butter', 2000),
  ('Raita', 3000),
  ('Boiled Egg', 2500),
  ('Extra Chutney', 1500),
  ('Extra Ice Cream Scoop', 4000),
  ('Extra Ginger', 500),
  ('Extra Mango Pulp', 2500),
  ('Masala Powder', 1000)
on conflict do nothing;

-- ------------------------------------------------------------- menu items
insert into menu_items
  (category_id, name, description, price_minor, discounted_price_minor, image_url,
   rating, review_count, is_veg, is_available, is_special, ingredients, allergens, prep_time_mins)
values
  ((select id from categories where slug='starters'), 'Paneer Tikka',
   'Juicy paneer cubes marinated in rich spices and grilled to perfection.',
   24900, null, 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=1000&q=70',
   4.8, 1320, true, true, true,
   array['Paneer','Yogurt','Capsicum','Onion','Garam masala','Lemon'],
   array['Dairy'], 18),

  ((select id from categories where slug='starters'), 'Tandoori Chicken',
   'Charcoal-smoked chicken marinated overnight in yogurt and signature masala.',
   32900, null, 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=1000&q=70',
   4.7, 860, false, true, false,
   array['Chicken','Yogurt','Kashmiri chilli','Ginger garlic','Garam masala'],
   array['Dairy'], 25),

  ((select id from categories where slug='starters'), 'Veg Spring Rolls',
   'Crispy rolls stuffed with seasoned vegetables, served with chilli sauce.',
   17900, null, 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1000&q=70',
   4.5, 410, true, true, false,
   array['Cabbage','Carrot','Capsicum','Refined flour','Pepper'],
   array['Gluten'], 12),

  ((select id from categories where slug='starters'), 'Samosa Chaat',
   'Crushed samosa topped with chickpeas, yogurt, chutneys and sev.',
   14900, null, 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1000&q=70',
   4.6, 520, true, true, false,
   array['Potato','Peas','Chickpeas','Yogurt','Tamarind chutney','Sev'],
   array['Dairy','Gluten'], 10),

  ((select id from categories where slug='starters'), 'Chicken Seekh Kebab',
   'Minced chicken kebabs grilled with herbs, served with onion salad.',
   28900, null, 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=1000&q=70',
   4.6, 340, false, false, false,
   array['Minced chicken','Coriander','Green chilli','Ginger garlic'],
   array[]::text[], 20),

  ((select id from categories where slug='main-course'), 'Butter Chicken',
   'Rich and creamy tomato-cashew gravy with tender tandoori chicken.',
   29900, 26900, 'https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=1000&q=70',
   4.9, 2140, false, true, true,
   array['Chicken','Tomato','Cashew','Butter','Cream','Kasuri methi'],
   array['Dairy','Nuts (cashew)'], 22),

  ((select id from categories where slug='main-course'), 'Paneer Butter Masala',
   'Soft paneer simmered in a velvety makhani gravy with a hint of honey.',
   27900, null, 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=1000&q=70',
   4.8, 1580, true, true, false,
   array['Paneer','Tomato','Butter','Cream','Cashew','Honey'],
   array['Dairy','Nuts (cashew)'], 20),

  ((select id from categories where slug='main-course'), 'Veg Pizza',
   'Wood-fired pizza loaded with fresh vegetables and mozzarella.',
   27900, null, 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1000&q=70',
   4.7, 990, true, true, false,
   array['Wheat base','Mozzarella','Onion','Capsicum','Tomato','Oregano'],
   array['Gluten','Dairy'], 18),

  ((select id from categories where slug='main-course'), 'Dal Makhani',
   'Black lentils slow-cooked overnight with butter and cream.',
   23900, null, 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=1000&q=70',
   4.7, 720, true, true, false,
   array['Urad dal','Rajma','Butter','Cream','Tomato'],
   array['Dairy'], 15),

  ((select id from categories where slug='main-course'), 'Chicken Dum Biryani',
   'Long-grain basmati layered with spiced chicken, sealed and slow-cooked.',
   31900, null, 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1000&q=70',
   4.8, 1890, false, true, true,
   array['Basmati rice','Chicken','Saffron','Fried onion','Mint','Biryani masala'],
   array['Dairy'], 28),

  ((select id from categories where slug='main-course'), 'Shahi Paneer',
   'Royal white gravy of cashews, cream and mild spices with paneer cubes.',
   26900, null, 'https://images.unsplash.com/photo-1631452180775-4ed9f8b3ac97?auto=format&fit=crop&w=1000&q=70',
   4.6, 640, true, true, false,
   array['Paneer','Cashew','Cream','Onion','Cardamom'],
   array['Dairy','Nuts (cashew)'], 20),

  ((select id from categories where slug='main-course'), 'Masala Dosa',
   'Crisp rice crepe filled with spiced potato, served with sambar and chutney.',
   18900, null, 'https://images.unsplash.com/photo-1630383249896-424e482df921?auto=format&fit=crop&w=1000&q=70',
   4.7, 1120, true, true, false,
   array['Rice batter','Urad dal','Potato','Mustard seeds','Curry leaf'],
   array[]::text[], 14),

  ((select id from categories where slug='desserts'), 'Chocolate Lava Cake',
   'Warm chocolate cake with a molten center, served with vanilla ice cream.',
   19900, null, 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=1000&q=70',
   4.8, 1450, true, true, true,
   array['Dark chocolate','Butter','Egg','Flour','Vanilla ice cream'],
   array['Dairy','Gluten','Egg'], 12),

  ((select id from categories where slug='desserts'), 'Gulab Jamun (2 pcs)',
   'Khoya dumplings soaked in cardamom sugar syrup, served warm.',
   12900, null, 'https://images.unsplash.com/photo-1601303516534-bf0b1eb70dd0?auto=format&fit=crop&w=1000&q=70',
   4.7, 830, true, true, false,
   array['Khoya','Flour','Sugar syrup','Cardamom'],
   array['Dairy','Gluten'], 5),

  ((select id from categories where slug='desserts'), 'Rasmalai (2 pcs)',
   'Soft paneer discs resting in saffron-cardamom thickened milk.',
   14900, null, 'https://images.unsplash.com/photo-1666190092159-3171cf0fbb12?auto=format&fit=crop&w=1000&q=70',
   4.6, 510, true, true, false,
   array['Paneer','Milk','Saffron','Cardamom','Pistachio'],
   array['Dairy','Nuts (pistachio)'], 5),

  ((select id from categories where slug='beverages'), 'Masala Chai',
   'Assam tea brewed with milk, ginger and whole spices.',
   7900, null, 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?auto=format&fit=crop&w=1000&q=70',
   4.8, 2210, true, true, false,
   array['Assam tea','Milk','Ginger','Cardamom','Cloves'],
   array['Dairy'], 6),

  ((select id from categories where slug='beverages'), 'Mango Lassi',
   'Thick yogurt smoothie blended with alphonso mango pulp.',
   12900, null, 'https://images.unsplash.com/photo-1626203071265-5a3e1b8c0d94?auto=format&fit=crop&w=1000&q=70',
   4.7, 940, true, true, false,
   array['Yogurt','Alphonso mango','Sugar','Cardamom'],
   array['Dairy'], 5),

  ((select id from categories where slug='beverages'), 'Cold Coffee',
   'Chilled blended coffee with ice cream and a dusting of cocoa.',
   15900, null, 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=1000&q=70',
   4.6, 670, true, true, false,
   array['Coffee','Milk','Ice cream','Sugar','Cocoa'],
   array['Dairy'], 5),

  ((select id from categories where slug='beverages'), 'Fresh Lime Soda',
   'Zesty lime with soda — sweet, salty or masala style.',
   9900, null, 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=1000&q=70',
   4.5, 480, true, true, false,
   array['Lemon','Soda','Black salt','Sugar'],
   array[]::text[], 4)
on conflict do nothing;

-- Link add-ons to dishes by name (idempotent).
insert into item_add_ons (menu_item_id, add_on_id)
select mi.id, ao.id
from (values
  ('Paneer Tikka', 'Extra Paneer'), ('Paneer Tikka', 'Mint Chutney'),
  ('Tandoori Chicken', 'Extra Mint Chutney'),
  ('Veg Spring Rolls', 'Extra Chilli Sauce'),
  ('Samosa Chaat', 'Extra Sev'),
  ('Butter Chicken', 'Extra Gravy'), ('Butter Chicken', 'Extra Roti (2 pcs)'),
  ('Paneer Butter Masala', 'Extra Paneer'),
  ('Veg Pizza', 'Extra Cheese'), ('Veg Pizza', 'Jalapenos'),
  ('Dal Makhani', 'Extra Butter'),
  ('Chicken Dum Biryani', 'Raita'), ('Chicken Dum Biryani', 'Boiled Egg'),
  ('Masala Dosa', 'Extra Chutney'),
  ('Chocolate Lava Cake', 'Extra Ice Cream Scoop'),
  ('Masala Chai', 'Extra Ginger'),
  ('Mango Lassi', 'Extra Mango Pulp'),
  ('Fresh Lime Soda', 'Masala Powder')
) as pairs(item_name, add_on_name)
join menu_items mi on mi.name = pairs.item_name
join add_ons ao on ao.name = pairs.add_on_name
on conflict do nothing;

-- --------------------------------------------------------------- coupons
insert into coupons (code, description, discount_percent, discount_flat_minor, max_discount_minor,
                     min_order_minor, expires_at, usage_limit, is_active)
values
  ('GROVE10', '10% off on orders above ₹199', 10, null, 5000, 19900, now() + interval '90 days', 1000, true),
  ('WELCOME50', 'Flat ₹50 off on your first order above ₹249', null, 5000, null, 24900, now() + interval '90 days', 500, true),
  ('FEAST200', 'Flat ₹200 off on orders above ₹999', null, 20000, null, 99900, now() + interval '60 days', 200, true),
  ('SUMMER20', 'Expired demo coupon — shows validation errors', 20, null, 10000, 0, now() - interval '1 day', 100, true)
on conflict (code) do nothing;

-- ------------------------------------------------------- tables and hours
insert into restaurant_tables (table_number, capacity, seating) values
  (1, 2, 'indoor'), (2, 4, 'indoor'), (3, 6, 'indoor'),
  (4, 2, 'outdoor'), (5, 4, 'outdoor'), (6, 8, 'outdoor'),
  (7, 10, 'indoor')
on conflict (table_number) do nothing;

insert into restaurant_opening_hours (day, opens_at, closes_at, is_closed) values
  (0, '09:00', '23:00', false),
  (1, '09:00', '23:00', false),
  (2, '09:00', '23:00', false),
  (3, '09:00', '23:00', false),
  (4, '09:00', '23:00', false),
  (5, '09:00', '23:30', false),
  (6, '08:30', '23:30', false)
on conflict (day) do update
  set opens_at = excluded.opens_at, closes_at = excluded.closes_at, is_closed = excluded.is_closed;

-- ------------------------------------------------------ staff role helper
-- Usage: select public.grant_staff('owner@thegrove.in', 'owner');
create or replace function public.grant_staff(staff_email text, new_role user_role)
returns text
language plpgsql security definer set search_path = public as $$
declare target uuid;
begin
  select id into target from profiles where email = staff_email;
  if target is null then
    raise exception 'No profile found for %. Sign up in the app first.', staff_email;
  end if;
  insert into staff_roles (user_id, role) values (target, new_role)
    on conflict (user_id) do update set role = excluded.role;
  update profiles set role = new_role where id = target;
  return 'granted ' || new_role::text || ' to ' || staff_email;
end;
$$;

-- Only an existing owner (or the SQL editor / service role) can grant roles.
revoke all on function public.grant_staff(text, user_role) from public;
grant execute on function public.grant_staff(text, user_role) to service_role;

-- Default guest support conversation topics (optional demo content)
-- Real conversations are created by customers through the app.
