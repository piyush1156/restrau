-- Customer notification and privacy preferences (enforced by the API before sending push/email).
alter table profiles
  add column if not exists notify_order_updates boolean not null default true,
  add column if not exists notify_offers boolean not null default true,
  add column if not exists notify_reservations boolean not null default true,
  add column if not exists share_analytics boolean not null default false;
