-- ============================================================================
-- The Grove Restaurant & Cafe — initial schema
-- Money is stored in integer minor units (paise). Never use floating point.
-- ============================================================================

create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- ------------------------------------------------------------------- enums
do $$ begin
  create type user_role as enum ('customer', 'owner', 'manager', 'kitchen', 'delivery');
exception when duplicate_object then null; end $$;

do $$ begin
  create type order_type as enum ('delivery', 'takeaway', 'dine_in');
exception when duplicate_object then null; end $$;

do $$ begin
  create type order_status as enum
    ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type payment_method as enum ('razorpay', 'cod');
exception when duplicate_object then null; end $$;

do $$ begin
  create type payment_status as enum ('pending', 'created', 'paid', 'failed', 'refunded', 'cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type reservation_status as enum ('pending', 'confirmed', 'rejected', 'cancelled', 'completed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type seat_preference as enum ('indoor', 'outdoor', 'any');
exception when duplicate_object then null; end $$;

do $$ begin
  create type message_role as enum ('user', 'assistant', 'staff');
exception when duplicate_object then null; end $$;

-- --------------------------------------------------------------- utilities
create or replace function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------------------------------------------------------------- profiles
create table if not exists profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null check (char_length(full_name) between 2 and 80),
  email citext not null unique,
  phone text check (phone ~ '^[6-9][0-9]{9}$'),
  role user_role not null default 'customer',
  locale text not null default 'en' check (locale in ('en', 'hi')),
  avatar_url text,
  push_tokens text[] not null default '{}',
  marketing_opt_in boolean not null default false,
  deletion_requested_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists profiles_role_idx on profiles (role);
create index if not exists profiles_email_idx on profiles (email);

drop trigger if exists profiles_updated_at on profiles;
create trigger profiles_updated_at before update on profiles
for each row execute function set_updated_at();

-- --------------------------------------------------------------- addresses
create table if not exists addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles (id) on delete cascade,
  label text not null check (label in ('Home', 'Work', 'Other')),
  line1 text not null check (char_length(line1) between 4 and 120),
  line2 text,
  landmark text,
  city text not null,
  pincode text not null check (pincode ~ '^[1-9][0-9]{5}$'),
  lat numeric(9, 6),
  lng numeric(9, 6),
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists addresses_user_idx on addresses (user_id);
create unique index if not exists addresses_one_default_idx
  on addresses (user_id) where is_default;

drop trigger if exists addresses_updated_at on addresses;
create trigger addresses_updated_at before update on addresses
for each row execute function set_updated_at();

-- -------------------------------------------------------------- categories
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------------- menu items
create table if not exists menu_items (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references categories (id) on delete restrict,
  name text not null,
  description text not null,
  price_minor integer not null check (price_minor >= 100),
  discounted_price_minor integer check (
    discounted_price_minor is null or (discounted_price_minor >= 100 and discounted_price_minor < price_minor)
  ),
  image_url text not null,
  rating numeric(2, 1) not null default 4.5 check (rating >= 0 and rating <= 5),
  review_count integer not null default 0 check (review_count >= 0),
  is_veg boolean not null default true,
  is_available boolean not null default true,
  is_special boolean not null default false,
  ingredients text[] not null default '{}',
  allergens text[] not null default '{}',
  prep_time_mins integer check (prep_time_mins between 1 and 120),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists menu_items_category_idx on menu_items (category_id);
create index if not exists menu_items_available_idx on menu_items (is_available, is_special);
create index if not exists menu_items_name_search_idx on menu_items using gin (to_tsvector('simple', name || ' ' || description));

drop trigger if exists menu_items_updated_at on menu_items;
create trigger menu_items_updated_at before update on menu_items
for each row execute function set_updated_at();

create table if not exists menu_item_images (
  id uuid primary key default gen_random_uuid(),
  menu_item_id uuid not null references menu_items (id) on delete cascade,
  url text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists menu_item_images_item_idx on menu_item_images (menu_item_id);

create table if not exists add_ons (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price_minor integer not null check (price_minor >= 0),
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists item_add_ons (
  menu_item_id uuid not null references menu_items (id) on delete cascade,
  add_on_id uuid not null references add_ons (id) on delete cascade,
  primary key (menu_item_id, add_on_id)
);

-- ------------------------------------------------------------- favourites
create table if not exists favourites (
  user_id uuid not null references profiles (id) on delete cascade,
  menu_item_id uuid not null references menu_items (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, menu_item_id)
);

-- ---------------------------------------------------------------- coupons
create table if not exists coupons (
  id uuid primary key default gen_random_uuid(),
  code citext not null unique,
  description text not null,
  discount_percent integer check (discount_percent between 1 and 90),
  discount_flat_minor integer check (discount_flat_minor >= 100),
  max_discount_minor integer check (max_discount_minor >= 100),
  min_order_minor integer not null default 0 check (min_order_minor >= 0),
  expires_at timestamptz not null,
  usage_limit integer check (usage_limit >= 1),
  used_count integer not null default 0 check (used_count >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint coupons_discount_present check (discount_percent is not null or discount_flat_minor is not null)
);

-- ---------------------------------------------------------------- orders
create sequence if not exists order_number_seq start 100001;

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('TG' || nextval('order_number_seq')),
  user_id uuid not null references profiles (id) on delete restrict,
  status order_status not null default 'pending',
  type order_type not null,
  payment_method payment_method not null,
  payment_status payment_status not null default 'pending',
  items_total_minor integer not null check (items_total_minor >= 0),
  discount_minor integer not null default 0 check (discount_minor >= 0),
  taxes_minor integer not null default 0 check (taxes_minor >= 0),
  delivery_fee_minor integer not null default 0 check (delivery_fee_minor >= 0),
  platform_fee_minor integer not null default 0 check (platform_fee_minor >= 0),
  grand_total_minor integer not null check (grand_total_minor >= 0),
  coupon_code citext references coupons (code) on delete set null,
  address_id uuid references addresses (id) on delete set null,
  address_snapshot jsonb,
  contact_phone text not null check (contact_phone ~ '^[6-9][0-9]{9}$'),
  delivery_instructions text,
  cancel_reason text,
  estimated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint orders_total_consistent check (
    grand_total_minor = items_total_minor - discount_minor + taxes_minor + delivery_fee_minor + platform_fee_minor
  ),
  constraint orders_delivery_address check (type <> 'delivery' or address_snapshot is not null)
);
create index if not exists orders_user_created_idx on orders (user_id, created_at desc);
create index if not exists orders_status_idx on orders (status, created_at desc);
create index if not exists orders_payment_status_idx on orders (payment_status);

drop trigger if exists orders_updated_at on orders;
create trigger orders_updated_at before update on orders
for each row execute function set_updated_at();

create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders (id) on delete cascade,
  menu_item_id uuid references menu_items (id) on delete set null,
  name text not null,
  image_url text not null,
  quantity integer not null check (quantity between 1 and 50),
  unit_price_minor integer not null check (unit_price_minor >= 0),
  add_ons jsonb not null default '[]'::jsonb,
  special_instructions text,
  created_at timestamptz not null default now()
);
create index if not exists order_items_order_idx on order_items (order_id);

create table if not exists order_status_history (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders (id) on delete cascade,
  status order_status not null,
  changed_by uuid references profiles (id) on delete set null,
  note text,
  created_at timestamptz not null default now()
);
create index if not exists order_status_history_order_idx on order_status_history (order_id, created_at);

-- -------------------------------------------------------------- payments
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders (id) on delete cascade,
  provider text not null default 'razorpay',
  provider_order_id text,
  provider_payment_id text,
  amount_minor integer not null check (amount_minor > 0),
  currency text not null default 'INR',
  status payment_status not null default 'created',
  signature_verified boolean not null default false,
  failure_reason text,
  raw_response jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_payment_id)
);
create index if not exists payments_order_idx on payments (order_id);
create unique index if not exists payments_provider_order_idx
  on payments (provider_order_id) where provider_order_id is not null;

drop trigger if exists payments_updated_at on payments;
create trigger payments_updated_at before update on payments
for each row execute function set_updated_at();

-- Idempotency for checkout and payment creation (prevents duplicate orders/charges).
create table if not exists idempotency_keys (
  key text primary key,
  user_id uuid not null references profiles (id) on delete cascade,
  scope text not null,
  response jsonb,
  created_at timestamptz not null default now()
);

create table if not exists coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_code citext not null references coupons (code) on delete cascade,
  user_id uuid not null references profiles (id) on delete cascade,
  order_id uuid not null references orders (id) on delete cascade,
  discount_minor integer not null check (discount_minor >= 0),
  created_at timestamptz not null default now(),
  unique (coupon_code, order_id)
);

-- ---------------------------------------------------------- reservations
create table if not exists restaurant_tables (
  id uuid primary key default gen_random_uuid(),
  table_number integer not null unique,
  capacity integer not null check (capacity between 1 and 20),
  seating seat_preference not null default 'indoor' check (seating in ('indoor', 'outdoor')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists reservations (
  id uuid primary key default gen_random_uuid(),
  code text not null unique default ('GRV' || (10000 + floor(random() * 90000))::int),
  user_id uuid not null references profiles (id) on delete cascade,
  reservation_date date not null,
  reservation_time time not null,
  guests integer not null check (guests between 1 and 20),
  seating seat_preference not null default 'any',
  table_id uuid references restaurant_tables (id) on delete set null,
  special_requests text,
  status reservation_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists reservations_date_idx on reservations (reservation_date, reservation_time);
-- one ACTIVE booking per table per date+slot; cancelled/rejected rows free the slot again
create unique index if not exists reservations_active_slot_idx
  on reservations (table_id, reservation_date, reservation_time)
  where status in ('pending', 'confirmed');
create index if not exists reservations_user_idx on reservations (user_id, created_at desc);

drop trigger if exists reservations_updated_at on reservations;
create trigger reservations_updated_at before update on reservations
for each row execute function set_updated_at();

create table if not exists restaurant_opening_hours (
  day integer primary key check (day between 0 and 6),
  opens_at time not null,
  closes_at time not null,
  is_closed boolean not null default false
);

create table if not exists delivery_assignments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references orders (id) on delete cascade,
  partner_id uuid not null references profiles (id) on delete restrict,
  assigned_at timestamptz not null default now(),
  picked_up_at timestamptz,
  delivered_at timestamptz
);

-- --------------------------------------------------------------- reviews
create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  menu_item_id uuid not null references menu_items (id) on delete cascade,
  user_id uuid not null references profiles (id) on delete cascade,
  order_id uuid references orders (id) on delete set null,
  rating integer not null check (rating between 1 and 5),
  comment text check (char_length(comment) <= 500),
  created_at timestamptz not null default now(),
  unique (menu_item_id, user_id, order_id)
);
create index if not exists reviews_item_idx on reviews (menu_item_id, created_at desc);

-- --------------------------------------------------------- notifications
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles (id) on delete cascade,
  title text not null,
  body text not null,
  data jsonb not null default '{}'::jsonb,
  channel text not null default 'push' check (channel in ('push', 'email', 'sms', 'in_app')),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on notifications (user_id, created_at desc);

-- ------------------------------------------------------------ support chat
create table if not exists support_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles (id) on delete cascade,
  subject text,
  status text not null default 'open' check (status in ('open', 'resolved', 'escalated')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists support_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references support_conversations (id) on delete cascade,
  role message_role not null,
  user_id uuid references profiles (id) on delete set null,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists support_messages_conversation_idx on support_messages (conversation_id, created_at);

-- ------------------------------------------------------------ staff / audit
create table if not exists staff_roles (
  user_id uuid primary key references profiles (id) on delete cascade,
  role user_role not null check (role in ('owner', 'manager', 'kitchen', 'delivery')),
  granted_by uuid references profiles (id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references profiles (id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  before jsonb,
  after jsonb,
  ip text,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_created_idx on audit_logs (created_at desc);

-- ---------------------------------------------------------------- helpers
create or replace function current_role_of(uid uuid) returns user_role
language sql stable security definer set search_path = public as $$
  select coalesce((select role from profiles where id = uid), 'customer'::user_role);
$$;

create or replace function is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select current_role_of(auth.uid()) in ('owner', 'manager', 'kitchen', 'delivery');
$$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select current_role_of(auth.uid()) in ('owner', 'manager');
$$;

create or replace function has_role(roles user_role[]) returns boolean
language sql stable security definer set search_path = public as $$
  select current_role_of(auth.uid()) = any(roles);
$$;

-- Keep ratings in sync with reviews.
create or replace function sync_menu_item_rating() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update menu_items mi
     set rating = coalesce((select round(avg(r.rating)::numeric, 1) from reviews r where r.menu_item_id = mi.id), 4.5),
         review_count = (select count(*) from reviews r where r.menu_item_id = mi.id)
   where mi.id = coalesce(new.menu_item_id, old.menu_item_id);
  return null;
end;
$$;

drop trigger if exists reviews_sync_rating on reviews;
create trigger reviews_sync_rating after insert or update or delete on reviews
for each row execute function sync_menu_item_rating();

-- NOTE: order_status_history is written explicitly by the API so each row records
-- who changed the status and why. No trigger is used here to avoid duplicate rows.

-- Prevent reservation double-booking at the database level, not just the API.
create or replace function assert_no_reservation_conflict() returns trigger
language plpgsql as $$
begin
  if new.status in ('pending', 'confirmed') and new.table_id is not null then
    if exists (
      select 1 from reservations r
       where r.id <> new.id
         and r.table_id = new.table_id
         and r.reservation_date = new.reservation_date
         and r.reservation_time = new.reservation_time
         and r.status in ('pending', 'confirmed')
    ) then
      raise exception 'That table is already booked for this slot.' using errcode = '23505';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists reservations_no_conflict on reservations;
create trigger reservations_no_conflict before insert or update on reservations
for each row execute function assert_no_reservation_conflict();
