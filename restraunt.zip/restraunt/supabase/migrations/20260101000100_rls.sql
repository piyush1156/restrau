-- ============================================================================
-- Row Level Security — least privilege for customers, staff and the service role
-- ============================================================================

alter table profiles enable row level security;
alter table addresses enable row level security;
alter table categories enable row level security;
alter table menu_items enable row level security;
alter table menu_item_images enable row level security;
alter table add_ons enable row level security;
alter table item_add_ons enable row level security;
alter table favourites enable row level security;
alter table coupons enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table order_status_history enable row level security;
alter table payments enable row level security;
alter table idempotency_keys enable row level security;
alter table coupon_redemptions enable row level security;
alter table reservations enable row level security;
alter table restaurant_tables enable row level security;
alter table restaurant_opening_hours enable row level security;
alter table delivery_assignments enable row level security;
alter table reviews enable row level security;
alter table notifications enable row level security;
alter table support_conversations enable row level security;
alter table support_messages enable row level security;
alter table staff_roles enable row level security;
alter table audit_logs enable row level security;

-- ---------------------------------------------------------------- profiles
drop policy if exists profiles_select_own on profiles;
create policy profiles_select_own on profiles for select
  using (id = auth.uid() or is_staff());

drop policy if exists profiles_update_own on profiles;
create policy profiles_update_own on profiles for update
  using (id = auth.uid()) with check (id = auth.uid());

-- customers must never be able to promote themselves
create or replace function guard_profile_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.role is distinct from old.role and not is_admin() then
    raise exception 'Only an owner or manager can change roles.';
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_guard_role on profiles;
create trigger profiles_guard_role before update on profiles
for each row execute function guard_profile_role();

-- --------------------------------------------------------------- addresses
drop policy if exists addresses_owner_all on addresses;
create policy addresses_owner_all on addresses for all
  using (user_id = auth.uid() or is_staff())
  with check (user_id = auth.uid());

-- ------------------------------------------------------- public catalogue
drop policy if exists categories_read on categories;
create policy categories_read on categories for select using (true);

drop policy if exists menu_items_read on menu_items;
create policy menu_items_read on menu_items for select using (true);

drop policy if exists menu_item_images_read on menu_item_images;
create policy menu_item_images_read on menu_item_images for select using (true);

drop policy if exists add_ons_read on add_ons;
create policy add_ons_read on add_ons for select using (true);

drop policy if exists item_add_ons_read on item_add_ons;
create policy item_add_ons_read on item_add_ons for select using (true);

drop policy if exists coupons_read_active on coupons;
create policy coupons_read_active on coupons for select
  using (is_active and expires_at > now());

-- ------------------------------------------------------------- favourites
drop policy if exists favourites_owner_all on favourites;
create policy favourites_owner_all on favourites for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------- orders
-- Customers read their own orders only. Writes go through the API (service role)
-- so totals, status transitions and payment state can never be forged client-side.
drop policy if exists orders_select_own on orders;
create policy orders_select_own on orders for select
  using (user_id = auth.uid() or is_staff());

drop policy if exists order_items_select_own on order_items;
create policy order_items_select_own on order_items for select
  using (
    exists (select 1 from orders o where o.id = order_items.order_id and (o.user_id = auth.uid() or is_staff()))
  );

drop policy if exists order_history_select_own on order_status_history;
create policy order_history_select_own on order_status_history for select
  using (
    exists (select 1 from orders o where o.id = order_status_history.order_id and (o.user_id = auth.uid() or is_staff()))
  );

drop policy if exists payments_select_own on payments;
create policy payments_select_own on payments for select
  using (
    exists (select 1 from orders o where o.id = payments.order_id and (o.user_id = auth.uid() or is_staff()))
  );

drop policy if exists redemptions_select_own on coupon_redemptions;
create policy redemptions_select_own on coupon_redemptions for select
  using (user_id = auth.uid() or is_admin());

-- ---------------------------------------------------------- reservations
drop policy if exists reservations_select on reservations;
create policy reservations_select on reservations for select
  using (user_id = auth.uid() or is_staff());

-- Customers may request a cancellation, never confirm/reject their own booking.
drop policy if exists reservations_cancel_own on reservations;
create policy reservations_cancel_own on reservations for update
  using (user_id = auth.uid()) with check (user_id = auth.uid() and status = 'cancelled');

drop policy if exists tables_read on restaurant_tables;
create policy tables_read on restaurant_tables for select using (true);

drop policy if exists hours_read on restaurant_opening_hours;
create policy hours_read on restaurant_opening_hours for select using (true);

drop policy if exists deliveries_select on delivery_assignments;
create policy deliveries_select on delivery_assignments for select
  using (
    partner_id = auth.uid()
    or is_admin()
    or exists (select 1 from orders o where o.id = delivery_assignments.order_id and o.user_id = auth.uid())
  );

-- --------------------------------------------------------------- reviews
drop policy if exists reviews_read on reviews;
create policy reviews_read on reviews for select using (true);

-- A review is always tied to the signed-in customer. order_id is set by the API
-- when a delivered order exists ("verified purchase"), otherwise it stays null.
drop policy if exists reviews_insert_own on reviews;
create policy reviews_insert_own on reviews for insert
  with check (user_id = auth.uid());

drop policy if exists reviews_delete_own on reviews;
create policy reviews_delete_own on reviews for delete using (user_id = auth.uid());

-- --------------------------------------------------------- notifications
drop policy if exists notifications_own on notifications;
create policy notifications_own on notifications for select using (user_id = auth.uid());
drop policy if exists notifications_mark_read on notifications;
create policy notifications_mark_read on notifications for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ------------------------------------------------------------ support
drop policy if exists support_conversations_own on support_conversations;
create policy support_conversations_own on support_conversations for select
  using (user_id = auth.uid() or is_staff());

drop policy if exists support_conversations_insert on support_conversations;
create policy support_conversations_insert on support_conversations for insert
  with check (user_id = auth.uid());

drop policy if exists support_messages_read on support_messages;
create policy support_messages_read on support_messages for select
  using (
    exists (
      select 1 from support_conversations c
       where c.id = support_messages.conversation_id and (c.user_id = auth.uid() or is_staff())
    )
  );

drop policy if exists support_messages_insert on support_messages;
create policy support_messages_insert on support_messages for insert
  with check (
    role = 'user'
    and exists (
      select 1 from support_conversations c
       where c.id = support_messages.conversation_id and c.user_id = auth.uid()
    )
  );

-- -------------------------------------------------------- staff / audit
drop policy if exists staff_roles_read_self on staff_roles;
create policy staff_roles_read_self on staff_roles for select
  using (user_id = auth.uid() or is_admin());

drop policy if exists audit_logs_admin_read on audit_logs;
create policy audit_logs_admin_read on audit_logs for select using (is_admin());

-- idempotency rows are service-role only
drop policy if exists idempotency_no_client on idempotency_keys;
create policy idempotency_no_client on idempotency_keys for select using (false);

-- ------------------------------------------------------------------------
-- Column protections: staff listings must not leak private customer fields
-- to kitchen/delivery roles beyond what they need. Handled in the API layer
-- by selecting explicit columns per role; RLS above limits the rows.
-- ------------------------------------------------------------------------
