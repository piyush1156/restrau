-- ============================================================================
-- Helper RPCs used by the API (service role only)
-- ============================================================================

-- Atomically bump coupon usage; returns the new count.
create or replace function increment_coupon_usage(coupon_code citext)
returns integer
language plpgsql security definer set search_path = public as $$
declare new_count integer;
begin
  update coupons
     set used_count = used_count + 1
   where code = coupon_code
     and is_active
     and (usage_limit is null or used_count < usage_limit)
  returning used_count into new_count;

  if new_count is null then
    raise exception 'Coupon is no longer available.' using errcode = 'P0001';
  end if;
  return new_count;
end;
$$;

revoke all on function increment_coupon_usage(citext) from public;
grant execute on function increment_coupon_usage(citext) to service_role;

-- Revenue for a day range, paid orders only. Used by reports + dashboard.
create or replace function revenue_between(from_ts timestamptz, to_ts timestamptz)
returns table (day date, orders bigint, revenue_minor bigint)
language sql stable security definer set search_path = public as $$
  select (created_at at time zone 'Asia/Kolkata')::date as day,
         count(*) as orders,
         coalesce(sum(grand_total_minor) filter (where payment_status = 'paid'), 0)::bigint as revenue_minor
    from orders
   where created_at >= from_ts and created_at < to_ts and status <> 'cancelled'
   group by 1
   order by 1;
$$;

revoke all on function revenue_between(timestamptz, timestamptz) from public;
grant execute on function revenue_between(timestamptz, timestamptz) to service_role;

-- Expire stale unpaid online orders so the kitchen queue stays honest.
create or replace function expire_unpaid_orders()
returns integer
language plpgsql security definer set search_path = public as $$
declare affected integer;
begin
  update orders
     set status = 'cancelled',
         cancel_reason = 'Payment not completed in time'
   where payment_method = 'razorpay'
     and payment_status in ('pending', 'created', 'failed')
     and status in ('pending', 'confirmed')
     and created_at < now() - interval '30 minutes';
  get diagnostics affected = row_count;
  return affected;
end;
$$;

revoke all on function expire_unpaid_orders() from public;
grant execute on function expire_unpaid_orders() to service_role;
